ilLumenate CAD toolkit 0.6.1

Install: copy the ilLumenate.bundle folder into
  Windows: %APPDATA%\Autodesk\ApplicationPlugins
  Mac:     ~/Library/Application Support/Autodesk/ApplicationAddins
then restart AutoCAD. Type ILHELP for the commands.

1. ILSETUP, then ILCATALOG with the CAD catalog downloaded from the ilLumenate portal.
2. ILSCALE the architect's underlay, ILROOM the rooms, ILCAB the cabinets.
3. ILSTYLE a run style, ILTAPE or ILCONVERT the runs, ILPSU and ILCONNECT the supplies, ILWIRE the home runs.
4. ILCHECK, then ILQUOTE to write the .ilq.json package.
5. On the schedule page in the portal: Import Drawing. Download the receipt and run ILRECEIPT.

The toolkit makes no network calls and never holds prices. Lengths it shows are hints: the portal's
configurators snap, split and build every run, and the System Designer sizes supplies and wire.
Supported: AutoCAD 2019+ on Windows; AutoCAD LT 2024+ and AutoCAD for Mac pending the version spike.
