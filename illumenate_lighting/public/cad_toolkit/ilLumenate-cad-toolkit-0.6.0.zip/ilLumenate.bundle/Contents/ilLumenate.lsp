;;; ilLumenate CAD toolkit 0.6.0 -- built by tools/cad_toolkit/package_bundle.py. Do not edit.

;;; ---- il-util.lsp ----
;;; il-util.lsp -- ilLumenate CAD toolkit: pure helpers (strings, lists, numbers).
;;;
;;; No AutoCAD calls here, so tools/cad_toolkit/test/mini_lisp.py can run it in CI. Plain AutoLISP
;;; plus a few vl- string and list functions that full AutoCAD, LT 2024+ and Mac all provide
;;; (no vlax-/vla- ActiveX, no reactors).

(setq *il-version* "0.6.0")

;; --- Association lists ------------------------------------------------------------------------

(defun il-get (key alist / pair)
  (if (setq pair (assoc key alist)) (cdr pair))
)

(defun il-put (key value alist)
  (if (assoc key alist)
    (subst (cons key value) (assoc key alist) alist)
    (append alist (list (cons key value)))
  )
)

(defun il-drop (key alist / result)
  (foreach pair alist
    (if (not (equal (car pair) key)) (setq result (cons pair result)))
  )
  (reverse result)
)

;; --- Strings ----------------------------------------------------------------------------------

(defun il-str (value)
  (cond
    ((null value) "")
    ((= (type value) 'STR) value)
    ((= (type value) 'INT) (itoa value))
    ((= (type value) 'REAL) (il-num->str value 4))
    (T (vl-princ-to-string value))
  )
)

(defun il-trim (text)
  (vl-string-trim " \t\r\n" (il-str text))
)

(defun il-split (text sep / parts at size)
  (setq size (strlen sep))
  (while (setq at (vl-string-search sep text))
    (setq parts (cons (substr text 1 at) parts)
          text (substr text (+ at size 1)))
  )
  (reverse (cons text parts))
)

(defun il-join (items sep / result)
  (setq result "")
  (foreach item items
    (setq result (if (= result "") (il-str item) (strcat result sep (il-str item))))
  )
  result
)

(defun il-replace-all (text old new / at result size)
  (setq result "" size (strlen old))
  (while (setq at (vl-string-search old text))
    (setq result (strcat result (substr text 1 at) new)
          text (substr text (+ at size 1)))
  )
  (strcat result text)
)

(defun il-starts-with (text prefix)
  (and (>= (strlen text) (strlen prefix)) (= (substr text 1 (strlen prefix)) prefix))
)

;; SLUG made unique among USED ids of at most SIZE characters: "COVE", then "COVE-2", "COVE-3" (the slug
;; is cut so the suffix fits).
(defun il-unique-id (slug used size / number suffix candidate)
  (setq candidate slug number 1)
  (while (member candidate used)
    (setq number (1+ number) suffix (strcat "-" (itoa number))
          candidate (strcat (vl-string-right-trim "._-" (substr slug 1 (- size (strlen suffix)))) suffix))
  )
  candidate
)

(defun il-pad2 (number)
  (if (< number 10) (strcat "0" (itoa number)) (itoa number))
)

;; --- Numbers ----------------------------------------------------------------------------------

(defun il-floor (x / n)
  (setq n (fix x))
  (if (and (< x 0) (/= x n)) (1- n) n)
)

(defun il-ceil (x / n)
  (setq n (fix x))
  (if (and (> x 0) (/= x n)) (1+ n) n)
)

;; Round half away from zero to DIGITS decimals (display values).
(defun il-round (x digits / scale)
  (setq scale (expt 10.0 digits))
  (if (minusp x)
    (- (/ (il-floor (+ (* (- x) scale) 0.5)) scale))
    (/ (il-floor (+ (* x scale) 0.5)) scale)
  )
)

;; Round half to even to a whole number, like Python's round(): the configurator's equal split
;; (tape_neon_configurator._compute_run_split) uses it, so the hint must too.
(defun il-round-even (x / low diff)
  (setq low (il-floor x) diff (- x low))
  (cond
    ((< diff 0.5) low)
    ((> diff 0.5) (1+ low))
    ((= (rem low 2) 0) low)
    (T (1+ low))
  )
)

;; Python round(x, digits) for reporting (half to even on the scaled value, then back).
(defun il-round-py (x digits / scale scaled low diff)
  (setq scale (expt 10.0 digits) scaled (* x scale) low (il-floor scaled) diff (- scaled low))
  (cond
    ((< (abs (- diff 0.5)) 1e-9) (/ (il-round-even scaled) scale))
    (T (/ (il-floor (+ scaled 0.5)) scale))
  )
)

;; A number as text with at most DIGITS decimals and no trailing zeros ("12", "12.5").
(defun il-num->str (x digits / text)
  (if (= (type x) 'INT)
    (itoa x)
    (progn
      (setq text (rtos (il-round x digits) 2 digits))
      (if (vl-string-search "." text)
        (progn
          (setq text (vl-string-right-trim "0" text))
          (if (= (substr text (strlen text)) ".") (setq text (substr text 1 (1- (strlen text)))))
        )
      )
      (if (= text "-0") "0" text)
    )
  )
)

;; TEXT as a number when it is a plain decimal ("24", "4.4", ".5", "1.97"), else nil.
(defun il-parse-number (text / index char digits dots)
  (setq text (il-trim text) index 1 digits 0 dots 0)
  (while (<= index (strlen text))
    (setq char (substr text index 1) index (1+ index))
    (cond
      ((< 47 (ascii char) 58) (setq digits (1+ digits)))
      ((= char ".") (setq dots (1+ dots)))
      (T (setq dots 2))
    )
  )
  (if (and (> digits 0) (< dots 2)) (atof text))
)

(defun il-number (value)
  (cond
    ((numberp value) value)
    ((and (= (type value) 'STR) (/= (il-trim value) "")) (atof value))
    (T nil)
  )
)

;; A dotted version as integers: "0.10.2" -> (0 10 2). Text after a part's digits is ignored.
(defun il-version-parts (text)
  (mapcar 'atoi (il-split (il-trim text) "."))
)

;; True when version A is older than version B, comparing each dotted part as a number ("0.9" < "0.10";
;; missing parts count as 0, so "0.5" equals "0.5.0").
(defun il-version< (a b / pa pb x y result done)
  (setq pa (il-version-parts a) pb (il-version-parts b))
  (while (and (not done) (or pa pb))
    (setq x (if pa (car pa) 0) y (if pb (car pb) 0) pa (cdr pa) pb (cdr pb))
    (cond
      ((< x y) (setq result T done T))
      ((> x y) (setq done T))
    )
  )
  result
)

(defun il-sum (numbers / total)
  (setq total 0.0)
  (foreach n numbers (if (numberp n) (setq total (+ total n))))
  total
)

;; --- Copies and scaling -----------------------------------------------------------------------

;; True when handle A was made before handle B (handles are hex and only grow).
(defun il-handle< (a b)
  (if (= (strlen a) (strlen b)) (< (strcase a) (strcase b)) (< (strlen a) (strlen b)))
)

;; Which tagged entities are copies. COPY and paste duplicate XData, so a copy carries the original's
;; id and the handle the original stored as "self". RECORDS: ((key id self handle) ...). Among the
;; entities sharing an id, the oldest one still on its own handle keeps it (the oldest of them all
;; when none is); the rest are copies. Returns ((copy-key . keeper-handle) ...).
(defun il-copies (records / groups group candidates keeper result)
  (foreach record records
    (if (/= (il-str (cadr record)) "")
      (setq groups (il-put (cadr record) (append (il-get (cadr record) groups) (list record)) groups))
    )
  )
  (foreach pair groups
    (setq group (cdr pair))
    (if (cdr group)
      (progn
        (setq candidates (vl-remove-if-not '(lambda (record) (= (nth 2 record) (nth 3 record))) group) keeper nil)
        (foreach record (if candidates candidates group)
          (if (or (null keeper) (il-handle< (nth 3 record) (nth 3 keeper))) (setq keeper record))
        )
        (foreach record group
          (if (not (equal (car record) (car keeper))) (setq result (cons (cons (car record) (nth 3 keeper)) result)))
        )
      )
    )
  )
  (reverse result)
)

;; The part of an id before its trailing number: "L1-03" -> "L1-", "CAB-2" -> "CAB-", "kitchen" -> "kitchen-".
(defun il-id-prefix (id / end)
  (setq end (strlen id))
  (while (and (> end 0) (< 47 (ascii (substr id end 1)) 58)) (setq end (1- end)))
  (if (= end (strlen id)) (strcat id "-") (substr id 1 end))
)

;; POINT scaled by FACTOR about BASE.
(defun il-scale-about (base point factor)
  (mapcar '(lambda (b p) (+ b (* factor (- p b)))) base point)
)

;; Where an attribute of a block item ("ATTDEF" tag x y ...) lands for an insert at BASE, SCALE, ROTATION.
(defun il-attdef-point (base scale rotation item / x y)
  (setq x (* scale (nth 2 item)) y (* scale (nth 3 item)))
  (list (+ (car base) (- (* x (cos rotation)) (* y (sin rotation))))
        (+ (cadr base) (* x (sin rotation)) (* y (cos rotation)))
        (if (caddr base) (caddr base) 0.0))
)

;; DATA (an entity list) with group CODE set to VALUE, added when missing.
(defun il-set-group (code value data)
  (if (assoc code data)
    (subst (cons code value) (assoc code data) data)
    (append data (list (cons code value)))
  )
)

;; The text alignment groups for a block item: centred ones carry ((72 . 1) (74 . 0) (11 . point)).
(defun il-align-groups (item point)
  (if (= (nth 8 item) "center") (list '(72 . 1) '(74 . 0) (cons 11 point)) '((72 . 0)))
)

;;; ---- il-json.lsp ----
;;; il-json.lsp -- ilLumenate CAD toolkit: a small JSON reader and writer (no network, no ActiveX).
;;;
;;; Values: an object is (IL-OBJ (key . value) ...), an array (IL-ARR item ...), true IL-TRUE,
;;; false IL-FALSE, null nil; strings and numbers are themselves. The reader takes a file (line by
;;; line, so a large catalog never becomes one huge string) or a string. Pure: CI runs it.

;; --- Constructors and accessors ----------------------------------------------------------------

(defun il-obj (pairs) (cons 'IL-OBJ pairs))
(defun il-arr (items) (cons 'IL-ARR items))
(defun il-obj-p (value) (and (listp value) value (eq (car value) 'IL-OBJ)))
(defun il-arr-p (value) (and (listp value) value (eq (car value) 'IL-ARR)))
(defun il-true-p (value) (eq value 'IL-TRUE))
(defun il-bool (flag) (if flag 'IL-TRUE 'IL-FALSE))

;; The value at KEY of an object (nil when absent or null).
(defun il-j (obj key)
  (if (il-obj-p obj) (il-get key (cdr obj)))
)

;; The value at a key path: (il-jp catalog '("settings" "stale_days")).
(defun il-jp (value path)
  (foreach key path (setq value (il-j value key)))
  value
)

;; The items of an array (nil for anything else).
(defun il-items (value)
  (if (il-arr-p value) (cdr value))
)

(defun il-keys (obj)
  (if (il-obj-p obj) (mapcar 'car (cdr obj)))
)

(defun il-jset (obj key value)
  (il-obj (il-put key value (cdr obj)))
)

;; --- Reader -----------------------------------------------------------------------------------
;; State: *il-jr-text* is the current chunk, *il-jr-pos* the 1-based position in it, *il-jr-file*
;; the open file (or nil when reading a string).

(defun il-jr-more ()
  (if (and *il-jr-file* (> *il-jr-pos* (strlen *il-jr-text*)))
    (progn
      (setq *il-jr-text* (read-line *il-jr-file*) *il-jr-pos* 1)
      (if *il-jr-text* (setq *il-jr-text* (strcat *il-jr-text* "\n")) (setq *il-jr-text* "" *il-jr-file* nil))
    )
  )
  (<= *il-jr-pos* (strlen *il-jr-text*))
)

(defun il-jr-peek ()
  (if (il-jr-more) (substr *il-jr-text* *il-jr-pos* 1))
)

(defun il-jr-next (/ char)
  (if (setq char (il-jr-peek)) (setq *il-jr-pos* (1+ *il-jr-pos*)))
  char
)

(defun il-jr-space (/ char)
  (while (and (setq char (il-jr-peek)) (member char '(" " "\t" "\n" "\r")))
    (setq *il-jr-pos* (1+ *il-jr-pos*))
  )
)

(defun il-jr-fail (message)
  (setq *il-jr-error* message)
  (exit)
)

(defun il-jr-expect (word / index)
  (setq index 1)
  (while (<= index (strlen word))
    (if (/= (il-jr-next) (substr word index 1)) (il-jr-fail (strcat "JSON: expected " word)))
    (setq index (1+ index))
  )
)

(defun il-jr-hex (text / value index char code)
  (setq value 0 index 1)
  (while (<= index (strlen text))
    (setq char (strcase (substr text index 1)) code (ascii char))
    (setq value (+ (* value 16) (if (>= code 65) (- code 55) (- code 48))))
    (setq index (1+ index))
  )
  value
)

(defun il-jr-string (/ parts char escape code done)
  (il-jr-next) ; opening quote
  (while (not done)
    (setq char (il-jr-next))
    (cond
      ((null char) (il-jr-fail "JSON: unterminated string"))
      ((= char "\"") (setq done T))
      ((= char "\\")
        (setq escape (il-jr-next))
        (setq parts
          (cons
            (cond
              ((= escape "n") "\n")
              ((= escape "t") "\t")
              ((= escape "r") "\r")
              ((= escape "b") "")
              ((= escape "f") "")
              ((= escape "u")
                (setq code (il-jr-hex (strcat (il-jr-next) (il-jr-next) (il-jr-next) (il-jr-next))))
                (if (and (> code 31) (< code 127)) (chr code) "?")
              )
              (T escape)
            )
            parts
          )
        )
      )
      (T (setq parts (cons char parts)))
    )
  )
  (apply 'strcat (reverse parts))
)

(defun il-jr-number (/ text char real)
  (setq text "")
  (while (and (setq char (il-jr-peek)) (vl-string-search char "+-0123456789.eE"))
    (if (vl-string-search char ".eE") (setq real T))
    (setq text (strcat text char) *il-jr-pos* (1+ *il-jr-pos*))
  )
  (if (or real (> (strlen text) 9)) (atof text) (atoi text))
)

(defun il-jr-value (/ char items pairs key)
  (il-jr-space)
  (setq char (il-jr-peek))
  (cond
    ((null char) (il-jr-fail "JSON: unexpected end"))
    ((= char "{")
      (il-jr-next)
      (il-jr-space)
      (if (= (il-jr-peek) "}")
        (il-jr-next)
        (progn
          (setq char ",")
          (while (= char ",")
            (il-jr-space)
            (setq key (il-jr-string))
            (il-jr-space)
            (if (/= (il-jr-next) ":") (il-jr-fail "JSON: expected :"))
            (setq pairs (cons (cons key (il-jr-value)) pairs))
            (il-jr-space)
            (setq char (il-jr-next))
          )
          (if (/= char "}") (il-jr-fail "JSON: expected }"))
        )
      )
      (il-obj (reverse pairs))
    )
    ((= char "[")
      (il-jr-next)
      (il-jr-space)
      (if (= (il-jr-peek) "]")
        (il-jr-next)
        (progn
          (setq char ",")
          (while (= char ",")
            (setq items (cons (il-jr-value) items))
            (il-jr-space)
            (setq char (il-jr-next))
          )
          (if (/= char "]") (il-jr-fail "JSON: expected ]"))
        )
      )
      (il-arr (reverse items))
    )
    ((= char "\"") (il-jr-string))
    ((= char "t") (il-jr-expect "true") 'IL-TRUE)
    ((= char "f") (il-jr-expect "false") 'IL-FALSE)
    ((= char "n") (il-jr-expect "null") nil)
    (T (il-jr-number))
  )
)

;; Parse TEXT; returns the value, or nil with *il-jr-error* set.
(defun il-json-parse (text / result)
  (setq *il-jr-text* text *il-jr-pos* 1 *il-jr-file* nil *il-jr-error* nil)
  (setq result (vl-catch-all-apply 'il-jr-value nil))
  (if (vl-catch-all-error-p result)
    (progn (if (null *il-jr-error*) (setq *il-jr-error* (vl-catch-all-error-message result))) nil)
    result
  )
)

;; Parse the JSON file at PATH; returns the value, or nil with *il-jr-error* set.
(defun il-json-read-file (path / file result)
  (setq *il-jr-error* nil)
  (if (not (setq file (open path "r")))
    (progn (setq *il-jr-error* (strcat "Cannot open " path)) nil)
    (progn
      (setq *il-jr-text* "" *il-jr-pos* 1 *il-jr-file* file)
      (setq result (vl-catch-all-apply 'il-jr-value nil))
      (close file)
      (setq *il-jr-file* nil)
      (if (vl-catch-all-error-p result)
        (progn (if (null *il-jr-error*) (setq *il-jr-error* (vl-catch-all-error-message result))) nil)
        result
      )
    )
  )
)

;; --- Writer -----------------------------------------------------------------------------------

(defun il-jw-string (text / index char code out)
  (setq index 1 out (list "\""))
  (while (<= index (strlen text))
    (setq char (substr text index 1) code (ascii char))
    (setq out
      (cons
        (cond
          ((= char "\"") "\\\"")
          ((= char "\\") "\\\\")
          ((= code 10) "\\n")
          ((= code 13) "\\r")
          ((= code 9) "\\t")
          ((< code 32) " ")
          (T char)
        )
        out
      )
    )
    (setq index (1+ index))
  )
  (apply 'strcat (reverse (cons "\"" out)))
)

;; The JSON text pieces of VALUE, appended in reverse to ACC (callers reverse once).
(defun il-jw-pieces (value acc / first)
  (cond
    ((null value) (cons "null" acc))
    ((eq value 'IL-TRUE) (cons "true" acc))
    ((eq value 'IL-FALSE) (cons "false" acc))
    ((= (type value) 'STR) (cons (il-jw-string value) acc))
    ((= (type value) 'INT) (cons (itoa value) acc))
    ((= (type value) 'REAL) (cons (il-num->str value 6) acc))
    ((il-obj-p value)
      (setq acc (cons "{" acc) first T)
      (foreach pair (cdr value)
        (if (not first) (setq acc (cons "," acc)))
        (setq first nil acc (cons ":" (cons (il-jw-string (car pair)) acc)))
        (setq acc (il-jw-pieces (cdr pair) acc))
      )
      (cons "}" acc)
    )
    ((il-arr-p value)
      (setq acc (cons "[" acc) first T)
      (foreach item (cdr value)
        (if (not first) (setq acc (cons "," acc)))
        (setq first nil acc (il-jw-pieces item acc))
      )
      (cons "]" acc)
    )
    (T (cons (il-jw-string (il-str value)) acc))
  )
)

(defun il-json-text (value)
  (apply 'strcat (reverse (il-jw-pieces value nil)))
)

;; Write VALUE to PATH, a few hundred characters per line so no line is ever too long to read back.
(defun il-json-write-file (value path / file line piece)
  (if (setq file (open path "w"))
    (progn
      (setq line "")
      (foreach piece (reverse (il-jw-pieces value nil))
        (setq line (strcat line piece))
        (if (and (> (strlen line) 200) (member (substr line (strlen line)) '("," "{" "[")))
          (progn (write-line line file) (setq line ""))
        )
      )
      (if (/= line "") (write-line line file))
      (close file)
      T
    )
  )
)

;;; ---- il-math.lsp ----
;;; il-math.lsp -- ilLumenate CAD toolkit: the hint math (draw-to-quote plan 1.7).
;;;
;;; The toolkit only shows hints; the configurators decide on import. These mirror, one for one,
;;; tools/cad_toolkit/reference/cad_subset.py and the server rules it is tested against:
;;;   cut snap   -- configuration_contract.whole_increments as tape_neon_configurator applies it
;;;   max run    -- tape_neon_configurator._compute_run_split (85 W per run, voltage-drop run)
;;;   PSU load   -- watts against rated W x usable_load_factor (a provisional tag, never sizing)
;;;   path       -- polyline length with bulges and its smallest arc radius (bend check)
;;; tools/system_designer/fixtures/cad/lisp-subset.json holds the shared golden cases.

(setq *il-mm-per-in* 25.4 *il-mm-per-ft* 304.8 *il-max-watts-per-run* 85.0)

(defun il-whole-increments (size increment)
  (il-floor (+ (/ (float size) increment) 1e-9))
)

;; One segment: ((mfg_in . x) (increments . n) (diff_in . d)).
(defun il-cut-snap (length-in cut-mm free-cut / requested increments mfg)
  (setq requested (* length-in *il-mm-per-in*))
  (if (or free-cut (null cut-mm) (<= cut-mm 0) (<= requested 0))
    (list (cons "mfg_in" (il-round-py length-in 4)) (cons "increments" nil) (cons "diff_in" 0.0))
    (progn
      (setq increments (max 1 (il-whole-increments requested cut-mm)))
      (setq mfg (* increments cut-mm))
      (list
        (cons "mfg_in" (il-round-py (/ mfg *il-mm-per-in*) 4))
        (cons "increments" increments)
        (cons "diff_in" (il-round-py (/ (- requested mfg) *il-mm-per-in*) 4))
      )
    )
  )
)

;; The configurator's effective max run in feet; nil means no limit.
(defun il-max-run-ft (w-per-ft vd-ft override-ft / by-watts)
  (cond
    ((and override-ft (> override-ft 0)) (float override-ft))
    (T
      (setq by-watts (if (and w-per-ft (> w-per-ft 0)) (/ *il-max-watts-per-run* w-per-ft)))
      (cond
        ((and vd-ft (> vd-ft 0) by-watts) (min by-watts (float vd-ft)))
        ((and vd-ft (> vd-ft 0)) (float vd-ft))
        (T by-watts)
      )
    )
  )
)

;; ((max_run_ft . f) (pct_of_max . p) (runs_count . n) (runs_in . (a b ...))).
(defun il-run-split (length-in w-per-ft cut-mm free-cut vd-ft override-ft
                     / length-mm effective max-mm count increment total base extra index runs)
  (setq length-mm (* length-in *il-mm-per-in*)
        effective (il-max-run-ft w-per-ft vd-ft override-ft))
  (setq max-mm (if effective (* effective *il-mm-per-ft*)))
  (setq count
    (if (and max-mm (> length-mm max-mm)) (il-ceil (/ length-mm max-mm)) 1))
  (setq increment (if (and (not free-cut) cut-mm (> cut-mm 0)) cut-mm 0))
  (cond
    ((= count 1) (setq runs (list length-mm)))
    ((> increment 0)
      (setq total (il-round-even (/ length-mm increment))
            base (/ total count)
            extra (rem total count)
            index 0)
      (repeat count
        (setq runs (cons (* (+ base (if (< index extra) 1 0)) increment) runs) index (1+ index))
      )
      (setq runs (reverse runs))
    )
    (T (repeat count (setq runs (cons (/ length-mm count) runs))))
  )
  (list
    (cons "max_run_ft" (if effective (il-round-py effective 2)))
    (cons "pct_of_max" (if effective (il-round-py (/ (* 100.0 (/ length-mm *il-mm-per-ft*)) effective) 1)))
    (cons "runs_count" count)
    (cons "runs_in" (mapcar '(lambda (mm) (il-round-py (/ mm *il-mm-per-in*) 2)) runs))
  )
)

(defun il-run-watts (length-in w-per-ft)
  (il-round-py (* (/ length-in 12.0) w-per-ft) 2)
)

;; ((total_w . t) (usable_w . u) (pct_of_usable . p) (over . flag)).
(defun il-psu-load (loads rated-w factor / total usable)
  (setq total (il-sum loads) usable (* rated-w (if factor factor 1.0)))
  (list
    (cons "total_w" (il-round-py total 2))
    (cons "usable_w" (il-round-py usable 2))
    (cons "pct_of_usable" (if (> usable 0) (il-round-py (/ (* 100.0 total) usable) 1)))
    (cons "over" (> total usable))
  )
)

;; VERTICES is ((x y bulge) ...): ((length_in . l) (min_arc_radius_in . r-or-nil)).
(defun il-path-length (vertices closed / points total smallest start end chord bulge sweep radius)
  (setq points vertices total 0.0)
  (if (and closed points) (setq points (append points (list (car points)))))
  (while (cdr points)
    (setq start (car points) end (cadr points) points (cdr points))
    (setq chord (distance (list (car start) (cadr start)) (list (car end) (cadr end))))
    (setq bulge (if (caddr start) (caddr start) 0.0))
    (if (or (equal bulge 0.0 1e-12) (= chord 0))
      (setq total (+ total chord))
      (progn
        (setq sweep (* 4 (atan (abs bulge))))
        (setq radius (/ chord (* 2 (sin (/ sweep 2)))))
        (setq total (+ total (* radius sweep)))
        (setq smallest (if smallest (min smallest radius) radius))
      )
    )
  )
  (list
    (cons "length_in" (il-round-py total 4))
    (cons "min_arc_radius_in" (if smallest (il-round-py smallest 4)))
  )
)

;; Split VERTICES at the vertex indexes in BREAKS (jumpers): a list of vertex lists, one per segment.
(defun il-split-vertices (vertices breaks / segments current index)
  (setq index 0)
  (foreach vertex vertices
    (setq current (cons vertex current))
    (if (and (member index breaks) (> index 0) (< index (1- (length vertices))))
      (setq segments (cons (reverse current) segments)
            current (list (list (car vertex) (cadr vertex) (caddr vertex))))
    )
    (setq index (1+ index))
  )
  (reverse (cons (reverse current) segments))
)

;; --- Polyline editing: ILJUMPER, ILFEED, tag placement -----------------------------------------

(setq *il-two-pi* (* 8.0 (atan 1.0)))

(defun il-xy (point) (list (float (car point)) (float (cadr point))))

(defun il-bulge (vertex) (if (numberp (caddr vertex)) (caddr vertex) 0.0))

;; The arc of segment P0 -> P1 with BULGE: (center radius start-angle sweep), nil when straight.
;; A positive bulge turns counterclockwise; its center lies left of the chord.
(defun il-bulge-arc (p0 p1 bulge / dx dy chord offset center)
  (setq dx (- (car p1) (car p0)) dy (- (cadr p1) (cadr p0)) chord (sqrt (+ (* dx dx) (* dy dy))))
  (if (and (not (equal bulge 0.0 1e-12)) (> chord 0))
    (progn
      (setq offset (/ (* chord (- 1.0 (* bulge bulge))) (* 4.0 bulge)))
      (setq center (list (- (/ (+ (car p0) (car p1)) 2.0) (* offset (/ dy chord)))
                         (+ (/ (+ (cadr p0) (cadr p1)) 2.0) (* offset (/ dx chord)))))
      (list center (/ (* chord (+ 1.0 (* bulge bulge))) (* 4.0 (abs bulge)))
            (atan (- (cadr p0) (cadr center)) (- (car p0) (car center))) (* 4.0 (atan bulge)))
    )
  )
)

(defun il-arc-point (arc angle-at)
  (list (+ (car (car arc)) (* (cadr arc) (cos angle-at))) (+ (cadr (car arc)) (* (cadr arc) (sin angle-at))))
)

(defun il-segment-length (p0 p1 bulge / arc)
  (if (setq arc (il-bulge-arc p0 p1 bulge)) (* (cadr arc) (abs (cadddr arc))) (distance (il-xy p0) (il-xy p1)))
)

;; The point U (0..1) of the way along segment P0 -> P1.
(defun il-segment-point (p0 p1 bulge u / arc)
  (if (setq arc (il-bulge-arc p0 p1 bulge))
    (il-arc-point arc (+ (caddr arc) (* u (cadddr arc))))
    (list (+ (car p0) (* u (- (car p1) (car p0)))) (+ (cadr p0) (* u (- (cadr p1) (cadr p0)))))
  )
)

;; The point FRACTION (0..1) of the way along open VERTICES ((x y bulge) ...), as (x y 0.0).
(defun il-path-point (vertices fraction / lengths total target walked points index result)
  (setq points vertices)
  (while (cdr points)
    (setq lengths (cons (il-segment-length (car points) (cadr points) (il-bulge (car points))) lengths) points (cdr points))
  )
  (setq lengths (reverse lengths) total (apply '+ (cons 0.0 lengths)) target (* fraction total) walked 0.0 index 0)
  (if (or (null lengths) (<= total 0)) (setq result (il-xy (car vertices))))
  (foreach size lengths
    (if (and (null result) (or (>= (+ walked size) target) (= index (1- (length lengths)))))
      (setq result (il-segment-point (nth index vertices) (nth (1+ index) vertices) (il-bulge (nth index vertices))
                                     (if (> size 0) (min 1.0 (max 0.0 (/ (- target walked) size))) 0.0)))
    )
    (setq walked (+ walked size) index (1+ index))
  )
  (list (car result) (cadr result) 0.0)
)

;; The closest point of segment P0 -> P1 to POINT: (u point distance), U being 0..1 along it.
(defun il-segment-nearest (p0 p1 bulge point / arc dx dy size u along swept)
  (if (setq arc (il-bulge-arc p0 p1 bulge))
    (progn
      (setq along (atan (- (cadr point) (cadr (car arc))) (- (car point) (car (car arc)))))
      (setq swept (rem (- along (caddr arc)) *il-two-pi*))
      (if (> (cadddr arc) 0)
        (if (< swept 0) (setq swept (+ swept *il-two-pi*)))
        (if (> swept 0) (setq swept (- swept *il-two-pi*)))
      )
      (if (<= (abs swept) (abs (cadddr arc)))
        (setq u (/ swept (cadddr arc)))
        (setq u (if (< (distance (il-xy point) (il-xy p0)) (distance (il-xy point) (il-xy p1))) 0.0 1.0))
      )
    )
    (progn
      (setq dx (- (car p1) (car p0)) dy (- (cadr p1) (cadr p0)) size (+ (* dx dx) (* dy dy)))
      (setq u (if (> size 0) (/ (+ (* (- (car point) (car p0)) dx) (* (- (cadr point) (cadr p0)) dy)) size) 0.0))
      (setq u (min 1.0 (max 0.0 u)))
    )
  )
  (setq along (il-segment-point p0 p1 bulge u))
  (list u along (distance (il-xy point) along))
)

;; Where a picked POINT lands on open VERTICES: ("vertex" index) when it is within TOLERANCE of a vertex
;; (or its nearest point on the run is), else ("split" segment-index u point) to add a vertex exactly
;; at the nearest point on the run. TOLERANCE is small: snapped points land where they were snapped.
(defun il-jumper-target (vertices point tolerance / best best-d index d near best-seg)
  (setq index 0)
  (foreach vertex vertices
    (setq d (distance (il-xy vertex) (il-xy point)))
    (if (or (null best-d) (< d best-d)) (setq best index best-d d))
    (setq index (1+ index))
  )
  (setq index 0)
  (while (< index (1- (length vertices)))
    (setq near (il-segment-nearest (nth index vertices) (nth (1+ index) vertices) (il-bulge (nth index vertices)) point))
    (if (or (null best-seg) (< (caddr near) (caddr (cdr best-seg)))) (setq best-seg (cons index near)))
    (setq index (1+ index))
  )
  (cond
    ((or (null best-seg) (<= best-d tolerance)) (list "vertex" best))
    ((<= (distance (il-xy (caddr best-seg)) (il-xy (nth (car best-seg) vertices))) tolerance) (list "vertex" (car best-seg)))
    ((<= (distance (il-xy (caddr best-seg)) (il-xy (nth (1+ (car best-seg)) vertices))) tolerance) (list "vertex" (1+ (car best-seg))))
    (T (list "split" (car best-seg) (cadr best-seg) (caddr best-seg)))
  )
)

;; How far POINT is from the path of VERTICES (closed paths include the closing side).
(defun il-distance-to-path (vertices closed point / points best near)
  (setq points (if closed (append vertices (list (car vertices))) vertices))
  (if (null (cdr points))
    (if points (distance (il-xy (car points)) (il-xy point)))
    (progn
      (while (cdr points)
        (setq near (il-segment-nearest (car points) (cadr points) (il-bulge (car points)) point))
        (if (or (null best) (< (caddr near) best)) (setq best (caddr near)))
        (setq points (cdr points))
      )
      best
    )
  )
)

(defun il-tan (x) (/ (sin x) (cos x)))

;; VERTICES with a new vertex at U along segment INDEX (an arc splits into two arcs).
(defun il-insert-vertex (vertices index u / arc result i point)
  (setq arc (il-bulge-arc (nth index vertices) (nth (1+ index) vertices) (il-bulge (nth index vertices))))
  (setq point (il-segment-point (nth index vertices) (nth (1+ index) vertices) (il-bulge (nth index vertices)) u) i 0)
  (foreach vertex vertices
    (if (= i index)
      (setq result (cons (list (car point) (cadr point) (if arc (il-tan (/ (* (- 1.0 u) (cadddr arc)) 4.0)) 0.0))
                         (cons (list (car vertex) (cadr vertex) (if arc (il-tan (/ (* u (cadddr arc)) 4.0)) 0.0)) result)))
      (setq result (cons vertex result))
    )
    (setq i (1+ i))
  )
  (reverse result)
)

;; Break indexes after a vertex was added following INDEX.
(defun il-shift-breaks (breaks index)
  (mapcar '(lambda (b) (if (> b index) (1+ b) b)) breaks)
)

;; Open VERTICES drawn the other way: each segment keeps its arc (bulges flip sign and move along).
(defun il-reverse-vertices (vertices / reversed result index)
  (setq reversed (reverse vertices) index 0)
  (foreach vertex reversed
    (setq result (cons (list (car vertex) (cadr vertex)
                             (if (< index (1- (length reversed))) (- (il-bulge (nth (1+ index) reversed))) 0.0))
                       result)
          index (1+ index))
  )
  (reverse result)
)

(defun il-reverse-breaks (breaks count)
  (vl-sort (mapcar '(lambda (b) (- count 1 b)) breaks) '<)
)

;; Spans (segment indexes) after a vertex was added following segment INDEX: a split span is two.
(defun il-split-spans (spans index / result)
  (foreach s spans
    (cond
      ((< s index) (setq result (cons s result)))
      ((= s index) (setq result (cons (1+ s) (cons s result))))
      (T (setq result (cons (1+ s) result)))
    )
  )
  (reverse result)
)

;; Spans of open VERTICES (COUNT of them) drawn the other way.
(defun il-reverse-spans (spans count)
  (vl-sort (mapcar '(lambda (s) (- count 2 s)) spans) '<)
)

;; The segment of open VERTICES nearest POINT.
(defun il-nearest-segment (vertices point / index best best-d near)
  (setq index 0)
  (while (< index (1- (length vertices)))
    (setq near (il-segment-nearest (nth index vertices) (nth (1+ index) vertices) (il-bulge (nth index vertices)) point))
    (if (or (null best-d) (< (caddr near) best-d)) (setq best index best-d (caddr near)))
    (setq index (1+ index))
  )
  best
)

;; The run of consecutive SPANS that holds segment INDEX.
(defun il-span-group (spans index / low high result)
  (if (member index spans)
    (progn
      (setq low index high index)
      (while (member (1- low) spans) (setq low (1- low)))
      (while (member (1+ high) spans) (setq high (1+ high)))
      (while (<= low high) (setq result (cons low result) low (1+ low)))
      (reverse result)
    )
  )
)

;; The lit pieces of a run and what follows each: ((vertices jumper-p jumper-in) ...). BREAKS are
;; vertex indexes where a jumper of JUMPER-IN joins two pieces; SPANS are segment indexes drawn as
;; jumper cable, not tape, whose drawn length is that jumper's length. A span at either end of the
;; run joins nothing and is left out. A closed run is walked from its first vertex round to it.
(defun il-run-pieces (vertices closed breaks spans jumper-in / points count index items current gap result next after)
  (setq points (if (and closed vertices)
                 (append vertices (list (list (car (car vertices)) (cadr (car vertices)) 0.0)))
                 vertices))
  (setq count (length points) index 0 gap 0.0 current (list (car points)))
  (while (< index (1- count))
    (if (member index spans)
      (progn
        (if (cdr current) (setq items (cons (list "lit" (reverse current)) items)))
        (setq gap (+ gap (il-segment-length (nth index points) (nth (1+ index) points) (il-bulge (nth index points)))))
        (setq current (list (nth (1+ index) points)))
      )
      (progn
        (if (> gap 0) (setq items (cons (list "gap" gap) items) gap 0.0))
        (setq current (cons (nth (1+ index) points) current))
        (if (and (member (1+ index) breaks) (< (1+ index) (1- count)) (not (member (1+ index) spans)))
          (setq items (cons (list "break") (cons (list "lit" (reverse current)) items))
                current (list (nth (1+ index) points)))
        )
      )
    )
    (setq index (1+ index))
  )
  (if (cdr current) (setq items (cons (list "lit" (reverse current)) items)))
  (setq items (reverse items) index 0)
  (foreach item items
    (if (= (car item) "lit")
      (progn
        (setq next (nth (1+ index) items) after (nth (+ index 2) items))
        (setq result (cons (cond ((and next (= (car next) "break")) (list (cadr item) T jumper-in))
                                 ((and next (= (car next) "gap") after) (list (cadr item) T (il-round-py (cadr next) 2)))
                                 (T (list (cadr item) nil nil)))
                           result))
      )
    )
    (setq index (1+ index))
  )
  (reverse result)
)

;; --- Joining lines and arcs (ILCONVERT) ---------------------------------------------------------

;; An ARC (center, radius, start and end angle, counterclockwise) as two vertices with a bulge.
(defun il-arc-piece (center radius start end / sweep)
  (setq sweep (rem (- end start) *il-two-pi*))
  (if (<= sweep 0) (setq sweep (+ sweep *il-two-pi*)))
  (list (list (+ (car center) (* radius (cos start))) (+ (cadr center) (* radius (sin start))) (il-tan (/ sweep 4.0)))
        (list (+ (car center) (* radius (cos end))) (+ (cadr center) (* radius (sin end))) 0.0))
)

(defun il-butlast (items) (reverse (cdr (reverse items))))

(defun il-same-point (a b tolerance) (<= (distance (il-xy a) (il-xy b)) tolerance))

;; Join open PIECES (vertex lists) end to end where they meet within TOLERANCE, turning pieces round
;; as needed. Returns ((vertices . source-indexes) ...), one per chain.
(defun il-chain-pieces (pieces tolerance / left chains chain used grown index piece)
  (setq index 0)
  (foreach piece pieces (setq left (cons index left) index (1+ index)))
  (setq left (reverse left))
  (while left
    (setq chain (nth (car left) pieces) used (list (car left)) left (cdr left) grown T)
    (while grown
      (setq grown nil)
      (foreach index left
        (if (not grown)
          (progn
            (setq piece (nth index pieces))
            (cond
              ((il-same-point (last chain) (car piece) tolerance) (setq chain (append (il-butlast chain) piece) grown T))
              ((il-same-point (last chain) (last piece) tolerance) (setq chain (append (il-butlast chain) (il-reverse-vertices piece)) grown T))
              ((il-same-point (car chain) (last piece) tolerance) (setq chain (append (il-butlast piece) chain) grown T))
              ((il-same-point (car chain) (car piece) tolerance) (setq chain (append (il-butlast (il-reverse-vertices piece)) chain) grown T))
            )
            (if grown (setq used (cons index used) left (vl-remove index left)))
          )
        )
      )
    )
    (setq chains (cons (cons chain (reverse used)) chains))
  )
  (reverse chains)
)

;;; ---- il-sha256.lsp ----
;;; il-sha256.lsp -- ilLumenate CAD toolkit: SHA-256 in plain AutoLISP.
;;;
;;; The ilq/2 package carries a drawing hash ("sha256:..."), used to tell whether the drawing changed
;;; since its last import (ILCHECK, ILSTRIP). AutoLISP has no hash function, so this is FIPS 180-4
;;; on 32-bit words. Sums go through 16-bit halves so no integer ever overflows. Input is ASCII text
;;; (the model's JSON). Pure: CI checks it against Python's hashlib.

(setq *il-sha-k*
  '(1116352408 1899447441 -1245643825 -373957723 961987163 1508970993 -1841331548 -1424204075
    -670586216 310598401 607225278 1426881987 1925078388 -2132889090 -1680079193 -1046744716
    -459576895 -272742522 264347078 604807628 770255983 1249150122 1555081692 1996064986
    -1740746414 -1473132947 -1341970488 -1084653625 -958395405 -710438585 113926993 338241895
    666307205 773529912 1294757372 1396182291 1695183700 1986661051 -2117940946 -1838011259
    -1564481375 -1474664885 -1035236496 -949202525 -778901479 -694614492 -200395387 275423344
    430227734 506948616 659060556 883997877 958139571 1322822218 1537002063 1747873779
    1955562222 2024104815 -2067236844 -1933114872 -1866530822 -1538233109 -1090935817 -965641998)
)

(defun il-sha-add (a b / low high)
  (setq low (+ (logand a 65535) (logand b 65535))
        high (+ (logand (lsh a -16) 65535) (logand (lsh b -16) 65535) (lsh low -16)))
  (logior (lsh (logand high 65535) 16) (logand low 65535))
)

(defun il-sha-add-all (values / total)
  (setq total 0)
  (foreach value values (setq total (il-sha-add total value)))
  total
)

(defun il-sha-rotr (x n)
  (logior (lsh x (- n)) (lsh x (- 32 n)))
)

(defun il-sha-xor (a b) (boole 6 a b))

(defun il-sha-hex (word / text index nibble)
  (setq text "" index 7)
  (while (>= index 0)
    (setq nibble (logand (lsh word (* -4 index)) 15))
    (setq text (strcat text (substr "0123456789abcdef" (1+ nibble) 1)) index (1- index))
  )
  text
)

;; The bytes of TEXT padded to whole 64-byte blocks, as a list of 32-bit words.
(defun il-sha-words (text / bytes count index word words bits)
  (setq count (strlen text) index 1)
  (while (<= index count)
    (setq bytes (cons (logand (ascii (substr text index 1)) 255) bytes) index (1+ index))
  )
  (setq bytes (cons 128 bytes))
  (while (/= (rem (length bytes) 64) 56) (setq bytes (cons 0 bytes)))
  (setq bits (* count 8))
  ;; 64-bit big-endian length; texts stay far below 2^29 bytes, so the high word is zero.
  (setq bytes (append (list (logand bits 255) (logand (lsh bits -8) 255) (logand (lsh bits -16) 255)
                            (logand (lsh bits -24) 255) 0 0 0 0)
                      bytes))
  (setq bytes (reverse bytes))
  (while bytes
    (setq word (logior (lsh (car bytes) 24) (lsh (cadr bytes) 16) (lsh (caddr bytes) 8) (cadddr bytes)))
    (setq words (cons word words) bytes (cddddr bytes))
  )
  (reverse words)
)

(defun il-sha256 (text / h words w index a b c d e f g hh s0 s1 ch maj t1 t2 block)
  (setq h '(1779033703 -1150833019 1013904242 -1521486534 1359893119 -1694144372 528734635 1541459225))
  (setq words (il-sha-words text))
  (while words
    (setq w nil index 0)
    (repeat 16 (setq w (cons (car words) w) words (cdr words)))
    (setq w (reverse w) index 16)
    (while (< index 64)
      (setq s0 (il-sha-xor (il-sha-xor (il-sha-rotr (nth (- index 15) w) 7) (il-sha-rotr (nth (- index 15) w) 18))
                           (lsh (nth (- index 15) w) -3)))
      (setq s1 (il-sha-xor (il-sha-xor (il-sha-rotr (nth (- index 2) w) 17) (il-sha-rotr (nth (- index 2) w) 19))
                           (lsh (nth (- index 2) w) -10)))
      (setq w (append w (list (il-sha-add-all (list (nth (- index 16) w) s0 (nth (- index 7) w) s1))))
            index (1+ index))
    )
    (setq a (nth 0 h) b (nth 1 h) c (nth 2 h) d (nth 3 h) e (nth 4 h) f (nth 5 h) g (nth 6 h) hh (nth 7 h) index 0)
    (while (< index 64)
      (setq s1 (il-sha-xor (il-sha-xor (il-sha-rotr e 6) (il-sha-rotr e 11)) (il-sha-rotr e 25)))
      (setq ch (il-sha-xor (logand e f) (logand (~ e) g)))
      (setq t1 (il-sha-add-all (list hh s1 ch (nth index *il-sha-k*) (nth index w))))
      (setq s0 (il-sha-xor (il-sha-xor (il-sha-rotr a 2) (il-sha-rotr a 13)) (il-sha-rotr a 22)))
      (setq maj (il-sha-xor (il-sha-xor (logand a b) (logand a c)) (logand b c)))
      (setq t2 (il-sha-add s0 maj))
      (setq hh g g f f e e (il-sha-add d t1) d c c b b a a (il-sha-add t1 t2) index (1+ index))
    )
    (setq h (mapcar 'il-sha-add h (list a b c d e f g hh)))
  )
  (apply 'strcat (mapcar 'il-sha-hex h))
)

;;; ---- il-catalog.lsp ----
;;; il-catalog.lsp -- ilLumenate CAD toolkit: the CAD catalog (cad-catalog/1) and its lookups.
;;;
;;; The catalog is a file the dealer downloads from the portal (no network calls from AutoCAD). It
;;; holds templates, variants, profiles and run styles, never prices. Pure: CI runs it.

(setq *il-catalog* nil *il-catalog-path* nil)

(defun il-catalog-read (path / catalog)
  (setq catalog (il-json-read-file path))
  (cond
    ((null catalog) nil)
    ((/= (il-j catalog "schema") "cad-catalog/1")
      (setq *il-jr-error* "This file is not an ilLumenate CAD catalog (cad-catalog/1)")
      nil
    )
    (T catalog)
  )
)

(defun il-tape-family-p (family)
  (member family '("LED Tape" "COB Tape" "LED Neon"))
)

;; The template FAMILY/CODE offers, as its catalog object, or nil when the catalog does not offer it.
(defun il-cat-template (catalog family code / found section)
  (setq section
    (cond
      ((il-tape-family-p family) "templates")
      ((= family "Linear Fixture") "fixture_templates")
      ((= family "Extrusion Kit") "kit_templates")
    )
  )
  (if section
    (foreach item (il-items (il-j catalog section))
      (if (and (null found) (= (il-j item "code") code)
               (or (/= section "templates") (= (il-j item "family") family)))
        (setq found item)
      )
    )
  )
  found
)

(defun il-cat-profile (catalog code / found)
  (foreach item (il-items (il-j catalog "profiles"))
    (if (and (null found) (= (il-j item "code") code)) (setq found item))
  )
  found
)

(defun il-cat-style (catalog id / found)
  (foreach item (il-items (il-j catalog "styles"))
    (if (and (null found) (= (il-j item "id") id)) (setq found item))
  )
  found
)

(defun il-cat-option (template key / found)
  (foreach option (il-items (il-j template "options"))
    (if (and (null found) (= (il-j option "key") key)) (setq found option))
  )
  found
)

;; The variant matching SELECTIONS (environment, CCT, output); the template default otherwise.
(defun il-cat-variant (template selections / best best-score score default)
  (setq best-score -1)
  (foreach variant (il-items (il-j template "variants"))
    (if (= (il-j variant "id") (il-j template "default_variant")) (setq default variant))
    (setq score 0)
    (foreach key '("environment_rating" "cct" "output_level")
      (cond
        ((null (il-j selections key)))
        ((null (il-j variant key)))
        ((= (il-j selections key) (il-j variant key)) (setq score (1+ score)))
        (T (setq score -100))
      )
    )
    (if (> score best-score) (setq best variant best-score score))
  )
  (if (>= best-score 0) best default)
)

;; The tape style that carries the light: the style itself, or a kit style's tape.
(defun il-style-tape (style)
  (if (= (il-j style "family") "Extrusion Kit") (il-j style "tape") style)
)

;; The variant a style draws with (nil for linear fixtures, whose tape the configurator picks). A
;; custom style's is made from its own numbers (il-custom-variant). Every hint and check asks here.
(defun il-style-variant (catalog style / tape template)
  (if (il-custom-p style)
    (il-custom-variant style)
    (progn
      (setq tape (il-style-tape style))
      (if (and tape (il-tape-family-p (il-j tape "family")))
        (if (setq template (il-cat-template catalog (il-j tape "family") (il-j tape "template")))
          (il-cat-variant template (il-j tape "selections"))
        )
      )
    )
  )
)

;; The profile a style draws: the kit's or the linear template's default profile.
(defun il-style-profile (catalog style / template)
  (if (setq template (il-cat-template catalog (il-j style "family") (il-j style "template")))
    (if (il-j template "profile") (il-cat-profile catalog (il-j template "profile")))
  )
)

;; A short label for a style: its own label, else family and template. Custom styles say so.
(defun il-style-label (style)
  (cond
    ((il-custom-p style) (strcat (il-custom-label style) " (custom)"))
    ((il-j style "label"))
    ((il-j style "preset"))
    (T (strcat (il-j style "template") " " (il-j style "family")))
  )
)

;; What a style is: its family, or for a custom style the family it was defined as.
(defun il-style-family (style)
  (if (il-custom-p style) (il-str (il-j (il-j style "custom") "family")) (il-j style "family"))
)

;; --- Custom styles ------------------------------------------------------------------------------
;; A style the user defines in CAD without a catalog template (ILSTYLE "Custom style"): id
;; "custom:<CODE>", family "Custom", template CODE, no selections, and a "custom" object with code,
;; label, family, color and the optional w_per_ft, voltage_v, cut_in, max_run_ft, part_number, notes
;; (the ilq/2 custom style). Its numbers drive the hints and checks; on import it is mapped to a preset,
;; or becomes a custom schedule line for Sales to price.

(setq *il-custom-families* '("LED Tape" "COB Tape" "LED Neon" "Linear Fixture" "Extrusion Kit" "Other"))

;; Default colours (AutoCAD colour index) by family; they keep off red, yellow and green, which mark
;; ILCHECK states.
(setq *il-custom-colors*
  '(("LED Tape" . 30) ("COB Tape" . 40) ("LED Neon" . 6) ("Linear Fixture" . 4) ("Extrusion Kit" . 5) ("Other" . 7)))

;; The numbers a custom style may carry, as the ilq/2 schema bounds them: (key low high low-allowed).
(setq *il-custom-numbers*
  '(("w_per_ft" 0 1000 T) ("voltage_v" 0 1000 nil) ("cut_in" 0 1000 nil) ("max_run_ft" 0 10000 nil)))

;; Free text a custom style may carry, with its longest length.
(setq *il-custom-texts* '(("part_number" . 140) ("notes" . 1000)))

(defun il-custom-p (style) (= (il-j style "family") "Custom"))

(defun il-custom-label (style / label)
  (setq label (il-j (il-j style "custom") "label"))
  (cond
    ((and label (/= (il-trim label) "")) label)
    ((il-j style "label"))
    (T (il-str (il-j style "template")))
  )
)

(defun il-custom-default-color (family / color)
  (if (setq color (cdr (assoc family *il-custom-colors*))) color 7)
)

(defun il-custom-color-ok (value)
  (and (numberp value) (= value (fix value)) (>= value 1) (<= value 255))
)

;; True when VALUE is a number the schema accepts for KEY (one of *il-custom-numbers*).
(defun il-custom-number-ok (key value / row)
  (setq row (assoc key *il-custom-numbers*))
  (and row (numberp value) (<= value (caddr row))
       (if (cadddr row) (>= value (cadr row)) (> value (cadr row))))
)

;; A custom style code from LABEL: upper-case letters and digits, any other run of characters one "-",
;; at most 24 characters, starting and ending with a letter or digit ("Cove 24V 4.4 W/ft" -> "COVE-24V-4-4-W-FT").
(defun il-custom-slug (label / text index char code out)
  (setq text (strcase (il-trim label)) index 1 out "")
  (while (<= index (strlen text))
    (setq char (substr text index 1) code (ascii char) index (1+ index))
    (cond
      ((or (< 47 code 58) (< 64 code 91)) (setq out (strcat out char)))
      ((and (/= out "") (/= (substr out (strlen out) 1) "-")) (setq out (strcat out "-")))
    )
  )
  (setq out (vl-string-right-trim "-" (substr out 1 24)))
  (if (= out "") "CUSTOM" out)
)

;; The codes STYLES (the drawing's) already use: custom styles' codes and every "custom:<x>" id.
(defun il-custom-codes (styles / codes id)
  (foreach style styles
    (setq id (il-str (il-j style "id")))
    (if (il-starts-with id "custom:") (setq codes (cons (substr id 8) codes)))
    (if (il-custom-p style) (setq codes (cons (il-str (il-j style "template")) codes)))
  )
  codes
)

;; A new style's code: LABEL's slug, made unique among STYLES ("COVE", "COVE-2", ...).
(defun il-custom-new-code (label styles)
  (il-unique-id (il-custom-slug label) (il-custom-codes styles) 24)
)

;; The custom style CODE from ANSWERS (("label" . text) ("family" . f) ("color" . n) ("w_per_ft" . x) ...).
;; A blank label is the code; an unknown family is "Other"; a missing or bad colour is the family's;
;; numbers out of the schema's range and blank texts are left out; texts are cut to the schema's length.
(defun il-custom-style (code answers / family label value pairs)
  (setq family (il-get "family" answers))
  (if (not (member family *il-custom-families*)) (setq family "Other"))
  (setq label (substr (il-trim (il-get "label" answers)) 1 140))
  (if (= label "") (setq label code))
  (setq value (il-get "color" answers))
  (setq pairs (list (cons "code" code) (cons "label" label) (cons "family" family)
                    (cons "color" (if (il-custom-color-ok value) (fix value) (il-custom-default-color family)))))
  (foreach row *il-custom-numbers*
    (setq value (il-get (car row) answers))
    (if (il-custom-number-ok (car row) value) (setq pairs (append pairs (list (cons (car row) value)))))
  )
  (foreach row *il-custom-texts*
    (setq value (il-trim (il-get (car row) answers)))
    (if (/= value "") (setq pairs (append pairs (list (cons (car row) (substr value 1 (cdr row)))))))
  )
  (il-obj (list (cons "id" (strcat "custom:" code)) (cons "label" label) (cons "family" "Custom")
                (cons "template" code) (cons "selections" (il-obj nil)) (cons "custom" (il-obj pairs))))
)

;; The variant a custom style draws with: its W/ft, its cut increment in mm (free cut without one) and
;; its max run as the voltage-drop max run (il-run-split still applies the 85 W per run rule).
(defun il-custom-variant (style / custom cut)
  (setq custom (il-j style "custom") cut (il-j custom "cut_in"))
  (if (not (il-custom-number-ok "cut_in" cut)) (setq cut nil))
  (il-obj
    (list
      (cons "id" (strcat "custom:" (il-str (il-j style "template"))))
      (cons "w_per_ft" (if (il-custom-number-ok "w_per_ft" (il-j custom "w_per_ft")) (il-j custom "w_per_ft")))
      (cons "cut_mm" (if cut (* cut *il-mm-per-in*)))
      (cons "free_cut" (il-bool (null cut)))
      (cons "max_run_vd_ft" (if (il-custom-number-ok "max_run_ft" (il-j custom "max_run_ft")) (il-j custom "max_run_ft")))
      (cons "voltage_v" (if (il-custom-number-ok "voltage_v" (il-j custom "voltage_v")) (il-j custom "voltage_v")))
    )
  )
)

;; ILCHECK's note on a custom run (info: it never blocks).
(defun il-custom-issue-text (style)
  (strcat "Uses custom style " (il-custom-label style) " (" (il-str (il-j style "template"))
          "); the import maps it to a preset, or adds a custom line for Sales to price")
)

;; The colour (AutoCAD colour index) of a run of STYLE in STATE ("error", "warning", "imported", "ok"):
;; red and yellow for problems; else a custom style's own colour, green, or ByLayer once imported.
(defun il-run-color (state style / color)
  (if (il-custom-p style)
    (setq color (il-j (il-j style "custom") "color")
          color (if (il-custom-color-ok color) (fix color) (il-custom-default-color (il-style-family style))))
  )
  (cond
    ((= state "error") 1)
    ((= state "warning") 2)
    (color color)
    ((= state "imported") 256)
    (T 3)
  )
)

;; Days between two "YYYY-MM-DD..." dates (approximate: 365-day years, 30.4-day months are fine
;; for a 30-day staleness warning).
(defun il-day-number (text)
  (+ (* 365.25 (atoi (substr text 1 4))) (* 30.44 (atoi (substr text 6 2))) (atoi (substr text 9 2)))
)

(defun il-days-between (from to)
  (fix (- (il-day-number to) (il-day-number from)))
)

;; A staleness warning, or nil. TODAY is "YYYY-MM-DD".
(defun il-catalog-stale (catalog today / days limit)
  (setq limit (il-jp catalog '("settings" "stale_days")))
  (if (null limit) (setq limit 30))
  (if (il-j catalog "generated_at")
    (progn
      (setq days (il-days-between (il-j catalog "generated_at") today))
      (if (> days limit)
        (strcat "The CAD catalog is " (itoa days) " days old; download the current one from the portal")
      )
    )
  )
)

;; A warning when the catalog asks for a newer toolkit (settings.min_toolkit_version), or nil.
(defun il-toolkit-outdated (catalog / minimum)
  (setq minimum (il-jp catalog '("settings" "min_toolkit_version")))
  (if (and minimum (/= (il-str minimum) "") (il-version< *il-version* (il-str minimum)))
    (strcat "This CAD toolkit is " *il-version* "; the catalog needs " (il-str minimum)
            " or newer. Download the current toolkit from the portal Resources page")
  )
)

;;; ---- il-model.lsp ----
;;; il-model.lsp -- ilLumenate CAD toolkit: the drawing model, hints, ILCHECK rules, the ilq/2
;;; package and the import receipt. Pure: the AutoCAD commands collect the model from entities
;;; (il-commands.lsp) and CI runs everything here against the shared fixtures.
;;;
;;; Model: an association list with "drawing", "rooms", "cabinets", "runs", "styles", "psus",
;;; "wires", "controls", "zones", "others" and "overrides". A run is an association list ("id" "handle" "fixture_type"
;;; "room" "location" "style" "vertices" "closed" "breaks" "spans" "start_feed" "lead_in" "jumper_in"
;;; "feed_method" "feed_handles" "cabinet" "psu_hint" "notes" "line_key" "configured_name"
;;; "config_hash" "layout" ...). Styles are catalog style objects (IL-OBJ) with an "id". Runs and rooms
;;; carry the layout that owns them (DXF group 410; nil reads as model space).

(setq *il-package-schema* "ilq/2")
(setq *il-length-tolerance* 0.05)

(defun il-model-style (model id / found)
  (foreach style (il-get "styles" model)
    (if (and (null found) (= (il-j style "id") id)) (setq found style))
  )
  found
)

;; --- Geometry and hints -----------------------------------------------------------------------

;; ((segments . (path-result ...)) (length_in . total) (min_arc_radius_in . r))
;; ((segments . (path-result ...)) (length_in . total) (min_arc_radius_in . r)). Each segment is a lit
;; piece of the run with "jumper" (a jumper follows it) and "jumper_in" (its length when known).
(defun il-run-geometry (run / results total smallest result)
  (setq total 0.0)
  (foreach piece (il-run-pieces (il-get "vertices" run) (il-get "closed" run) (il-get "breaks" run) (il-get "spans" run) (il-get "jumper_in" run))
    (setq result (append (il-path-length (car piece) nil) (list (cons "jumper" (cadr piece)) (cons "jumper_in" (caddr piece)))))
    (setq results (cons result results) total (+ total (il-get "length_in" result)))
    (if (il-get "min_arc_radius_in" result)
      (setq smallest (if smallest (min smallest (il-get "min_arc_radius_in" result)) (il-get "min_arc_radius_in" result)))
    )
  )
  (list (cons "segments" (reverse results)) (cons "length_in" (il-round-py total 4)) (cons "min_arc_radius_in" smallest))
)

;; What the run tag and the live readout show: drawn and snapped length, watts, % of max run, splits.
(defun il-run-hint (run style catalog / geometry variant snapped cut free split watts)
  (setq geometry (il-run-geometry run) variant (if style (il-style-variant catalog style)))
  (setq snapped 0.0)
  (if variant
    (progn
      (setq cut (il-j variant "cut_mm") free (il-true-p (il-j variant "free_cut")))
      (foreach segment (il-get "segments" geometry)
        (setq snapped (+ snapped (il-get "mfg_in" (il-cut-snap (il-get "length_in" segment) cut free))))
      )
      (setq split (il-run-split snapped (il-j variant "w_per_ft") cut free (il-j variant "max_run_vd_ft") nil))
      (setq watts (if (il-j variant "w_per_ft") (il-run-watts snapped (il-j variant "w_per_ft"))))
    )
    (setq snapped (il-get "length_in" geometry))
  )
  (list
    (cons "length_in" (il-get "length_in" geometry))
    (cons "snapped_in" (il-round-py snapped 2))
    (cons "segments" (length (il-get "segments" geometry)))
    (cons "min_arc_radius_in" (il-get "min_arc_radius_in" geometry))
    (cons "watts" watts)
    (cons "max_run_ft" (il-get "max_run_ft" split))
    (cons "pct_of_max" (il-get "pct_of_max" split))
    (cons "runs_count" (if split (il-get "runs_count" split) 1))
    (cons "runs_in" (il-get "runs_in" split))
    (cons "variant" variant)
  )
)

;; "120.25 in (10'-0 1/4\") 44.1 W 54% max" for the readout and the run tag.
(defun il-hint-text (hint / text)
  (setq text (strcat (il-num->str (il-get "snapped_in" hint) 2) " in"))
  (if (il-get "watts" hint) (setq text (strcat text "  " (il-num->str (il-get "watts" hint) 1) " W")))
  (if (il-get "pct_of_max" hint) (setq text (strcat text "  " (il-num->str (il-get "pct_of_max" hint) 0) "% max")))
  (if (> (il-get "runs_count" hint) 1) (setq text (strcat text "  splits x" (itoa (il-get "runs_count" hint)))))
  text
)

;; --- ILCHECK (geometry checks; the engine and the configurators check the rest on import) -------

(defun il-issue (code ref severity text)
  (list (cons "code" code) (cons "ref" ref) (cons "severity" severity) (cons "text" text))
)

(defun il-overridden-p (issue overrides / found)
  (foreach override overrides
    (if (and (= (il-get "code" override) (il-get "code" issue)) (= (il-get "ref" override) (il-get "ref" issue)))
      (setq found T)
    )
  )
  found
)

(defun il-psu-runs (model psu-id / found)
  (foreach psu (il-get "psus" model)
    (if (= (il-get "id" psu) psu-id) (setq found (il-get "runs" psu)))
  )
  found
)

(defun il-run-fed-p (model run-id / fed)
  (foreach psu (il-get "psus" model)
    (if (member run-id (il-get "runs" psu)) (setq fed T))
  )
  (foreach wire (il-get "wires" model)
    (if (or (= (il-get "to" wire) run-id) (= (il-get "from" wire) run-id)) (setq fed T))
  )
  fed
)

;; Adds to the ISSUES list of the il-check call running (AutoLISP variables are dynamically scoped).
(defun il-add (code ref severity text)
  (setq issues (cons (il-issue code ref severity text) issues))
)

;; The length hints of run ID (cut snap, over the max run with an end feed), added like il-add.
(defun il-add-hint-issues (run id hint)
  (if (> (abs (- (il-get "length_in" hint) (il-get "snapped_in" hint))) *il-length-tolerance*)
    (il-add "CUT_SNAP" id "info"
      (strcat "Builds " (il-num->str (il-get "snapped_in" hint) 2) " in for "
              (il-num->str (il-get "length_in" hint) 2) " in drawn (cut increment)"))
  )
  (if (and (> (il-get "runs_count" hint) 1) (= (il-get "feed_method" run) "end"))
    (il-add "TAPE_RUN_TOO_LONG" id "warning"
      (strcat "Over the " (il-num->str (il-get "max_run_ft" hint) 1) " ft max run; the build splits into "
              (itoa (il-get "runs_count" hint)) " runs. Choose double-end or center feed, or accept the split"))
  )
)

;; Every issue in the drawing: ((code ref severity text) ...). TODAY is "YYYY-MM-DD".
(defun il-check (model catalog today / issues ids id run style template profile hint variant
                                       stale ends tape-width loads driver over)
  (if (null catalog)
    (il-add "CATALOG_MISSING" "drawing" "error" "Load the CAD catalog (ILCATALOG) before checking")
  )
  (if (and catalog (setq stale (il-catalog-stale catalog today)))
    (il-add "CATALOG_STALE" "drawing" "warning" stale)
  )
  (if (and catalog (setq stale (il-toolkit-outdated catalog)))
    (il-add "TOOLKIT_OUTDATED" "drawing" "warning" stale)
  )
  (if (not (il-true-p (il-bool (il-get "scale_verified" (il-get "drawing" model)))))
    (il-add "SCALE_UNVERIFIED" "drawing" "warning" "Calibrate the underlay scale with ILSCALE")
  )
  (foreach run (il-get "runs" model)
    (setq id (il-get "id" run))
    (cond
      ((or (null id) (= id "")) (il-add "RUN_MISSING_ID" (il-get "handle" run) "error" "Run has no ID; run ILUPDATE"))
      ((member id ids) (il-add "RUN_DUPLICATE_ID" id "error" (strcat "Two runs are tagged " id "; run ILUPDATE to renumber copies")))
      (T (setq ids (cons id ids)))
    )
    (if (or (null (il-get "fixture_type" run)) (= (il-get "fixture_type" run) ""))
      (il-add "RUN_MISSING_TYPE" (if id id (il-get "handle" run)) "error" "Run has no schedule Type")
    )
    (if (null (il-get "room" run)) (il-add "RUN_NO_ROOM" id "warning" "Run is not in a room (ILROOM)"))
    (if (null (il-get "segments" (il-run-geometry run)))
      (il-add "RUN_NO_TAPE" id "error" "The whole run is marked as jumper span; take a span off with ILJUMPER")
    )
    (if (and (il-get "spans" run) (not (il-get "closed" run))
             (or (member 0 (il-get "spans" run)) (member (- (length (il-get "vertices" run)) 2) (il-get "spans" run))))
      (il-add "JUMPER_SPAN_AT_END" id "warning" "A jumper span at the run's end joins nothing and is left out; trim it, or count it in the lead (ILFEED)")
    )
    (setq style (il-model-style model (il-get "style" run)))
    (cond
      ((null style) (il-add "RUN_NO_STYLE" id "error" "Run has no style (ILSTYLE)"))
      ;; A custom style has no template, bend radius, profile or tape width to check: only its own
      ;; numbers' length hints, and a note that the import maps or prices it.
      ((il-custom-p style)
        (il-add "CUSTOM_STYLE" id "info" (il-custom-issue-text style))
        (il-add-hint-issues run id (il-run-hint run style catalog))
      )
      ((and catalog (null (setq template (il-cat-template catalog (il-j style "family") (il-j style "template")))))
        (il-add "TEMPLATE_DISCONTINUED" id "error" (strcat (il-j style "template") " is not in the current catalog"))
      )
      ((and catalog (= (il-j style "family") "Extrusion Kit")
            (null (il-cat-template catalog (il-j (il-j style "tape") "family") (il-j (il-j style "tape") "template"))))
        (il-add "TEMPLATE_DISCONTINUED" id "error" (strcat (il-j (il-j style "tape") "template") " is not in the current catalog"))
      )
      (catalog
        (setq hint (il-run-hint run style catalog) variant (il-get "variant" hint))
        (il-add-hint-issues run id hint)
        (if (and variant (il-j variant "min_bend_radius_in") (il-get "min_arc_radius_in" hint)
                 (< (il-get "min_arc_radius_in" hint) (il-j variant "min_bend_radius_in")))
          (il-add "BEND_RADIUS" id "error"
            (strcat "Arc radius " (il-num->str (il-get "min_arc_radius_in" hint) 2) " in is under the tape's "
                    (il-num->str (il-j variant "min_bend_radius_in") 2) " in minimum"))
        )
        (setq profile (il-style-profile catalog style))
        (if (and profile (il-get "min_arc_radius_in" hint) (not (il-true-p (il-j profile "curve_capable"))))
          (il-add "PROFILE_NOT_CURVE_CAPABLE" id "error" (strcat (il-j profile "code") " cannot follow a curve"))
        )
        (setq tape-width (if variant (il-j variant "width_in")))
        (if (and profile tape-width (il-j profile "width_in") (> tape-width (il-j profile "width_in")))
          (il-add "TAPE_WIDER_THAN_PROFILE" id "error"
            (strcat "Tape is " (il-num->str tape-width 3) " in wide; " (il-j profile "code") " fits "
                    (il-num->str (il-j profile "width_in") 3) " in"))
        )
      )
    )
    (if (and id (not (il-run-fed-p model id)) (null (il-get "cabinet" run)))
      (il-add "RUN_UNCONNECTED" id "warning" "Run has no supply location (ILCONNECT or ILWIRE)")
    )
  )
  (setq ends (append ids (mapcar '(lambda (x) (il-get "id" x)) (il-get "psus" model))
                     (mapcar '(lambda (x) (il-get "id" x)) (il-get "controls" model))
                     (mapcar '(lambda (x) (il-get "id" x)) (il-get "cabinets" model))))
  (foreach wire (il-get "wires" model)
    (foreach end (list (il-get "from" wire) (il-get "to" wire))
      (if (not (member end ends)) (il-add "WIRE_UNKNOWN_END" (il-get "id" wire) "error" (strcat "Wire end " (il-str end) " is not a run, PSU or cabinet")))
    )
  )
  ;; Provisional PSU load (the designer sizes and assigns; this is only the tag's hint).
  (foreach psu (il-get "psus" model)
    (setq driver nil)
    (if (and catalog (il-get "item_code" psu))
      (foreach item (il-items (il-j catalog "drivers"))
        (if (= (il-j item "code") (il-get "item_code" psu)) (setq driver item))
      )
    )
    (if (and driver (il-j driver "rated_w"))
      (progn
        (setq loads nil)
        (foreach run (il-get "runs" model)
          (if (member (il-get "id" run) (il-get "runs" psu))
            (progn
              (setq hint (il-run-hint run (il-model-style model (il-get "style" run)) catalog))
              (if (il-get "watts" hint) (setq loads (cons (il-get "watts" hint) loads)))
            )
          )
        )
        (setq over (il-psu-load loads (il-j driver "rated_w") (il-j driver "usable_load_factor")))
        (if (il-get "over" over)
          (il-add "PSU_OVERLOAD" (il-get "id" psu) "warning"
            (strcat (il-num->str (il-get "total_w" over) 1) " W on " (il-num->str (il-get "usable_w" over) 1)
                    " W usable; the System Designer will reassign outputs"))
        )
      )
    )
  )
  (append (reverse issues) (il-check-controls model catalog))
)

;; (errors warnings): issues an override covers do not count.
(defun il-issue-counts (issues overrides / errors warnings)
  (setq errors 0 warnings 0)
  (foreach issue issues
    (if (not (il-overridden-p issue overrides))
      (cond
        ((= (il-get "severity" issue) "error") (setq errors (1+ errors)))
        ((= (il-get "severity" issue) "warning") (setq warnings (1+ warnings)))
      )
    )
  )
  (list errors warnings)
)

;; --- Sheets -------------------------------------------------------------------------------------

;; A CadId for a layout name (^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$): other characters become one "-",
;; leading and trailing punctuation goes, at most 40 characters. Model space (nil) is "Model".
(defun il-sheet-slug (layout / text index char code out)
  (setq text (if (and layout (/= (il-trim layout) "")) (il-trim layout) "Model") index 1 out "")
  (while (<= index (strlen text))
    (setq char (substr text index 1) code (ascii char) index (1+ index))
    (cond
      ((or (< 47 code 58) (< 64 code 91) (< 96 code 123) (member char '("." "_" "-"))) (setq out (strcat out char)))
      ((and (/= out "") (/= (substr out (strlen out) 1) "-")) (setq out (strcat out "-")))
    )
  )
  (while (and (/= out "") (member (substr out 1 1) '("." "_" "-"))) (setq out (substr out 2)))
  (setq out (vl-string-right-trim "._-" (substr out 1 40)))
  (if (= out "") "Sheet" out)
)

;; SLUG made unique among USED ids: "Level-1", then "Level-1-2", "Level-1-3" (kept within 40 characters).
(defun il-unique-slug (slug used) (il-unique-id slug used 40))

;; The layout a run or room is on: its "layout", model space when it has none.
(defun il-item-layout (item / layout)
  (setq layout (il-get "layout" item))
  (if (and layout (/= (il-trim layout) "")) layout "Model")
)

;; The model's sheets: one per layout that owns a run, in the order the runs first use them, as
;; ((("layout" . name) ("id" . cad-id) ("label" . name)) ...).
(defun il-model-sheets (model / sheets layout ids id)
  (foreach run (il-get "runs" model)
    (setq layout (il-item-layout run))
    (if (null (il-sheet-for sheets layout))
      (setq id (il-unique-slug (il-sheet-slug layout) ids) ids (cons id ids)
            sheets (append sheets (list (list (cons "layout" layout) (cons "id" id) (cons "label" (substr layout 1 120))))))
    )
  )
  sheets
)

;; The sheet id of LAYOUT among SHEETS (nil when no run is on it).
(defun il-sheet-for (sheets layout / found)
  (foreach sheet sheets
    (if (and (null found) (= (il-get "layout" sheet) layout)) (setq found (il-get "id" sheet)))
  )
  found
)

;; How far the sheets' scale can be trusted: ILSCALE calibrated it ("verified"), or only the drawing's
;; units say it ("declared"; an AutoCAD drawing always has units).
(defun il-scale-status (drawing)
  (if (il-true-p (il-bool (il-get "scale_verified" drawing))) "verified" "declared")
)

(defun il-package-sheets (sheets drawing / status)
  (setq status (il-scale-status drawing))
  (il-arr (mapcar '(lambda (sheet)
                     (il-obj (list (cons "id" (il-get "id" sheet)) (cons "label" (il-get "label" sheet))
                                   (cons "scale" (il-obj (list (cons "status" status) (cons "unit" "in")))))))
                  sheets))
)

;; --- ilq/2 package ----------------------------------------------------------------------------

(defun il-opt (key value pairs)
  (if (and value (/= value "")) (append pairs (list (cons key value))) pairs)
)

;; A custom style's definition as the package carries it: il-custom-style's, so a hand-edited or old
;; stored definition is cleaned the same way (the code is the style's template).
(defun il-package-custom (style)
  (il-j (il-custom-style (il-str (il-j style "template")) (cdr (il-j style "custom"))) "custom")
)

(defun il-package-style (style / pairs tape)
  (setq pairs nil)
  (if (il-custom-p style)
    (setq style (il-obj (list (cons "family" "Custom") (cons "template" (il-j style "template"))
                              (cons "custom" (il-package-custom style)))))
  )
  (if (il-starts-with (il-str (il-j style "id")) "preset:")
    (setq pairs (list (cons "preset" (il-style-label style))))
  )
  (setq pairs (append pairs (list (cons "family" (il-j style "family")) (cons "template" (il-j style "template"))
                                  (cons "selections" (if (il-j style "selections") (il-j style "selections") (il-obj nil))))))
  (if (il-j style "segments") (setq pairs (append pairs (list (cons "segments" (il-j style "segments"))))))
  (if (setq tape (il-j style "tape"))
    (setq pairs (append pairs (list (cons "tape" (il-obj (list (cons "family" (il-j tape "family"))
                                                               (cons "template" (il-j tape "template"))
                                                               (cons "selections" (if (il-j tape "selections") (il-j tape "selections") (il-obj nil))))))))))
  (if (il-j style "custom") (setq pairs (append pairs (list (cons "custom" (il-j style "custom"))))))
  (il-obj pairs)
)

(defun il-package-segments (run / geometry results index count pairs)
  (setq geometry (il-run-geometry run) results (il-get "segments" geometry) index 0 count (length results))
  (mapcar
    '(lambda (segment / pairs)
       (setq pairs (list (cons "path_length_in" (il-get "length_in" segment))))
       (if (= index 0)
         (setq pairs (il-opt "start_feed" (il-get "start_feed" run) pairs)
               pairs (if (il-get "lead_in" run) (append pairs (list (cons "lead_length_in" (il-get "lead_in" run)))) pairs))
       )
       (setq pairs (append pairs (list (cons "end_type" (if (and (< index (1- count)) (il-get "jumper" segment)) "JUMPER" "ENDCAP")))))
       (if (and (< index (1- count)) (il-get "jumper" segment) (il-get "jumper_in" segment))
         (setq pairs (append pairs (list (cons "jumper_length_in" (il-get "jumper_in" segment)))))
       )
       (if (il-get "min_arc_radius_in" segment)
         (setq pairs (append pairs (list (cons "min_arc_radius_in" (il-get "min_arc_radius_in" segment)))))
       )
       (setq index (1+ index))
       (il-obj pairs)
     )
    results
  )
)

;; SHEETS: il-model-sheets of MODEL.
(defun il-package-run (model run sheets / pairs erp)
  (setq pairs (list (cons "id" (il-get "id" run)) (cons "handle" (il-get "handle" run)) (cons "identity" "xdata")))
  (setq pairs (il-opt "sheet" (il-sheet-for sheets (il-item-layout run)) pairs))
  (setq pairs (il-opt "room" (il-get "room" run) pairs))
  (setq pairs (append pairs (list (cons "fixture_type" (il-get "fixture_type" run)))))
  (setq pairs (il-opt "location" (il-get "location" run) pairs))
  (setq pairs (append pairs
    (list
      (cons "style" (il-package-style (il-model-style model (il-get "style" run))))
      (cons "segments" (il-arr (il-package-segments run)))
      (cons "feed" (il-obj (list (cons "method" (if (il-get "feed_method" run) (il-get "feed_method" run) "end"))
                                 (cons "point_handles" (il-arr (il-get "feed_handles" run))))))
    )))
  (setq pairs (il-opt "cabinet" (il-get "cabinet" run) pairs))
  (setq pairs (il-opt "psu_hint" (il-get "psu_hint" run) pairs))
  (setq pairs (il-opt "notes" (il-get "notes" run) pairs))
  (setq erp (il-opt "line_key" (il-get "line_key" run) nil))
  (setq erp (il-opt "configured_name" (il-get "configured_name" run) erp))
  (setq erp (il-opt "config_hash" (il-get "config_hash" run) erp))
  (il-obj (append pairs (list (cons "erp" (il-obj erp)))))
)

;; The ilq/2 package for MODEL. ISSUES are il-check's result; PLATFORM names the AutoCAD product.
;; Each layout with runs is a sheet; runs and rooms name theirs (a room only when its layout has runs).
(defun il-package (model catalog issues platform / drawing counts overrides sheets)
  (setq drawing (il-get "drawing" model) overrides (il-get "overrides" model) sheets (il-model-sheets model))
  (setq counts (il-issue-counts issues overrides))
  (il-obj
    (list
      (cons "schema" *il-package-schema*)
      (cons "toolkit" (il-obj (list (cons "version" *il-version*) (cons "platform" platform))))
      (cons "source" (il-obj (list (cons "tool" "autocad") (cons "version" *il-version*) (cons "platform" platform)
                                   (cons "input" "ilq"))))
      (cons "sheets" (il-package-sheets sheets drawing))
      (cons "catalog" (il-obj (list (cons "snapshot_hash" (il-j catalog "snapshot_hash"))
                                    (cons "hash" (il-j catalog "hash"))
                                    (cons "generated_at" (il-str (il-j catalog "generated_at"))))))
      (cons "target" (il-obj (list (cons "schedule" (il-str (il-get "schedule" drawing)))
                                   (cons "schedule_version" (if (il-get "schedule_version" drawing) (il-get "schedule_version" drawing) 0))
                                   (cons "project" (il-str (il-get "project" drawing))))))
      (cons "drawing" (il-obj (list (cons "file" (il-get "file" drawing))
                                    (cons "rev" (if (il-get "rev" drawing) (il-get "rev" drawing) 0))
                                    (cons "hash" (il-get "hash" drawing))
                                    (cons "units" "in")
                                    (cons "scale_verified" (il-bool (il-get "scale_verified" drawing))))))
      (cons "rooms" (il-arr (mapcar '(lambda (room)
                                       (il-obj (il-opt "sheet" (il-sheet-for sheets (il-item-layout room))
                                                 (list (cons "id" (il-get "id" room)) (cons "name" (il-get "name" room))
                                                       (cons "level" (il-str (il-get "level" room)))
                                                       (cons "env" (if (il-get "env" room) (il-get "env" room) "dry-concealed"))))))
                                    (il-get "rooms" model))))
      (cons "cabinets" (il-arr (mapcar '(lambda (cabinet)
                                          (il-obj (il-opt "room" (il-get "room" cabinet)
                                                    (list (cons "id" (il-get "id" cabinet))
                                                          (cons "location_rating" (if (il-get "location_rating" cabinet) (il-get "location_rating" cabinet) "Dry"))
                                                          (cons "access_note" (il-str (il-get "access_note" cabinet)))))))
                                       (il-get "cabinets" model))))
      (cons "runs" (il-arr (mapcar '(lambda (run) (il-package-run model run sheets)) (il-get "runs" model))))
      (cons "psus" (il-arr (mapcar '(lambda (psu)
                                      (il-obj (il-opt "item_code" (il-get "item_code" psu)
                                                (il-opt "cabinet" (il-get "cabinet" psu)
                                                  (list (cons "id" (il-get "id" psu))
                                                        (cons "runs" (il-arr (il-get "runs" psu))))))))
                                   (il-get "psus" model))))
      (cons "wire_paths" (il-arr (mapcar '(lambda (wire)
                                            (il-obj (list (cons "id" (il-get "id" wire)) (cons "from" (il-get "from" wire))
                                                          (cons "to" (il-get "to" wire)) (cons "kind" (il-get "kind" wire))
                                                          (cons "path_length_in" (il-get "length_in" wire)))))
                                         (il-get "wires" model))))
      (cons "check" (il-obj (list (cons "errors" (car counts)) (cons "warnings" (cadr counts))
                                  (cons "overrides" (il-arr (mapcar '(lambda (o)
                                                                       (il-obj (list (cons "code" (il-get "code" o)) (cons "ref" (il-get "ref" o))
                                                                                     (cons "note" (il-get "note" o)))))
                                                                    overrides))))))
      (cons "controls" (il-package-controls model))
      (cons "zones" (il-package-zones model))
      (cons "other_lines" (il-arr (il-get "others" model)))
    )
  )
)

;; What the drawing's content hash covers: the package without who wrote it, when, the drawing's
;; file, scale and check state, the catalog, or the sheets (layout names and scale status are not what
;; was drawn, and leaving them out keeps hashes from 0.4.x toolkits stable).
(defun il-package-content (package / strip)
  (setq strip '(("runs" "sheet" "identity") ("rooms" "sheet")))
  (il-obj
    (mapcar
      '(lambda (pair)
         (if (assoc (car pair) strip)
           (cons (car pair)
                 (il-arr (mapcar '(lambda (item)
                                    (il-obj (vl-remove-if '(lambda (field) (member (car field) (cdr (assoc (car pair) strip)))) (cdr item))))
                                 (il-items (cdr pair)))))
           pair
         )
       )
      (vl-remove-if '(lambda (pair) (member (car pair) '("toolkit" "source" "drawing" "check" "catalog" "sheets"))) (cdr package))
    )
  )
)

;; The drawing's content hash: what was drawn, not when or by whom.
(defun il-model-hash (model catalog)
  (il-sha256 (il-json-text (il-package-content (il-package model catalog nil "hash"))))
)

;; --- Receipt (ilq-receipt/1) ------------------------------------------------------------------

;; ((run-id . receipt-run-object) ...) from a receipt the portal wrote.
(defun il-receipt-index (receipt)
  (if (= (il-j receipt "schema") "ilq-receipt/1")
    (mapcar '(lambda (run) (cons (il-j run "id") run)) (il-items (il-j receipt "runs")))
  )
)

;; ((control-id . line-key) ...) from a receipt (controls in v1).
(defun il-receipt-controls (receipt)
  (if (= (il-j receipt "schema") "ilq-receipt/1")
    (mapcar '(lambda (pair) (cons (car pair) (cdr pair))) (cdr (il-j receipt "controls")))
  )
)

;; The run with the receipt's ERP keys, part number and server length stamped on it.
(defun il-run-with-receipt (run index / entry)
  (if (setq entry (cdr (assoc (il-get "id" run) index)))
    (progn
      (foreach key '("line_key" "configured_name" "config_hash" "part_number")
        (setq run (il-put key (il-j entry key) run))
      )
      (il-put "server_in" (il-j entry "server_length_in") run)
    )
    run
  )
)

;;; ---- il-controls.lsp ----
;;; il-controls.lsp -- ilLumenate CAD toolkit: controls in v1 (PRD question 7). Pure: CI runs it.
;;;
;;; Controls are placed in the drawing (ILCTRL) and runs are grouped into zones dimmed by a control
;;; output (ILZONE). The drawing carries what was placed and grouped; the System Designer assigns
;;; outputs, derives control links, exports the DMX patch and checks the system. These are hints:
;;; DMX footprints and address overlaps, a zone's protocol against its control port, data length.
;;;
;;; Model keys: "controls" -- ((id handle item_code cabinet room universe start control_from notes
;;; line_key) ...), start a number or "auto"; "zones" -- ((id name method control port runs) ...).

;; Zone method -> the control protocol a port must send (as the designer's ZONE_CONTROL_PROTOCOL).
(setq *il-zone-protocols*
  '(("DMX512" "DMX512") ("CRMX-wireless" "CRMX-wireless") ("0-10V" "0-10V") ("DALI-2" "DALI-2")
    ("Lutron-QS" "Lutron-QS") ("Lutron-EcoSystem" "Lutron-EcoSystem")
    ("phase-forward" "phase-forward") ("phase-reverse" "phase-reverse"))
)
(setq *il-zone-methods*
  '("DMX512" "CRMX-wireless" "0-10V" "DALI-2" "Lutron-QS" "Lutron-EcoSystem" "phase-forward" "phase-reverse" "none"))

(defun il-cat-control (catalog code / found)
  (foreach item (il-items (il-j catalog "controllers"))
    (if (and (null found) (= (il-j item "code") code)) (setq found item))
  )
  found
)

(defun il-control-port (control-item port-name / found)
  (foreach port (il-items (il-j control-item "ports"))
    (if (and (null found) (= (il-j port "name") port-name)) (setq found port))
  )
  found
)

;; Output ports (not "in") of a catalog control, as names.
(defun il-control-outputs (control-item / names)
  (foreach port (il-items (il-j control-item "ports"))
    (if (/= (il-j port "direction") "in") (setq names (cons (il-j port "name") names)))
  )
  (reverse names)
)

(defun il-model-control (model id / found)
  (foreach control (il-get "controls" model)
    (if (and (null found) (= (il-get "id" control) id)) (setq found control))
  )
  found
)

(defun il-control-footprint (catalog control / item footprint)
  (setq item (il-cat-control catalog (il-get "item_code" control)))
  (setq footprint (if item (il-j item "dmx_footprint")))
  (if (and footprint (> footprint 0)) footprint 1)
)

(defun il-receives-dmx (catalog control / item)
  (setq item (il-cat-control catalog (il-get "item_code" control)))
  (and item (il-true-p (il-j item "receives_dmx")))
)

;; The DMX patch preview: ((universe id start end auto-flag) ...) sorted by universe and start.
;; Fixed addresses keep theirs; "auto" receivers take the next free block, in id order.
(defun il-dmx-patch (model catalog / receivers universes rows used start footprint universe placed)
  (foreach control (il-get "controls" model)
    (if (il-receives-dmx catalog control) (setq receivers (cons control receivers)))
  )
  (setq receivers (vl-sort receivers '(lambda (a b) (< (il-get "id" a) (il-get "id" b)))))
  (foreach control receivers
    (setq universe (if (il-get "universe" control) (il-get "universe" control) 1))
    (if (not (member universe universes)) (setq universes (cons universe universes)))
  )
  (foreach universe (vl-sort universes '<)
    (setq used nil placed nil)
    (foreach control receivers
      (if (and (= (if (il-get "universe" control) (il-get "universe" control) 1) universe)
               (numberp (il-get "start" control)))
        (progn
          (setq start (il-get "start" control) footprint (il-control-footprint catalog control))
          (setq used (cons (list start (+ start footprint -1)) used))
          (setq placed (cons (list universe (il-get "id" control) start (+ start footprint -1) nil) placed))
        )
      )
    )
    (foreach control receivers
      (if (and (= (if (il-get "universe" control) (il-get "universe" control) 1) universe)
               (not (numberp (il-get "start" control))))
        (progn
          (setq footprint (il-control-footprint catalog control) start 1)
          (while (vl-some '(lambda (block) (and (<= start (cadr block)) (>= (+ start footprint -1) (car block)))) used)
            (setq start (1+ (apply 'max (mapcar 'cadr (vl-remove-if-not '(lambda (block) (and (<= start (cadr block)) (>= (+ start footprint -1) (car block)))) used)))))
          )
          (setq used (cons (list start (+ start footprint -1)) used))
          (setq placed (cons (list universe (il-get "id" control) start (+ start footprint -1) T) placed))
        )
      )
    )
    (setq rows (append rows (vl-sort placed '(lambda (a b) (< (caddr a) (caddr b))))))
  )
  rows
)

;; Control issues, appended by il-check: ((code ref severity text) ...).
(defun il-check-controls (model catalog / issues ids item zoned control port protocol wanted patch wire limit source)
  (foreach control (il-get "controls" model)
    (setq ids (cons (il-get "id" control) ids))
    (setq item (if catalog (il-cat-control catalog (il-get "item_code" control))))
    (cond
      ((and catalog (null item))
        (il-add "CONTROL_UNKNOWN" (il-get "id" control) "error"
          (strcat (il-str (il-get "item_code" control)) " is not a control in the current catalog")))
      ((and (il-receives-dmx catalog control) (null (il-get "control_from" control))
            (not (vl-some '(lambda (w) (member (il-get "id" control) (list (il-get "from" w) (il-get "to" w)))) (il-get "wires" model))))
        (il-add "CONTROL_NO_SIGNAL" (il-get "id" control) "warning" "Decoder has no DMX source: set its controller or draw a data wire (ILWIRE)"))
    )
    (if (and (setq source (il-get "control_from" control)) (null (il-model-control model source)))
      (il-add "CONTROL_UNKNOWN_SOURCE" (il-get "id" control) "error" (strcat "Signal source " source " is not a control"))
    )
  )
  ;; DMX: addresses inside 1-512, no overlaps, no full universes.
  (if catalog
    (progn
      (setq patch (il-dmx-patch model catalog))
      (foreach row patch
        (if (> (nth 3 row) 512)
          (il-add "DMX_UNIVERSE_FULL" (nth 1 row) "error"
            (strcat "Needs channels " (itoa (nth 2 row)) "-" (itoa (nth 3 row)) " in universe " (itoa (car row)) " (512 max)")))
        (foreach other patch
          (if (and (= (car row) (car other)) (< (nth 1 row) (nth 1 other))
                   (<= (nth 2 row) (nth 3 other)) (>= (nth 3 row) (nth 2 other)))
            (il-add "DMX_ADDRESS_OVERLAP" (nth 1 row) "error"
              (strcat (nth 1 row) " and " (nth 1 other) " share channels in universe " (itoa (car row)))))
        )
      )
    )
  )
  ;; Zones: a control output in the zone's protocol, runs in one zone only.
  (foreach zone (il-get "zones" model)
    (if (null (il-get "runs" zone)) (il-add "ZONE_EMPTY" (il-get "id" zone) "warning" "Zone has no runs"))
    (foreach run (il-get "runs" zone)
      (if (member run zoned)
        (il-add "RUN_IN_TWO_ZONES" run "error" (strcat run " is in more than one zone"))
        (setq zoned (cons run zoned))
      )
    )
    (setq wanted (cadr (assoc (il-get "method" zone) *il-zone-protocols*)))
    (cond
      ((null (il-get "control" zone))
        (if (and wanted (not (member (il-get "method" zone) '("0-10V" "DALI-2" "phase-forward" "phase-reverse"))))
          (il-add "ZONE_NO_CONTROL" (il-get "id" zone) "warning" (strcat (il-get "method" zone) " zone has no control output"))))
      ((null (setq control (il-model-control model (il-get "control" zone))))
        (il-add "ZONE_UNKNOWN_CONTROL" (il-get "id" zone) "error" (strcat (il-get "control" zone) " is not a control in the drawing")))
      ((and catalog (setq item (il-cat-control catalog (il-get "item_code" control))))
        (setq port (il-control-port item (il-get "port" zone)))
        (setq protocol (if port (il-j port "protocol")))
        (cond
          ((null port)
            (il-add "PROTOCOL_MISMATCH" (il-get "id" zone) "error"
              (strcat (il-get "control" zone) " has no output " (il-str (il-get "port" zone)))))
          ((and wanted (/= protocol wanted))
            (il-add "PROTOCOL_MISMATCH" (il-get "id" zone) "error"
              (strcat (il-get "method" zone) " zone on a " (il-str protocol) " output of " (il-get "control" zone))))
        )
      )
    )
  )
  ;; Data length from controls that limit it (pixel data, SPI).
  (foreach wire (il-get "wires" model)
    (if (and catalog (= (il-get "kind" wire) "data") (setq control (il-model-control model (il-get "from" wire)))
             (setq item (il-cat-control catalog (il-get "item_code" control)))
             (setq limit (il-j item "max_data_length_ft"))
             (> (/ (il-get "length_in" wire) 12.0) limit))
      (il-add "DATA_TOO_LONG" (il-get "id" wire) "warning"
        (strcat (il-num->str (/ (il-get "length_in" wire) 12.0) 1) " ft of data from " (il-get "id" control)
                "; it allows " (il-num->str limit 1) " ft"))
    )
  )
  (reverse issues)
)

;; The package's "controls" and "zones" sections.
(defun il-package-controls (model / dmx)
  (il-arr
    (mapcar
      '(lambda (control / pairs)
         (setq pairs (list (cons "id" (il-get "id" control)) (cons "handle" (il-get "handle" control))
                           (cons "item_code" (il-get "item_code" control))))
         (setq pairs (il-opt "cabinet" (il-get "cabinet" control) pairs))
         (setq pairs (il-opt "room" (il-get "room" control) pairs))
         (if (il-get "universe" control)
           (setq pairs (append pairs (list (cons "dmx" (il-obj (list (cons "universe" (il-get "universe" control))
                                                                    (cons "start_address" (if (numberp (il-get "start" control)) (il-get "start" control) "auto")))))))))
         (setq pairs (il-opt "control_from" (il-get "control_from" control) pairs))
         (setq pairs (il-opt "notes" (il-get "notes" control) pairs))
         (il-obj (append pairs (list (cons "erp" (il-obj (il-opt "line_key" (il-get "line_key" control) nil))))))
       )
      (il-get "controls" model)
    )
  )
)

(defun il-package-zones (model)
  (il-arr
    (mapcar
      '(lambda (zone / pairs)
         (setq pairs (list (cons "id" (il-get "id" zone)) (cons "name" (il-get "name" zone)) (cons "method" (il-get "method" zone))))
         (if (il-get "control" zone)
           (setq pairs (append pairs (list (cons "control" (il-obj (list (cons "id" (il-get "control" zone)) (cons "port" (il-get "port" zone)))))))))
         (il-obj (append pairs (list (cons "runs" (il-arr (il-get "runs" zone))))))
       )
      (il-get "zones" model)
    )
  )
)

;;; ---- il-assets.lsp ----
;;; il-assets.lsp: GENERATED by tools/system_designer/scripts/export-cad-assets.mjs. Do not edit.
;;; Layers, linetypes and blocks of the ilLumenate CAD toolkit (draw-to-quote plan 1.6, 3.3, 3.4),
;;; from the riser layer standard, symbols and title blocks. il-blocks.lsp builds them with entmake.
;;; Layer row: (name aci linetype lineweight-mm plot description). Block item kinds: LINE, PLINE,
;;; CIRCLE, ARC, TEXT and ATTDEF ("center" last when centred), in paper inches at 1:1.

(setq *il-asset-layers* (quote (
  ("E-ANNO-TTLB" 7 "Continuous" 0.5 T "Border and title block")
  ("E-ANNO-TEXT" 7 "Continuous" 0.18 T "General text and notes")
  ("E-ANNO-SCHD" 7 "Continuous" 0.18 T "Schedules")
  ("E-ANNO-TAGS" 7 "Continuous" 0.18 T "Device and wire tags")
  ("E-POWR-EQPM" 7 "Continuous" 0.35 T "Power equipment")
  ("E-LITE-CTRL-EQPM" 7 "Continuous" 0.35 T "Control equipment")
  ("E-LITE-FIXT" 7 "Continuous" 0.35 T "Lighting loads")
  ("E-POWR-WIRE-LV" 30 "Continuous" 0.35 T "Line-voltage conductors")
  ("E-LITE-WIRE-CL2" 94 "Continuous" 0.25 T "Class 2 power")
  ("E-LITE-CTRL-DMX" 150 "DASHED" 0.18 T "DMX and Ethernet")
  ("E-LITE-CTRL-SIGL" 200 "DASHDOT" 0.18 T "0-10 V and DALI")
  ("E-LITE-CTRL-LUTR" 84 "PHANTOM" 0.18 T "Lutron links")
  ("E-LITE-CTRL-SPI" 44 "HIDDEN" 0.18 T "Pixel data")
  ("E-LITE-CTRL-WRLS" 210 "DOT" 0.18 T "Wireless")
  ("E-ANNO-ENCL" 8 "DASHED2" 0.18 T "Location and enclosure")
  ("E-ANNO-QAFL" 1 "Continuous" 0.18 nil "Preview-only QA flags")
  ("E-LITE-TAPE" 3 "Continuous" 0.5 T "Plan: LED tape and neon runs")
  ("E-LITE-EXTR" 4 "Continuous" 0.25 T "Plan: extrusion and linear fixture outlines")
  ("E-LITE-FEED" 2 "Continuous" 0.25 T "Plan: feed points and end markers")
  ("E-LITE-DATA" 150 "DASHED" 0.25 T "Plan: control and data wiring")
  ("E-POWR-CABN" 6 "Continuous" 0.35 T "Plan: power supply cabinets and locations")
  ("E-POWR-WIRE-LINE" 1 "PHANTOM" 0.35 T "Plan: line-voltage feeds")
  ("E-ANNO-ROOM" 8 "DASHED2" 0.18 T "Plan: rooms and zones")
  ("E-ANNO-ISSU" 1 "Continuous" 0.18 nil "Plan: ILCHECK issue markers (no plot)")
)))

(setq *il-asset-linetypes* (quote (
  ("Continuous" "Continuous in paper inches" ())
  ("DASHED" "DASHED in paper inches" (0.125 -0.0625))
  ("DASHED2" "DASHED2 in paper inches" (0.0625 -0.0312))
  ("DASHDOT" "DASHDOT in paper inches" (0.125 -0.0312 0.0 -0.0312))
  ("PHANTOM" "PHANTOM in paper inches" (0.25 -0.0312 0.0625 -0.0312 0.0625 -0.0312))
  ("HIDDEN" "HIDDEN in paper inches" (0.0625 -0.0625))
  ("DOT" "DOT in paper inches" (0.0 -0.0625))
)))

(setq *il-asset-blocks* (quote (
  ("IL-PSU" "Power supply (riser symbol psu)"
   ("PLINE" (0.0 0.0 2.8 0.0 2.8 1.825 0.0 1.825) T "E-POWR-EQPM")
   ("TEXT" 0.14 1.355 0.0938 "POWER SUPPLY" "left" "E-POWR-EQPM")
   ("LINE" 0.0 1.245 2.8 1.245 "E-POWR-EQPM")
   ("ATTDEF" "TAG" 0.14 1.565 0.125 "" T "E-POWR-EQPM")
   ("ATTDEF" "MODEL" 0.14 0.99 0.0938 "" nil "E-POWR-EQPM")
   ("ATTDEF" "VIN" 0.14 0.38 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "VOUT" 1.5 0.38 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "WATTS" 0.14 0.19 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "LOAD_PCT" 1.5 0.19 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "DMX_ADDR" 0.14 0.56 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "LOCATION" 0.14 0.56 0.0938 "" nil "E-POWR-EQPM"))
  ("IL-DRIVER" "CC driver (riser symbol cc-driver)"
   ("PLINE" (0.0 0.0 2.8 0.0 2.8 1.825 0.0 1.825) T "E-POWR-EQPM")
   ("TEXT" 0.14 1.355 0.0938 "CC DRIVER" "left" "E-POWR-EQPM")
   ("LINE" 0.0 1.245 2.8 1.245 "E-POWR-EQPM")
   ("ATTDEF" "TAG" 0.14 1.565 0.125 "" T "E-POWR-EQPM")
   ("ATTDEF" "MODEL" 0.14 0.99 0.0938 "" nil "E-POWR-EQPM")
   ("ATTDEF" "VIN" 0.14 0.38 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "VOUT" 1.5 0.38 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "WATTS" 0.14 0.19 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "LOAD_PCT" 1.5 0.19 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "DMX_ADDR" 0.14 0.56 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "LOCATION" 0.14 0.56 0.0938 "" nil "E-POWR-EQPM"))
  ("IL-DECODER" "DMX decoder (riser symbol decoder)"
   ("PLINE" (0.0 0.0 2.8 0.0 2.8 1.825 0.0 1.825) T "E-LITE-CTRL-EQPM")
   ("TEXT" 0.14 1.355 0.0938 "DMX DECODER" "left" "E-LITE-CTRL-EQPM")
   ("LINE" 0.0 1.245 2.8 1.245 "E-LITE-CTRL-EQPM")
   ("ATTDEF" "TAG" 0.14 1.565 0.125 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "MODEL" 0.14 0.99 0.0938 "" nil "E-LITE-CTRL-EQPM")
   ("ATTDEF" "VIN" 0.14 0.38 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "VOUT" 1.5 0.38 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "WATTS" 0.14 0.19 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "LOAD_PCT" 1.5 0.19 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "DMX_ADDR" 0.14 0.56 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "LOCATION" 0.14 0.56 0.0938 "" nil "E-LITE-CTRL-EQPM"))
  ("IL-CONTROLLER" "DMX controller (riser symbol console)"
   ("PLINE" (0.0 0.0 2.8 0.0 2.8 1.825 0.0 1.825) T "E-LITE-CTRL-EQPM")
   ("TEXT" 0.14 1.355 0.0938 "DMX CONTROLLER" "left" "E-LITE-CTRL-EQPM")
   ("LINE" 0.0 1.245 2.8 1.245 "E-LITE-CTRL-EQPM")
   ("ATTDEF" "TAG" 0.14 1.565 0.125 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "MODEL" 0.14 0.99 0.0938 "" nil "E-LITE-CTRL-EQPM")
   ("ATTDEF" "VIN" 0.14 0.38 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "VOUT" 1.5 0.38 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "WATTS" 0.14 0.19 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "LOAD_PCT" 1.5 0.19 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "DMX_ADDR" 0.14 0.56 0.0938 "" T "E-LITE-CTRL-EQPM")
   ("ATTDEF" "LOCATION" 0.14 0.56 0.0938 "" nil "E-LITE-CTRL-EQPM"))
  ("IL-JBOX" "Junction box (riser symbol junction)"
   ("PLINE" (0.0 0.0 2.8 0.0 2.8 1.825 0.0 1.825) T "E-POWR-EQPM")
   ("TEXT" 0.14 1.355 0.0938 "JUNCTION BOX" "left" "E-POWR-EQPM")
   ("LINE" 0.0 1.245 2.8 1.245 "E-POWR-EQPM")
   ("ATTDEF" "TAG" 0.14 1.565 0.125 "" T "E-POWR-EQPM")
   ("ATTDEF" "MODEL" 0.14 0.99 0.0938 "" nil "E-POWR-EQPM")
   ("ATTDEF" "VIN" 0.14 0.38 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "VOUT" 1.5 0.38 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "WATTS" 0.14 0.19 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "LOAD_PCT" 1.5 0.19 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "DMX_ADDR" 0.14 0.56 0.0938 "" T "E-POWR-EQPM")
   ("ATTDEF" "LOCATION" 0.14 0.56 0.0938 "" nil "E-POWR-EQPM"))
  ("IL-CABINET" "Power supply cabinet or location"
   ("PLINE" (-0.5 -0.3 0.5 -0.3 0.5 0.3 -0.5 0.3) T "E-POWR-CABN")
   ("LINE" -0.5 -0.3 0.5 0.3 "E-POWR-CABN")
   ("ATTDEF" "TAG" 0.0 0.38 0.125 "" T "E-ANNO-TAGS" "center")
   ("ATTDEF" "RATING" 0.0 -0.5 0.0938 "" T "E-ANNO-TAGS" "center")
   ("ATTDEF" "ACCESS" 0.0 -0.65 0.0938 "" nil "E-ANNO-TAGS" "center"))
  ("IL-FEED" "Feed point on a run"
   ("CIRCLE" 0.0 0.0 0.08 "E-LITE-FEED")
   ("PLINE" (-0.08 0.12 0.08 0.12 0.0 0.26) T "E-LITE-FEED"))
  ("IL-END" "End of a run (endcap)"
   ("LINE" 0.0 -0.1 0.0 0.1 "E-LITE-FEED"))
  ("IL-JUMPER" "Jumper between two segments of a run"
   ("CIRCLE" 0.0 0.0 0.06 "E-LITE-FEED")
   ("LINE" -0.1 -0.1 0.1 0.1 "E-LITE-FEED"))
  ("IL-RUNTAG" "Run tag: id, style and lengths"
   ("PLINE" (-0.3 -0.1 0.3 -0.1 0.38 0.0 0.3 0.1 -0.3 0.1 -0.38 0.0) T "E-ANNO-TAGS")
   ("ATTDEF" "TAG" 0.0 -0.047 0.0938 "" T "E-ANNO-TAGS" "center")
   ("ATTDEF" "STYLE" 0.0 -0.25 0.0938 "" T "E-ANNO-TAGS" "center")
   ("ATTDEF" "LENGTH" 0.0 -0.4 0.0938 "" T "E-ANNO-TAGS" "center")
   ("ATTDEF" "PART" 0.0 -0.55 0.0938 "" nil "E-ANNO-TAGS" "center"))
  ("IL-PSUTAG" "PSU tag with provisional load"
   ("PLINE" (-0.18 -0.18 0.18 -0.18 0.18 0.18 -0.18 0.18) T "E-ANNO-TAGS")
   ("ATTDEF" "TAG" 0.0 -0.047 0.0938 "" T "E-ANNO-TAGS" "center")
   ("ATTDEF" "LOAD" 0.0 -0.33 0.0938 "" T "E-ANNO-TAGS" "center")
   ("ATTDEF" "MODEL" 0.0 -0.48 0.0938 "" nil "E-ANNO-TAGS" "center"))
  ("IL-WIRETAG" "Wire tag"
   ("CIRCLE" 0.0 0.0 0.12 "E-ANNO-TAGS")
   ("ATTDEF" "TAG" 0.0 -0.047 0.0938 "" T "E-ANNO-TAGS" "center")
   ("ATTDEF" "LENGTH" 0.0 -0.28 0.0938 "" T "E-ANNO-TAGS" "center"))
  ("IL-ROOMTAG" "Room tag"
   ("ATTDEF" "NAME" 0.0 0.0 0.125 "" T "E-ANNO-ROOM" "center")
   ("ATTDEF" "ID" 0.0 -0.18 0.0938 "" T "E-ANNO-ROOM" "center")
   ("ATTDEF" "ENV" 0.0 -0.33 0.0938 "" T "E-ANNO-ROOM" "center"))
  ("IL-ISSUE" "ILCHECK issue marker (no-plot layer)"
   ("CIRCLE" 0.0 0.0 0.15 "E-ANNO-ISSU")
   ("LINE" 0.0 -0.05 0.0 0.09 "E-ANNO-ISSU")
   ("CIRCLE" 0.0 -0.09 0.012 "E-ANNO-ISSU")
   ("ATTDEF" "CODE" 0.0 -0.3 0.0938 "" T "E-ANNO-ISSU" "center"))
  ("IL-TB-ARCH-C" "ARCH-C title block (24 x 18 in)"
   ("PLINE" (0.5 0.5 23.5 0.5 23.5 17.5 0.5 17.5) T "E-ANNO-TTLB")
   ("PLINE" (20.25 0.5 23.5 0.5 23.5 17.5 20.25 17.5) T "E-ANNO-TTLB")
   ("PLINE" (20.37 16.2323 23.38 16.2323 23.38 17.46 20.37 17.46) T "E-ANNO-TTLB")
   ("TEXT" 20.45 16.8462 0.25 "ilLumenate" "left" "E-ANNO-TTLB")
   ("PLINE" (20.37 14.9488 23.38 14.9488 23.38 16.1523 20.37 16.1523) T "E-ANNO-TTLB")
   ("TEXT" 20.43 15.9923 0.075 "PROJECT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "PROJECT" 20.43 15.2488 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 13.6654 23.38 13.6654 23.38 14.8688 20.37 14.8688) T "E-ANNO-TTLB")
   ("TEXT" 20.43 14.7088 0.075 "PROJECT NO." "left" "E-ANNO-TTLB")
   ("ATTDEF" "NUMBER" 20.43 13.9654 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 12.3819 23.38 12.3819 23.38 13.5854 20.37 13.5854) T "E-ANNO-TTLB")
   ("TEXT" 20.43 13.4254 0.075 "CLIENT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CLIENT" 20.43 12.6819 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 11.0985 23.38 11.0985 23.38 12.3019 20.37 12.3019) T "E-ANNO-TTLB")
   ("TEXT" 20.43 12.1419 0.075 "SITE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "ADDRESS" 20.43 11.3985 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 9.5485 23.38 9.5485 23.38 11.0185 20.37 11.0185) T "E-ANNO-TTLB")
   ("TEXT" 20.43 10.8585 0.2 "SHEET TITLE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_TITLE" 20.43 9.8485 0.3325 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 8.2408 23.38 8.2408 23.38 9.4685 20.37 9.4685) T "E-ANNO-TTLB")
   ("TEXT" 20.43 9.3085 0.1 "SHEET" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_NUMBER" 20.43 8.5408 0.1663 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 6.9573 23.38 6.9573 23.38 8.1608 20.37 8.1608) T "E-ANNO-TTLB")
   ("TEXT" 20.43 8.0008 0.075 "DATE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DATE" 20.43 7.2573 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 5.6738 23.38 5.6738 23.38 6.8773 20.37 6.8773) T "E-ANNO-TTLB")
   ("TEXT" 20.43 6.7173 0.075 "SCALE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SCALE" 20.43 5.9738 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 4.3904 23.38 4.3904 23.38 5.5938 20.37 5.5938) T "E-ANNO-TTLB")
   ("TEXT" 20.43 5.4338 0.075 "DRAWN BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DRAWN_BY" 20.43 4.6904 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 3.1069 23.38 3.1069 23.38 4.3104 20.37 4.3104) T "E-ANNO-TTLB")
   ("TEXT" 20.43 4.1504 0.075 "CHECKED BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CHECKED_BY" 20.43 3.4069 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 1.8235 23.38 1.8235 23.38 3.0269 20.37 3.0269) T "E-ANNO-TTLB")
   ("TEXT" 20.43 2.8669 0.075 "REVISIONS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "REVISIONS" 20.43 2.1235 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (20.37 0.54 23.38 0.54 23.38 1.7435 20.37 1.7435) T "E-ANNO-TTLB")
   ("TEXT" 20.43 1.5835 0.075 "STATUS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "STAMP" 20.43 0.84 0.1247 "" T "E-ANNO-TEXT"))
  ("IL-TB-ARCH-D" "ARCH-D title block (36 x 24 in)"
   ("PLINE" (0.5 0.5 35.5 0.5 35.5 23.5 0.5 23.5) T "E-ANNO-TTLB")
   ("PLINE" (31.75 0.5 35.5 0.5 35.5 23.5 31.75 23.5) T "E-ANNO-TTLB")
   ("PLINE" (31.87 21.7708 35.38 21.7708 35.38 23.46 31.87 23.46) T "E-ANNO-TTLB")
   ("TEXT" 31.95 22.6154 0.25 "ilLumenate" "left" "E-ANNO-TTLB")
   ("PLINE" (31.87 20.0015 35.38 20.0015 35.38 21.6908 31.87 21.6908) T "E-ANNO-TTLB")
   ("TEXT" 31.93 21.5308 0.075 "PROJECT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "PROJECT" 31.93 20.3015 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 18.2323 35.38 18.2323 35.38 19.9215 31.87 19.9215) T "E-ANNO-TTLB")
   ("TEXT" 31.93 19.7615 0.075 "PROJECT NO." "left" "E-ANNO-TTLB")
   ("ATTDEF" "NUMBER" 31.93 18.5323 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 16.4631 35.38 16.4631 35.38 18.1523 31.87 18.1523) T "E-ANNO-TTLB")
   ("TEXT" 31.93 17.9923 0.075 "CLIENT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CLIENT" 31.93 16.7631 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 14.6938 35.38 14.6938 35.38 16.3831 31.87 16.3831) T "E-ANNO-TTLB")
   ("TEXT" 31.93 16.2231 0.075 "SITE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "ADDRESS" 31.93 14.9938 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 12.9246 35.38 12.9246 35.38 14.6138 31.87 14.6138) T "E-ANNO-TTLB")
   ("TEXT" 31.93 14.4538 0.2 "SHEET TITLE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_TITLE" 31.93 13.2246 0.3325 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 11.1554 35.38 11.1554 35.38 12.8446 31.87 12.8446) T "E-ANNO-TTLB")
   ("TEXT" 31.93 12.6846 0.1 "SHEET" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_NUMBER" 31.93 11.4554 0.1663 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 9.3862 35.38 9.3862 35.38 11.0754 31.87 11.0754) T "E-ANNO-TTLB")
   ("TEXT" 31.93 10.9154 0.075 "DATE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DATE" 31.93 9.6862 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 7.6169 35.38 7.6169 35.38 9.3062 31.87 9.3062) T "E-ANNO-TTLB")
   ("TEXT" 31.93 9.1462 0.075 "SCALE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SCALE" 31.93 7.9169 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 5.8477 35.38 5.8477 35.38 7.5369 31.87 7.5369) T "E-ANNO-TTLB")
   ("TEXT" 31.93 7.3769 0.075 "DRAWN BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DRAWN_BY" 31.93 6.1477 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 4.0785 35.38 4.0785 35.38 5.7677 31.87 5.7677) T "E-ANNO-TTLB")
   ("TEXT" 31.93 5.6077 0.075 "CHECKED BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CHECKED_BY" 31.93 4.3785 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 2.3092 35.38 2.3092 35.38 3.9985 31.87 3.9985) T "E-ANNO-TTLB")
   ("TEXT" 31.93 3.8385 0.075 "REVISIONS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "REVISIONS" 31.93 2.6092 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (31.87 0.54 35.38 0.54 35.38 2.2292 31.87 2.2292) T "E-ANNO-TTLB")
   ("TEXT" 31.93 2.0692 0.075 "STATUS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "STAMP" 31.93 0.84 0.1247 "" T "E-ANNO-TEXT"))
  ("IL-TB-ANSI-A" "ANSI-A title block (11 x 8.5 in)"
   ("PLINE" (0.5 0.5 10.5 0.5 10.5 8.0 0.5 8.0) T "E-ANNO-TTLB")
   ("PLINE" (8.25 0.5 10.5 0.5 10.5 8.0 8.25 8.0) T "E-ANNO-TTLB")
   ("PLINE" (8.37 7.26 10.38 7.26 10.38 7.96 8.37 7.96) T "E-ANNO-TTLB")
   ("TEXT" 8.45 7.61 0.25 "ilLumenate" "left" "E-ANNO-TTLB")
   ("PLINE" (8.37 6.75 10.38 6.75 10.38 7.19 8.37 7.19) T "E-ANNO-TTLB")
   ("TEXT" 8.43 7.03 0.075 "PROJECT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "PROJECT" 8.43 6.97 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 6.24 10.38 6.24 10.38 6.68 8.37 6.68) T "E-ANNO-TTLB")
   ("TEXT" 8.43 6.52 0.075 "PROJECT NO." "left" "E-ANNO-TTLB")
   ("ATTDEF" "NUMBER" 8.43 6.46 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 5.73 10.38 5.73 10.38 6.17 8.37 6.17) T "E-ANNO-TTLB")
   ("TEXT" 8.43 6.01 0.075 "CLIENT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CLIENT" 8.43 5.95 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 5.22 10.38 5.22 10.38 5.66 8.37 5.66) T "E-ANNO-TTLB")
   ("TEXT" 8.43 5.5 0.075 "SITE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "ADDRESS" 8.43 5.44 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 4.25 10.38 4.25 10.38 5.15 8.37 5.15) T "E-ANNO-TTLB")
   ("TEXT" 8.43 4.99 0.2 "SHEET TITLE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_TITLE" 8.43 4.55 0.3325 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 3.63 10.38 3.63 10.38 4.18 8.37 4.18) T "E-ANNO-TTLB")
   ("TEXT" 8.43 4.02 0.1 "SHEET" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_NUMBER" 8.43 3.905 0.1663 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 3.12 10.38 3.12 10.38 3.56 8.37 3.56) T "E-ANNO-TTLB")
   ("TEXT" 8.43 3.4 0.075 "DATE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DATE" 8.43 3.34 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 2.61 10.38 2.61 10.38 3.05 8.37 3.05) T "E-ANNO-TTLB")
   ("TEXT" 8.43 2.89 0.075 "SCALE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SCALE" 8.43 2.83 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 2.1 10.38 2.1 10.38 2.54 8.37 2.54) T "E-ANNO-TTLB")
   ("TEXT" 8.43 2.38 0.075 "DRAWN BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DRAWN_BY" 8.43 2.32 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 1.59 10.38 1.59 10.38 2.03 8.37 2.03) T "E-ANNO-TTLB")
   ("TEXT" 8.43 1.87 0.075 "CHECKED BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CHECKED_BY" 8.43 1.81 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 1.08 10.38 1.08 10.38 1.52 8.37 1.52) T "E-ANNO-TTLB")
   ("TEXT" 8.43 1.36 0.075 "REVISIONS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "REVISIONS" 8.43 1.3 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (8.37 0.57 10.38 0.57 10.38 1.01 8.37 1.01) T "E-ANNO-TTLB")
   ("TEXT" 8.43 0.85 0.075 "STATUS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "STAMP" 8.43 0.79 0.1247 "" T "E-ANNO-TEXT"))
  ("IL-TB-ANSI-B" "ANSI-B title block (17 x 11 in)"
   ("PLINE" (0.5 0.5 16.5 0.5 16.5 10.5 0.5 10.5) T "E-ANNO-TTLB")
   ("PLINE" (13.75 0.5 16.5 0.5 16.5 10.5 13.75 10.5) T "E-ANNO-TTLB")
   ("PLINE" (13.87 9.59 16.38 9.59 16.38 10.46 13.87 10.46) T "E-ANNO-TTLB")
   ("TEXT" 13.95 10.025 0.25 "ilLumenate" "left" "E-ANNO-TTLB")
   ("PLINE" (13.87 8.92 16.38 8.92 16.38 9.51 13.87 9.51) T "E-ANNO-TTLB")
   ("TEXT" 13.93 9.35 0.075 "PROJECT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "PROJECT" 13.93 9.215 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 8.25 16.38 8.25 16.38 8.84 13.87 8.84) T "E-ANNO-TTLB")
   ("TEXT" 13.93 8.68 0.075 "PROJECT NO." "left" "E-ANNO-TTLB")
   ("ATTDEF" "NUMBER" 13.93 8.545 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 7.58 16.38 7.58 16.38 8.17 13.87 8.17) T "E-ANNO-TTLB")
   ("TEXT" 13.93 8.01 0.075 "CLIENT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CLIENT" 13.93 7.875 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 6.91 16.38 6.91 16.38 7.5 13.87 7.5) T "E-ANNO-TTLB")
   ("TEXT" 13.93 7.34 0.075 "SITE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "ADDRESS" 13.93 7.205 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 5.36 16.38 5.36 16.38 6.83 13.87 6.83) T "E-ANNO-TTLB")
   ("TEXT" 13.93 6.67 0.2 "SHEET TITLE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_TITLE" 13.93 5.66 0.3325 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 4.56 16.38 4.56 16.38 5.28 13.87 5.28) T "E-ANNO-TTLB")
   ("TEXT" 13.93 5.12 0.1 "SHEET" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_NUMBER" 13.93 4.86 0.1663 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 3.89 16.38 3.89 16.38 4.48 13.87 4.48) T "E-ANNO-TTLB")
   ("TEXT" 13.93 4.32 0.075 "DATE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DATE" 13.93 4.185 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 3.22 16.38 3.22 16.38 3.81 13.87 3.81) T "E-ANNO-TTLB")
   ("TEXT" 13.93 3.65 0.075 "SCALE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SCALE" 13.93 3.515 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 2.55 16.38 2.55 16.38 3.14 13.87 3.14) T "E-ANNO-TTLB")
   ("TEXT" 13.93 2.98 0.075 "DRAWN BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DRAWN_BY" 13.93 2.845 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 1.88 16.38 1.88 16.38 2.47 13.87 2.47) T "E-ANNO-TTLB")
   ("TEXT" 13.93 2.31 0.075 "CHECKED BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CHECKED_BY" 13.93 2.175 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 1.21 16.38 1.21 16.38 1.8 13.87 1.8) T "E-ANNO-TTLB")
   ("TEXT" 13.93 1.64 0.075 "REVISIONS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "REVISIONS" 13.93 1.505 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (13.87 0.54 16.38 0.54 16.38 1.13 13.87 1.13) T "E-ANNO-TTLB")
   ("TEXT" 13.93 0.97 0.075 "STATUS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "STAMP" 13.93 0.835 0.1247 "" T "E-ANNO-TEXT"))
  ("IL-TB-ANSI-D" "ANSI-D title block (34 x 22 in)"
   ("PLINE" (0.5 0.5 33.5 0.5 33.5 21.5 0.5 21.5) T "E-ANNO-TTLB")
   ("PLINE" (29.75 0.5 33.5 0.5 33.5 21.5 29.75 21.5) T "E-ANNO-TTLB")
   ("PLINE" (29.87 19.9246 33.38 19.9246 33.38 21.46 29.87 21.46) T "E-ANNO-TTLB")
   ("TEXT" 29.95 20.6923 0.25 "ilLumenate" "left" "E-ANNO-TTLB")
   ("PLINE" (29.87 18.3092 33.38 18.3092 33.38 19.8446 29.87 19.8446) T "E-ANNO-TTLB")
   ("TEXT" 29.93 19.6846 0.075 "PROJECT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "PROJECT" 29.93 18.6092 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 16.6938 33.38 16.6938 33.38 18.2292 29.87 18.2292) T "E-ANNO-TTLB")
   ("TEXT" 29.93 18.0692 0.075 "PROJECT NO." "left" "E-ANNO-TTLB")
   ("ATTDEF" "NUMBER" 29.93 16.9938 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 15.0785 33.38 15.0785 33.38 16.6138 29.87 16.6138) T "E-ANNO-TTLB")
   ("TEXT" 29.93 16.4538 0.075 "CLIENT" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CLIENT" 29.93 15.3785 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 13.4631 33.38 13.4631 33.38 14.9985 29.87 14.9985) T "E-ANNO-TTLB")
   ("TEXT" 29.93 14.8385 0.075 "SITE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "ADDRESS" 29.93 13.7631 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 11.8477 33.38 11.8477 33.38 13.3831 29.87 13.3831) T "E-ANNO-TTLB")
   ("TEXT" 29.93 13.2231 0.2 "SHEET TITLE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_TITLE" 29.93 12.1477 0.3325 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 10.2323 33.38 10.2323 33.38 11.7677 29.87 11.7677) T "E-ANNO-TTLB")
   ("TEXT" 29.93 11.6077 0.1 "SHEET" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SHEET_NUMBER" 29.93 10.5323 0.1663 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 8.6169 33.38 8.6169 33.38 10.1523 29.87 10.1523) T "E-ANNO-TTLB")
   ("TEXT" 29.93 9.9923 0.075 "DATE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DATE" 29.93 8.9169 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 7.0015 33.38 7.0015 33.38 8.5369 29.87 8.5369) T "E-ANNO-TTLB")
   ("TEXT" 29.93 8.3769 0.075 "SCALE" "left" "E-ANNO-TTLB")
   ("ATTDEF" "SCALE" 29.93 7.3015 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 5.3862 33.38 5.3862 33.38 6.9215 29.87 6.9215) T "E-ANNO-TTLB")
   ("TEXT" 29.93 6.7615 0.075 "DRAWN BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "DRAWN_BY" 29.93 5.6862 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 3.7708 33.38 3.7708 33.38 5.3062 29.87 5.3062) T "E-ANNO-TTLB")
   ("TEXT" 29.93 5.1462 0.075 "CHECKED BY" "left" "E-ANNO-TTLB")
   ("ATTDEF" "CHECKED_BY" 29.93 4.0708 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 2.1554 33.38 2.1554 33.38 3.6908 29.87 3.6908) T "E-ANNO-TTLB")
   ("TEXT" 29.93 3.5308 0.075 "REVISIONS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "REVISIONS" 29.93 2.4554 0.1247 "" T "E-ANNO-TEXT")
   ("PLINE" (29.87 0.54 33.38 0.54 33.38 2.0754 29.87 2.0754) T "E-ANNO-TTLB")
   ("TEXT" 29.93 1.9154 0.075 "STATUS" "left" "E-ANNO-TTLB")
   ("ATTDEF" "STAMP" 29.93 0.84 0.1247 "" T "E-ANNO-TEXT"))
)))

;;; ---- il-core.lsp ----
;;; il-core.lsp -- ilLumenate CAD toolkit: command wrapper, XData and drawing storage (plan 3.1).
;;;
;;; Every command runs inside il-begin / il-end: one undo step, system variables restored, and an
;;; *error* handler that puts both back if the user cancels. Entities carry XData under the app
;;; "ILLUMENATE" as key/value strings with a schema version; long data (styles, settings, other
;;; lines, overrides) lives in XRECORDs of the "ILLUMENATE" dictionary in the named object dictionary.
;;; Only entget/entmod/entmake and dictionary functions: works on full AutoCAD, LT 2024+ and Mac.

(setq *il-app* "ILLUMENATE" *il-dict* "ILLUMENATE" *il-xdata-schema* 1)
(setq *il-sysvars* '("CMDECHO" "OSMODE" "CLAYER" "ATTREQ" "ATTDIA" "DIMZIN"))

;; --- Command wrapper ----------------------------------------------------------------------------

(defun il-begin (/ saved)
  (setq *il-json-cache* nil *il-layout* nil *il-tag-index* nil)
  (setq *il-saved-vars* (mapcar '(lambda (name) (cons name (getvar name))) *il-sysvars*))
  (setq *il-old-error* *error*)
  (setq *error* il-error)
  (setvar "CMDECHO" 0)
  (setvar "ATTREQ" 0)
  (setvar "DIMZIN" 8)
  (command "_.UNDO" "_BEGIN")
  T
)

(defun il-restore ()
  (foreach pair *il-saved-vars*
    (if (cdr pair) (vl-catch-all-apply 'setvar (list (car pair) (cdr pair))))
  )
)

(defun il-end ()
  (command "_.UNDO" "_END")
  (il-restore)
  (setq *error* *il-old-error*)
  (princ)
)

(defun il-error (message)
  (while (> (getvar "CMDACTIVE") 0) (command))
  (command "_.UNDO" "_END")
  (il-restore)
  (setq *error* *il-old-error*)
  (if (not (member message '("Function cancelled" "quit / exit abort" "console break")))
    (princ (strcat "\nilLumenate: " message))
  )
  (princ)
)

;; Capability report for the Phase 0 spike and ILVERSION: what this AutoCAD offers.
(defun il-capabilities ()
  (list
    (cons "product" (getvar "PRODUCT"))
    (cons "version" (getvar "ACADVER"))
    (cons "platform" (getvar "PLATFORM"))
    (cons "activex" (if (= (type vlax-get-acad-object) 'SUBR) "yes" "no"))
    (cons "reactors" (if (= (type vlr-object-reactor) 'SUBR) "yes" "no"))
    (cons "dcl" (if (= (type load_dialog) 'SUBR) "yes" "no"))
  )
)

(defun il-platform ()
  (strcat (getvar "PRODUCT") " " (substr (getvar "ACADVER") 1 4))
)

;; --- XData ------------------------------------------------------------------------------------

;; The ILLUMENATE XData of ENAME as ((key . value) ...), migrated to the current schema.
(defun il-xget (ename / data items result key)
  (setq data (cdr (assoc -3 (entget ename (list *il-app*)))))
  (setq items (cdr (assoc *il-app* data)))
  (while items
    (if (= (car (car items)) 1000)
      (progn
        (setq key (cdr (car items)) items (cdr items))
        (setq result (cons (cons key (if items (cdr (car items)) "")) result))
      )
    )
    (setq items (cdr items))
  )
  (il-xmigrate (reverse result))
)

;; Schema migrations: each step lifts XData written by an older toolkit. Version 1 is the first.
(defun il-xmigrate (pairs / version)
  (setq version (atoi (il-str (il-get "sv" pairs))))
  (cond
    ((null pairs) nil)
    ((< version 1) (il-put "sv" "1" pairs))
    (T pairs)
  )
)

;; Replace ENAME's ILLUMENATE XData with PAIRS ((key . value) ...); values become text <= 250 chars.
(defun il-xset (ename pairs / data entity)
  (regapp *il-app*)
  (setq pairs (il-put "sv" (itoa *il-xdata-schema*) pairs))
  (foreach pair pairs
    (if (and (cdr pair) (/= (il-str (cdr pair)) ""))
      (setq data (append data (list (cons 1000 (car pair)) (cons 1000 (substr (il-str (cdr pair)) 1 250)))))
    )
  )
  (setq entity (vl-remove-if '(lambda (item) (= (car item) -3)) (entget ename)))
  (entmod (append entity (list (list -3 (cons *il-app* data)))))
  (entupd ename)
)

(defun il-xupdate (ename changes / pairs)
  (setq pairs (il-xget ename))
  (foreach change changes (setq pairs (il-put (car change) (cdr change) pairs)))
  (il-xset ename pairs)
)

(defun il-kind (ename) (il-get "kind" (il-xget ename)))

;; Every entity with ILLUMENATE XData of KIND ("RUN", "ROOM", "CABINET", "PSU", "WIRE").
(defun il-entities (kind / ss index result ename)
  (if (setq ss (ssget "_X" (list (list -3 (list *il-app*)))))
    (progn
      (setq index 0)
      (repeat (sslength ss)
        (setq ename (ssname ss index) index (1+ index))
        (if (= (il-kind ename) kind) (setq result (cons ename result)))
      )
    )
  )
  (reverse result)
)

(defun il-handle (ename) (cdr (assoc 5 (entget ename))))

(defun il-find-id (kind id / found)
  (foreach ename (il-entities kind)
    (if (= (il-get "id" (il-xget ename)) id) (setq found ename))
  )
  found
)

;; The next free tag: (il-next-id "RUN" "L1-") returns "L1-03".
(defun il-next-id (kind prefix / used number)
  (foreach ename (il-entities kind)
    (setq used (cons (il-get "id" (il-xget ename)) used))
  )
  (setq number 1)
  (while (member (strcat prefix (il-pad2 number)) used) (setq number (1+ number)))
  (strcat prefix (il-pad2 number))
)

;; --- Drawing storage (named object dictionary) ------------------------------------------------

(defun il-dict (/ found)
  (if (setq found (dictsearch (namedobjdict) *il-dict*))
    (cdr (assoc -1 found))
    (dictadd (namedobjdict) *il-dict* (entmakex '((0 . "DICTIONARY") (100 . "AcDbDictionary"))))
  )
)

;; Store TEXT under KEY, in 250-character chunks.
(defun il-store (key text / dict chunks index)
  (setq dict (il-dict) index 1)
  (while (<= index (strlen text))
    (setq chunks (cons (cons 1 (substr text index 250)) chunks) index (+ index 250))
  )
  (if (dictsearch dict key) (entdel (cdr (assoc -1 (dictsearch dict key)))))
  (dictremove dict key)
  (dictadd dict key
    (entmakex (append '((0 . "XRECORD") (100 . "AcDbXrecord")) (reverse chunks) (if (null chunks) '((1 . "")))))
  )
  text
)

(defun il-fetch (key / record)
  (if (setq record (dictsearch (il-dict) key))
    (apply 'strcat (mapcar 'cdr (vl-remove-if-not '(lambda (item) (= (car item) 1)) record)))
  )
)

;; JSON values in the dictionary.
(defun il-store-json (key value)
  (il-store key (il-json-text value))
  (setq *il-json-cache* (cons (cons key value) (vl-remove-if '(lambda (pair) (= (car pair) key)) *il-json-cache*)))
  value
)
;; Parsed values are kept for the rest of the command (settings and styles are read per run).
(defun il-fetch-json (key / text cached value)
  (if (setq cached (assoc key *il-json-cache*))
    (cdr cached)
    (progn
      (setq value (if (and (setq text (il-fetch key)) (/= text "")) (il-json-parse text)))
      (setq *il-json-cache* (cons (cons key value) *il-json-cache*))
      value
    )
  )
)

;; Drawing settings: an object of schedule, project, catalog path and hash, revision, scale flag.
(defun il-settings () (if (il-fetch-json "SETTINGS") (il-fetch-json "SETTINGS") (il-obj nil)))
(defun il-setting (key) (il-j (il-settings) key))
(defun il-set-setting (key value) (il-store-json "SETTINGS" (il-jset (il-settings) key value)))

;; --- Prompts ----------------------------------------------------------------------------------

;; Pick one of ITEMS (strings) by number; DEFAULT-INDEX is 1-based. Returns the item or nil.
;; A number outside the list asks again; Enter takes the default (nil when there is none).
(defun il-choose (title items default-index / index answer done)
  (if (and default-index (or (< default-index 1) (> default-index (length items)))) (setq default-index 1))
  (if items
    (progn
      (princ (strcat "\n" title ":"))
      (setq index 1)
      (foreach item items
        (princ (strcat "\n  " (itoa index) ". " (il-str item)))
        (setq index (1+ index))
      )
      (while (not done)
        (initget 4)
        (setq answer (getint (strcat "\nNumber" (if default-index (strcat " <" (itoa default-index) ">") "") ": ")))
        (if (null answer) (setq answer default-index))
        (if (or (null answer) (and (> answer 0) (<= answer (length items))))
          (setq done T)
          (princ (strcat "\nPick 1 to " (itoa (length items)) "."))
        )
      )
      (if answer (nth (1- answer) items))
    )
  )
)

;; An id for a new KIND entity: the typed one when it is free, else the next free one after PREFIX.
(defun il-ask-id (kind message prefix / suggested id)
  (setq suggested (il-next-id kind prefix) id (il-trim (il-ask message suggested)))
  (cond
    ((= id "") suggested)
    ((il-find-id kind id) (princ (strcat "\n" id " is taken; using " suggested ".")) suggested)
    (T id)
  )
)

;; True when the current space is a layout's paper space (not model space or a viewport in it).
(defun il-paper-space-p () (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)))

(defun il-ask (message default / answer)
  (setq answer (getstring T (strcat "\n" message (if (and default (/= default "")) (strcat " <" default ">") "") ": ")))
  (if (= answer "") default answer)
)

(defun il-today (/ date)
  (setq date (rtos (getvar "CDATE") 2 0))
  (strcat (substr date 1 4) "-" (substr date 5 2) "-" (substr date 7 2))
)

;; --- Geometry ---------------------------------------------------------------------------------

;; ((x y bulge) ...) of an LWPOLYLINE, and whether it is closed.
(defun il-lw-vertices (ename / data result point)
  (setq data (entget ename))
  (foreach item data
    (cond
      ((= (car item) 10) (setq point (list (cadr item) (caddr item) 0.0) result (cons point result)))
      ((and (= (car item) 42) result)
        (setq result (cons (list (car (car result)) (cadr (car result)) (cdr item)) (cdr result))))
    )
  )
  (reverse result)
)

;; Replace the vertices of LWPOLYLINE ENAME with VERTICES ((x y bulge) ...); widths reset, XData kept.
(defun il-lw-set-vertices (ename vertices / head tail seen data)
  (foreach group (entget ename)
    (cond
      ((= (car group) 10) (setq seen T))
      ((and seen (member (car group) '(40 41 42 91))))
      (seen (setq tail (cons group tail)))
      ((= (car group) 90) (setq head (cons (cons 90 (length vertices)) head)))
      (T (setq head (cons group head)))
    )
  )
  (foreach vertex vertices
    (setq data (append data (list (list 10 (car vertex) (cadr vertex)) '(40 . 0.0) '(41 . 0.0) (cons 42 (il-bulge vertex)))))
  )
  (entmod (append (reverse head) data (reverse tail)))
  (entupd ename)
)

(defun il-lw-closed (ename) (= 1 (logand 1 (cdr (assoc 70 (entget ename))))))

(defun il-point-in-polygon (point vertices / inside a b count index)
  (setq count (length vertices) index 0)
  (while (< index count)
    (setq a (nth index vertices) b (nth (rem (1+ index) count) vertices))
    (if (and (/= (> (cadr a) (cadr point)) (> (cadr b) (cadr point)))
             (< (car point) (+ (car a) (/ (* (- (car b) (car a)) (- (cadr point) (cadr a))) (- (cadr b) (cadr a))))))
      (setq inside (not inside))
    )
    (setq index (1+ index))
  )
  inside
)

(defun il-midpoint (vertices / a b)
  (setq a (car vertices) b (last vertices))
  (list (/ (+ (car a) (car b)) 2.0) (/ (+ (cadr a) (cadr b)) 2.0) 0.0)
)

(defun il-centroid (vertices / x y)
  (setq x 0.0 y 0.0)
  (foreach v vertices (setq x (+ x (car v)) y (+ y (cadr v))))
  (list (/ x (length vertices)) (/ y (length vertices)) 0.0)
)

;; Plan symbols are drawn in paper inches; insert them at the drawing's annotation scale.
(defun il-symbol-scale (/ scale)
  (setq scale (il-number (il-setting "symbol_scale")))
  (if (and scale (> scale 0)) scale (max 1.0 (getvar "DIMSCALE")))
)

;;; ---- il-blocks.lsp ----
;;; il-blocks.lsp -- ilLumenate CAD toolkit: layers, linetypes and blocks from il-assets.lsp (3.3, 3.4).
;;;
;;; The asset data is generated from the riser's layer standard, symbols and title blocks, so the plan
;;; and the riser read the same. Everything is made with entmake: no DWG library, LT and Mac safe.

(defun il-ensure-linetype (row / name pattern total items)
  (setq name (car row) pattern (caddr row))
  (if (and (not (tblsearch "LTYPE" name)) (/= (strcase name) "CONTINUOUS"))
    (progn
      (setq total 0.0)
      (foreach dash pattern (setq total (+ total (abs dash))))
      (setq items nil)
      (foreach dash pattern (setq items (append items (list (cons 49 dash) (cons 74 0)))))
      (entmake
        (append
          (list '(0 . "LTYPE") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLinetypeTableRecord")
                (cons 2 name) '(70 . 0) (cons 3 (cadr row)) '(72 . 65) (cons 73 (length pattern)) (cons 40 total))
          items
        )
      )
    )
  )
)

(defun il-ensure-layer (row / name)
  (setq name (nth 0 row))
  (if (not (tblsearch "LAYER" name))
    (progn
      (regapp "AcAecLayerStandard")
      (entmake
        (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
              (cons 2 name) '(70 . 0) (cons 62 (nth 1 row)) (cons 6 (nth 2 row))
              (cons 370 (fix (+ 0.5 (* 100 (nth 3 row))))) (cons 290 (if (nth 4 row) 1 0))
              (list -3 (list "AcAecLayerStandard" (cons 1000 "") (cons 1000 (nth 5 row)))))
      )
    )
  )
)

(defun il-make-item (item / kind points data)
  (setq kind (car item))
  (cond
    ((= kind "LINE")
      (entmake (list '(0 . "LINE") (cons 8 (nth 5 item)) (list 10 (nth 1 item) (nth 2 item) 0.0) (list 11 (nth 3 item) (nth 4 item) 0.0))))
    ((= kind "PLINE")
      (setq points (nth 1 item) data nil)
      (while points
        (setq data (append data (list (list 10 (car points) (cadr points)))) points (cddr points))
      )
      (entmake (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 (nth 3 item)) '(100 . "AcDbPolyline")
                             (cons 90 (length data)) (cons 70 (if (nth 2 item) 1 0)))
                       data)))
    ((= kind "CIRCLE")
      (entmake (list '(0 . "CIRCLE") (cons 8 (nth 4 item)) (list 10 (nth 1 item) (nth 2 item) 0.0) (cons 40 (nth 3 item)))))
    ((= kind "ARC")
      (entmake (list '(0 . "ARC") (cons 8 (nth 6 item)) (list 10 (nth 1 item) (nth 2 item) 0.0) (cons 40 (nth 3 item))
                     (cons 50 (* pi (/ (nth 4 item) 180.0))) (cons 51 (* pi (/ (nth 5 item) 180.0))))))
    ((= kind "TEXT")
      (entmake (list '(0 . "TEXT") (cons 8 (nth 6 item)) (list 10 (nth 1 item) (nth 2 item) 0.0) (cons 40 (nth 3 item))
                     (cons 1 (nth 4 item)))))
    ((= kind "ATTDEF")
      (entmake (append (list '(0 . "ATTDEF") (cons 8 (nth 7 item)) (list 10 (nth 2 item) (nth 3 item) 0.0) (cons 40 (nth 4 item))
                             (cons 1 (nth 5 item)) (cons 3 (nth 1 item)) (cons 2 (nth 1 item)) (cons 70 (if (nth 6 item) 0 1)))
                       (il-align-groups item (list (nth 2 item) (nth 3 item) 0.0)))))
  )
)

(defun il-ensure-block (block / name has-attributes)
  (setq name (car block))
  (if (not (tblsearch "BLOCK" name))
    (progn
      (foreach item (cddr block) (if (= (car item) "ATTDEF") (setq has-attributes T)))
      (entmake (list '(0 . "BLOCK") (cons 2 name) (cons 70 (if has-attributes 2 0)) '(10 0.0 0.0 0.0) (cons 4 (cadr block))))
      (foreach item (cddr block) (il-make-item item))
      (entmake '((0 . "ENDBLK")))
    )
  )
  name
)

;; Layers, linetypes and every block. Safe to run again: existing records are kept.
(defun il-assets-ensure ()
  (foreach row *il-asset-linetypes* (il-ensure-linetype row))
  (foreach row *il-asset-layers* (il-ensure-layer row))
  (foreach block *il-asset-blocks* (il-ensure-block block))
  T
)

(defun il-block-data (name / found)
  (foreach block *il-asset-blocks* (if (= (car block) name) (setq found block)))
  found
)

;; Insert block NAME at POINT with ATTRIBUTES ((tag . value) ...) on LAYER; returns the INSERT. When
;; *il-layout* is set (tags of an entity) it goes on that layout, else in the current space.
(defun il-insert (name point scale layer attributes / block insert at)
  (il-ensure-block (il-block-data name))
  (setq block (il-block-data name))
  (entmake (append (list '(0 . "INSERT") (cons 8 layer) (cons 2 name) (cons 10 point) (cons 41 scale) (cons 42 scale) (cons 43 scale)
                         (cons 66 (if (vl-some '(lambda (item) (= (car item) "ATTDEF")) (cddr block)) 1 0)))
                   (if *il-layout* (list (cons 410 *il-layout*)))))
  (foreach item (cddr block)
    (if (= (car item) "ATTDEF")
      (progn
        (setq at (il-attdef-point point scale 0.0 item))
        (entmake (append (list '(0 . "ATTRIB") (cons 8 (nth 7 item)) (cons 10 at) (cons 40 (* scale (nth 4 item)))
                               (cons 1 (il-str (il-get (nth 1 item) attributes))) (cons 2 (nth 1 item))
                               (cons 70 (if (nth 6 item) 0 1)))
                         (il-align-groups item at)))
      )
    )
  )
  (if (vl-some '(lambda (item) (= (car item) "ATTDEF")) (cddr block)) (entmake '((0 . "SEQEND"))))
  (entlast)
)

;; The ATTDEF item for TAG in BLOCK data.
(defun il-attdef-item (block tag / found)
  (foreach item (cddr block)
    (if (and (= (car item) "ATTDEF") (= (strcase (nth 1 item)) (strcase tag))) (setq found item))
  )
  found
)

;; Tags placed before 0.4.2 have left-aligned text where the block now centres it: re-place those
;; attributes centred (once; a centred attribute is left where it is). Returns how many moved.
(defun il-recenter-tags (/ ss index ename data block base scale rotation next attribute item point count)
  (setq count 0)
  (if (setq ss (ssget "_X" '((0 . "INSERT") (2 . "IL-*"))))
    (progn
      (setq index 0)
      (repeat (sslength ss)
        (setq ename (ssname ss index) index (1+ index) data (entget ename) block (il-block-data (cdr (assoc 2 data))))
        (if block
          (progn
            (setq base (cdr (assoc 10 data)) scale (cdr (assoc 41 data)) next (entnext ename)
                  rotation (if (numberp (cdr (assoc 50 data))) (cdr (assoc 50 data)) 0.0))
            (while (and next (= (cdr (assoc 0 (setq attribute (entget next)))) "ATTRIB"))
              (setq item (il-attdef-item block (cdr (assoc 2 attribute))))
              (if (and item (= (nth 8 item) "center") (not (equal (cdr (assoc 72 attribute)) 1)))
                (progn
                  (setq point (il-attdef-point base scale rotation item))
                  (foreach group (cons (cons 10 point) (il-align-groups item point))
                    (setq attribute (il-set-group (car group) (cdr group) attribute))
                  )
                  (entmod attribute)
                  (setq count (1+ count))
                )
              )
              (setq next (entnext next))
            )
            (entupd ename)
          )
        )
      )
    )
  )
  count
)

;; Set attribute TAG of the INSERT ENAME to VALUE.
(defun il-set-attribute (ename tag value / next data)
  (setq next (entnext ename))
  (while (and next (= (cdr (assoc 0 (setq data (entget next)))) "ATTRIB"))
    (if (= (strcase (cdr (assoc 2 data))) (strcase tag))
      (progn (entmod (subst (cons 1 (il-str value)) (assoc 1 data) data)) (entupd ename))
    )
    (setq next (entnext next))
  )
)

;;; ---- il-commands.lsp ----
;;; il-commands.lsp -- ilLumenate CAD toolkit commands (draw-to-quote plan 3.3-3.9, 4.1-4.5).
;;;
;;; AutoCAD draws the geometry; the portal builds the products. Runs are LWPOLYLINEs with XData; rooms
;;; are closed polylines; cabinets, PSUs and tags are blocks. Hints (snap, % of max run, PSU load) come
;;; from il-math and are only hints: the import's server numbers win. No PSU sizing, voltage drop,
;;; stick packing or BOM math happens here. Command line only, so LT 2024+ and Mac work too.

(setq *il-style* nil *il-fixture-type* "L1")

(setq *il-env-choices*
  '("dry-concealed" "in-wall" "plenum" "riser" "raceway" "damp" "wet" "outdoor-exposed" "direct-burial"))

;; --- Catalog and styles -----------------------------------------------------------------------

(defun il-catalog (/ path)
  (if (null *il-catalog*)
    (progn
      (setq path (cond ((il-setting "catalog_path")) ((getenv "ILLUMENATE_CATALOG"))))
      (if (and path (findfile path))
        (progn
          (setq *il-catalog* (il-catalog-read path) *il-catalog-path* path)
          (il-catalog-warnings *il-catalog*)
        )
      )
    )
  )
  *il-catalog*
)

;; Print the catalog's staleness and minimum-toolkit warnings (on ILCATALOG and the first load).
(defun il-catalog-warnings (catalog)
  (if catalog
    (foreach warning (list (il-catalog-stale catalog (il-today)) (il-toolkit-outdated catalog))
      (if warning (princ (strcat "\nilLumenate: " warning ".")))
    )
  )
)

(defun il-require-catalog ()
  (if (null (il-catalog))
    (progn (princ "\nLoad the CAD catalog first: ILCATALOG.") (exit))
  )
  *il-catalog*
)

(defun il-styles () (il-items (il-fetch-json "STYLES")))

(defun il-save-style (style / styles kept)
  (foreach item (il-styles)
    (if (/= (il-j item "id") (il-j style "id")) (setq kept (cons item kept)))
  )
  (setq styles (cons style (reverse kept)))
  (il-store-json "STYLES" (il-arr styles))
  style
)

(defun il-style-by-id (id / found)
  (foreach style (il-styles) (if (= (il-j style "id") id) (setq found style)))
  found
)

;; --- ILCATALOG, ILSETUP --------------------------------------------------------------------------

(defun c:ILCATALOG (/ path catalog)
  (il-begin)
  (setq path (getfiled "ilLumenate CAD catalog" (if *il-catalog-path* *il-catalog-path* "") "json" 0))
  (cond
    ((null path))
    ((null (setq catalog (il-catalog-read path)))
      (princ (strcat "\nCould not read the catalog: " (il-str *il-jr-error*))))
    (T
      (setq *il-catalog* catalog *il-catalog-path* path)
      (setenv "ILLUMENATE_CATALOG" path)
      (il-set-setting "catalog_path" path)
      (il-set-setting "snapshot_hash" (il-j catalog "snapshot_hash"))
      (il-set-setting "catalog_hash" (il-j catalog "hash"))
      (princ (strcat "\nCatalog " (substr (il-str (il-j catalog "hash")) 1 8) " loaded: "
                     (itoa (length (il-items (il-j catalog "templates")))) " tape and neon templates, "
                     (itoa (length (il-items (il-j catalog "styles")))) " run styles."))
      (il-catalog-warnings catalog)
    )
  )
  (il-end)
)

(defun c:ILSETUP (/ schedule project size scale old-scale tb point)
  (il-begin)
  (il-assets-ensure)
  (if (/= (getvar "INSUNITS") 1)
    (princ "\nThis drawing is not in inches (INSUNITS=1). Lengths are read as inches; check the units.")
  )
  (setq schedule (il-ask "Portal schedule name (blank for none yet)" (il-str (il-setting "schedule"))))
  (setq project (il-ask "Portal project" (il-str (il-setting "project"))))
  (il-set-setting "schedule" schedule)
  (il-set-setting "project" project)
  (setq old-scale (il-symbol-scale))
  (initget 6)
  (setq scale (getreal (strcat "\nPlot scale factor for symbols (48 for 1/4\"=1'-0\") <" (il-num->str old-scale 2) ">: ")))
  (if scale
    (progn
      (il-set-setting "symbol_scale" scale)
      (if (not (equal scale old-scale 1e-9))
        (princ (strcat "\nResized " (itoa (il-rescale-symbols (/ (float scale) old-scale))) " placed symbols to the new scale."
                       " Place DMX and output tables again (ILDMX, ILOUT) if you have them."))
      )
    )
    (il-set-setting "symbol_scale" old-scale)
  )
  (if (setq size (il-choose "Title block" '("None" "ARCH-D" "ARCH-C" "ANSI-D" "ANSI-B" "ANSI-A") 1))
    (if (/= size "None")
      (progn
        (setq point (getpoint "\nTitle block lower-left corner <0,0>: "))
        (setq tb (il-insert (strcat "IL-TB-" size) (if point point '(0.0 0.0 0.0))
                            (if (il-paper-space-p) 1.0 (il-symbol-scale)) "E-ANNO-TTLB"
                   (list (cons "PROJECT" project) (cons "NUMBER" schedule) (cons "DATE" (il-today))
                         (cons "SCALE" (il-scale-text (il-symbol-scale)))
                         (cons "SHEET_TITLE" "LIGHTING PLAN") (cons "STAMP" "FOR REFERENCE"))))
        (princ (if (il-paper-space-p)
                 "\nTitle block placed full size on this layout."
                 (strcat "\nTitle block placed in model space at the plot scale (" (il-scale-text (il-symbol-scale))
                         "). On a layout tab it goes in full size.")))
      )
    )
  )
  (if (not (il-catalog)) (princ "\nNext: ILCATALOG to load the CAD catalog downloaded from the portal."))
  (princ "\nLayers and blocks are ready.")
  (il-end)
)

;; --- ILSTYLE ----------------------------------------------------------------------------------

(defun il-new-tape-style (catalog family / templates names template selections option value label choice values at)
  (foreach item (il-items (il-j catalog "templates"))
    (if (= (il-j item "family") family) (setq templates (cons item templates)))
  )
  (setq templates (reverse templates) names (mapcar '(lambda (item) (strcat (il-str (il-j item "code")) "  " (il-str (il-j item "name")))) templates))
  (if (null templates) (progn (princ (strcat "\nThe catalog has no " family " templates.")) (exit)))
  (if (null (setq choice (il-choose (strcat family " template") names 1))) (exit))
  (setq template (nth (vl-position choice names) templates))
  (foreach option (il-items (il-j template "options"))
    (setq values (il-items (il-j option "values")) at (vl-position (il-j option "default") values))
    (setq value (il-choose (il-str (il-j option "label")) values (if at (1+ at) 1)))
    (if value (setq selections (append selections (list (cons (il-j option "key") value)))))
  )
  (setq label (il-trim (il-ask "Style name" (strcat (il-j template "code") " " (il-join (mapcar 'cdr selections) " ")))))
  ;; Custom styles (no template) own their "custom:<CODE>" ids; this one must not replace one.
  (il-obj (list (cons "id" (strcat (if (il-custom-p (il-style-by-id (strcat "custom:" label))) "tape:" "custom:") label))
                (cons "label" label) (cons "family" family)
                (cons "template" (il-j template "code")) (cons "selections" (il-obj selections))))
)

(defun il-pick-style (styles title / names choice)
  (setq names (mapcar '(lambda (style)
                         (strcat (il-style-label style) "  [" (il-style-family style)
                                 (if (il-custom-p style) (strcat " " (il-str (il-j style "template"))) "") "]"))
                      styles))
  (if (setq choice (il-choose title names 1)) (nth (vl-position choice names) styles))
)

;; --- Custom styles (no catalog template) ---

;; A number for KEY (one of *il-custom-numbers*): Enter keeps DEFAULT, "-" clears it; asks again until
;; the answer is a number in the schema's range.
(defun il-ask-custom-number (key message default / answer value done)
  (while (not done)
    (setq answer (il-trim (getstring (strcat "\n" message
                                             (if default (strcat " <" (il-num->str default 4) ">, - clears") " (Enter skips)")
                                             ": "))))
    (cond
      ((= answer "") (setq value default done T))
      ((= answer "-") (setq value nil done T))
      ((il-custom-number-ok key (setq value (il-parse-number answer))) (setq done T))
      (T (princ (strcat "\nType a number up to " (itoa (caddr (assoc key *il-custom-numbers*)))
                        (if (cadddr (assoc key *il-custom-numbers*)) "" " (more than 0)")
                        ", Enter to keep, or - to clear.")))
    )
  )
  value
)

;; Free text: Enter keeps DEFAULT, "-" clears it.
(defun il-ask-custom-text (message default / answer)
  (setq answer (il-trim (getstring T (strcat "\n" message
                                             (if (and default (/= default "")) (strcat " <" default ">, - clears") " (Enter skips)")
                                             ": "))))
  (cond ((= answer "") default) ((= answer "-") nil) (T answer))
)

(defun il-ask-custom-color (default / answer value done)
  (while (not done)
    (setq answer (il-trim (getstring (strcat "\nColour (AutoCAD colour number 1-255) <" (itoa default) ">: "))))
    (setq value (if (= answer "") default (il-parse-number answer)))
    (if (il-custom-color-ok value) (setq done T) (princ "\nType a colour number from 1 to 255."))
  )
  (fix value)
)

;; Ask for a custom style: name, what it is, colour, W/ft, voltage, cut increment, max run, part number
;; and notes (Enter skips the optional ones). OLD (a custom style) gives the answers' defaults and keeps
;; its code; a new style's code comes from its name, unique among STYLES.
(defun il-ask-custom-style (old styles / custom label family at color answers)
  (setq custom (if old (il-j old "custom")) label "")
  (while (= label "")
    (setq label (il-trim (il-ask "Style name (for example Cove 24V 4.4 W/ft)" (if old (il-custom-label old) ""))))
  )
  (setq at (vl-position (il-j custom "family") *il-custom-families*))
  (setq family (il-choose "What it is" *il-custom-families* (if at (1+ at) 1)))
  (if (null family) (setq family (if at (nth at *il-custom-families*) "LED Tape")))
  ;; The old colour stays unless it was the old family's default and the family changed.
  (setq color (il-j custom "color"))
  (if (or (not (il-custom-color-ok color))
          (and (/= family (il-j custom "family")) (= color (il-custom-default-color (il-j custom "family")))))
    (setq color (il-custom-default-color family))
  )
  (setq answers (list (cons "label" label) (cons "family" family) (cons "color" (il-ask-custom-color (fix color)))))
  (foreach row '(("w_per_ft" "Watts per foot") ("voltage_v" "Voltage (V)")
                 ("cut_in" "Cut increment in inches (none: cut anywhere)") ("max_run_ft" "Max run from one feed, in feet"))
    (setq answers (append answers (list (cons (car row) (il-ask-custom-number (car row) (cadr row) (il-j custom (car row)))))))
  )
  (setq answers (append answers (list (cons "part_number" (il-ask-custom-text "Part number" (il-j custom "part_number")))
                                      (cons "notes" (il-ask-custom-text "Option notes (CCT, CRI, finish...)" (il-j custom "notes"))))))
  (il-custom-style (if old (il-str (il-j old "template")) (il-custom-new-code label styles)) answers)
)

;; After a custom style ID changed: retag its runs and repaint the ones showing its old colour.
(defun il-refresh-style-runs (id old-color new-color / count)
  (setq count 0)
  (foreach ename (il-entities "RUN")
    (if (= (il-get "style" (il-xget ename)) id)
      (progn
        (if (and (/= old-color new-color) (equal (cdr (assoc 62 (entget ename))) old-color)) (il-color-run ename "ok"))
        (il-tag-run ename)
        (setq count (1+ count))
      )
    )
  )
  count
)

(defun c:ILSTYLE (/ catalog source family style tape presets kits old)
  (il-begin)
  (setq catalog (il-require-catalog))
  (setq source (il-choose "Run style"
                 (append (if (il-styles) '("Recent style in this drawing"))
                         '("Saved preset" "New tape or neon style" "Custom style (no template)"))
                 1))
  (cond
    ((= source "Recent style in this drawing")
      (setq style (il-pick-style (il-styles) "Styles in this drawing"))
      (if (and (il-custom-p style) (= (il-choose (il-style-label style) '("Use" "Edit") 1) "Edit"))
        (setq old style style (il-ask-custom-style style (il-styles)))
      )
    )
    ((= source "Custom style (no template)") (setq style (il-ask-custom-style nil (il-styles))))
    ((= source "Saved preset")
      (setq presets (il-items (il-j catalog "styles")))
      (if (null presets)
        (princ "\nNo presets in the catalog. Save presets in the portal configurator, then download the catalog again.")
        (setq style (il-pick-style presets "Presets"))
      )
    )
    ((= source "New tape or neon style")
      (setq family (il-choose "Family" '("LED Tape" "COB Tape" "LED Neon") 1))
      (if family (setq style (il-new-tape-style catalog family)))
    )
  )
  (if (and style (= (il-j style "family") "Extrusion Kit") (null (il-j style "tape")))
    (progn
      (princ "\nA kit run needs the tape that goes in it.")
      (setq kits (vl-remove-if-not '(lambda (item) (il-tape-family-p (il-j item "family")))
                                   (append (il-styles) (il-items (il-j catalog "styles")))))
      (setq tape (if kits (il-pick-style kits "Tape for the kit") (il-new-tape-style catalog "LED Tape")))
      (if tape
        (progn
          (setq style (il-jset style "tape" (il-obj (list (cons "family" (il-j tape "family")) (cons "template" (il-j tape "template"))
                                                          (cons "selections" (il-j tape "selections"))))))
          (setq style (il-jset style "id" (strcat (il-j style "id") "+" (il-str (il-j tape "template")))))
        )
        (progn (princ "\nNo tape chosen; the kit style was not kept.") (setq style nil))
      )
    )
  )
  (if style
    (progn
      (il-save-style style)
      (setq *il-style* (il-j style "id"))
      (il-set-setting "current_style" *il-style*)
      (if old
        (princ (strcat "\n" (itoa (il-refresh-style-runs *il-style* (il-run-color "ok" old) (il-run-color "ok" style)))
                       " runs of this style updated."))
      )
      (princ (strcat "\nCurrent style: " (il-style-label style)
                     (if (il-custom-p style)
                       (strcat " [" (il-str (il-j style "template")) "]. On import it is mapped to a saved preset, or priced by Sales.")
                       "")))
    )
  )
  (il-end)
)

;; --- Runs: ILTAPE, ILCONVERT, ILJUMPER -------------------------------------------------------------

(defun il-run-layer (style)
  (if (member (il-style-family style) '("Linear Fixture" "Extrusion Kit")) "E-LITE-EXTR" "E-LITE-TAPE")
)

;; The run as the model sees it, from its polyline and XData.
(defun il-run-from-entity (ename / x)
  (setq x (il-xget ename))
  (list
    (cons "ename" ename)
    (cons "id" (il-get "id" x))
    (cons "handle" (il-handle ename))
    (cons "fixture_type" (il-get "type" x))
    (cons "room" (il-get "room" x))
    (cons "location" (il-get "location" x))
    (cons "style" (il-get "style" x))
    (cons "vertices" (il-lw-vertices ename))
    (cons "closed" (il-lw-closed ename))
    (cons "breaks" (il-run-breaks x))
    (cons "spans" (il-run-spans x))
    (cons "start_feed" (il-get "start_feed" x))
    (cons "lead_in" (il-number (il-get "lead_in" x)))
    (cons "jumper_in" (il-number (il-get "jumper_in" x)))
    (cons "feed_method" (if (il-get "feed" x) (il-get "feed" x) "end"))
    (cons "feed_handles" (if (il-get "feed_handles" x) (il-split (il-get "feed_handles" x) ",")))
    (cons "cabinet" (il-get "cabinet" x))
    (cons "psu_hint" (il-get "psu_hint" x))
    (cons "notes" (il-get "notes" x))
    (cons "line_key" (il-get "line_key" x))
    (cons "configured_name" (il-get "configured_name" x))
    (cons "config_hash" (il-get "config_hash" x))
    (cons "part_number" (il-get "part_number" x))
    (cons "server_in" (il-number (il-get "server_in" x)))
    (cons "layout" (cdr (assoc 410 (entget ename))))
  )
)

;; Colour by state: green ok, yellow a hint to look at, red an error (ByLayer once imported); a custom
;; style's run shows the style's colour when ok or imported (il-run-color).
(defun il-color-run (ename severity / data color)
  (setq color (il-run-color severity (il-style-by-id (il-get "style" (il-xget ename)))))
  (setq data (entget ename))
  (entmod (if (assoc 62 data) (subst (cons 62 color) (assoc 62 data) data) (append data (list (cons 62 color)))))
)

;; Ask what to do when the run is over the max run (a proposal; the configurator builds it).
(defun il-over-max (ename hint / answer)
  (princ (strcat "\nOver the " (il-num->str (il-get "max_run_ft" hint) 1) " ft max run ("
                 (il-num->str (il-get "pct_of_max" hint) 0) "%). The build splits into "
                 (itoa (il-get "runs_count" hint)) " runs: " (il-join (mapcar '(lambda (x) (il-num->str x 2)) (il-get "runs_in" hint)) " + ") " in."))
  (initget "Split Double Center")
  (setq answer (getkword "\nFeed [Split into runs/Double-end/Center] <Split>: "))
  (cond
    ((= answer "Double") (il-xupdate ename '(("feed" . "double-end"))))
    ((= answer "Center") (il-xupdate ename '(("feed" . "center"))))
    (T (il-xupdate ename '(("feed" . "end")))
       (il-add-override "TAPE_RUN_TOO_LONG" (il-get "id" (il-xget ename)) "Split into runs at the configurator's max run"))
  )
)

;; Turn ENAME (an LWPOLYLINE) into a run of the current style; returns the run id.
(defun il-make-run (ename fixture-type / style id layer data hint)
  (setq style (il-style-by-id *il-style*) id (il-next-id "RUN" (strcat fixture-type "-")))
  (setq layer (il-run-layer style) data (entget ename))
  (entmod (subst (cons 8 layer) (assoc 8 data) data))
  (il-xset ename (list (cons "kind" "RUN") (cons "id" id) (cons "type" fixture-type) (cons "style" *il-style*)
                       (cons "start_feed" "End") (cons "lead_in" "0") (cons "feed" "end")))
  (setq hint (il-run-hint (il-run-from-entity ename) style (il-catalog)))
  (princ (strcat "\n" id ": " (il-hint-text hint)))
  (if (> (il-get "runs_count" hint) 1) (il-over-max ename hint))
  (il-color-run ename (if (> (il-get "runs_count" hint) 1) "warning" "ok"))
  (il-tag-run ename)
  id
)

(defun il-require-style ()
  (if (null *il-style*) (setq *il-style* (il-setting "current_style")))
  (if (not (il-style-by-id *il-style*))
    (progn (princ "\nChoose a run style first: ILSTYLE.") (exit))
  )
)

(defun il-ask-type ()
  (if (and (= *il-fixture-type* "L1") (il-setting "fixture_type")) (setq *il-fixture-type* (il-setting "fixture_type")))
  (setq *il-fixture-type* (il-trim (il-ask "Schedule Type for these runs (for example L1)" *il-fixture-type*)))
  (if (= *il-fixture-type* "") (setq *il-fixture-type* "L1"))
  (il-set-setting "fixture_type" *il-fixture-type*)
)

(defun c:ILTAPE (/ before ename more count)
  (il-begin)
  (il-require-catalog)
  (il-require-style)
  (il-ask-type)
  (setvar "CLAYER" (progn (il-assets-ensure) (il-run-layer (il-style-by-id *il-style*))))
  (setq more T count 0)
  (while more
    (princ (if (= count 0)
             "\nDraw the run from its feed end (lines and arcs). Enter finishes the run."
             "\nDraw the next run of this style, or press Enter to stop."))
    (setq before (entlast))
    (command "_.PLINE")
    (while (> (getvar "CMDACTIVE") 0) (command pause))
    (setq ename (entlast))
    (cond
      ((or (null ename) (equal before ename) (/= (cdr (assoc 0 (entget ename))) "LWPOLYLINE")) (setq more nil))
      ((< (il-get "length_in" (il-path-length (il-lw-vertices ename) (il-lw-closed ename))) 0.01)
        (entdel ename)
        (princ "\nThat run has no length and was not kept."))
      (T (il-make-run ename *il-fixture-type*) (setq count (1+ count)))
    )
  )
  (if (> count 1) (princ (strcat "\n" (itoa count) " runs drawn.")))
  (il-end)
)

(defun c:ILCONVERT (/ ss index ename pieces closed join chains made count skipped tolerance vertices closed-p)
  (il-begin)
  (il-require-catalog)
  (il-require-style)
  (princ "\nSelect lines, arcs and polylines to make into runs of the current style.")
  (if (setq ss (ssget '((0 . "LWPOLYLINE,LINE,ARC"))))
    (progn
      (setq index 0 count 0 skipped 0)
      (repeat (sslength ss)
        (setq ename (ssname ss index) index (1+ index))
        (cond
          ((il-kind ename) (setq skipped (1+ skipped)))
          ((and (= (cdr (assoc 0 (entget ename))) "LWPOLYLINE") (il-lw-closed ename)) (setq closed (cons ename closed)))
          (T (setq pieces (cons ename pieces)))
        )
      )
      (setq pieces (reverse pieces) closed (reverse closed))
      (if (> (length pieces) 1)
        (progn
          (initget "Yes No")
          (setq join (/= (getkword "\nJoin pieces that meet end to end into one run? [Yes/No] <Yes>: ") "No"))
        )
      )
      (if (or pieces closed) (il-ask-type))
      (setq tolerance (max 0.01 (* 0.005 (il-symbol-scale))))
      (setq index 0)
      (setq chains (if join
                     (il-chain-pieces (mapcar 'il-piece-of pieces) tolerance)
                     (mapcar '(lambda (e) (setq index (1+ index)) (cons (il-piece-of e) (list (1- index)))) pieces)))
      (setvar "CLAYER" (progn (il-assets-ensure) (il-run-layer (il-style-by-id *il-style*))))
      (foreach chain chains
        (setq vertices (car chain))
        (if (and (null (cddr chain)) (= (cdr (assoc 0 (entget (nth (cadr chain) pieces)))) "LWPOLYLINE"))
          (setq made (nth (cadr chain) pieces))
          (progn
            (setq closed-p (and (> (length vertices) 2) (il-same-point (car vertices) (last vertices) tolerance)))
            (if closed-p (setq vertices (il-butlast vertices)))
            (setq made (il-make-lwpolyline vertices closed-p (nth (cadr chain) pieces)))
            (foreach i (cdr chain) (entdel (nth i pieces)))
          )
        )
        (il-make-run made *il-fixture-type*)
        (setq count (1+ count))
      )
      (foreach ename closed (il-make-run ename *il-fixture-type*) (setq count (1+ count)))
      (princ (strcat "\n" (itoa count) " runs made"
                     (if (> skipped 0) (strcat "; " (itoa skipped) " were already ilLumenate objects and were left as they are") "")
                     "."))
    )
  )
  (il-end)
)

;; The index of the vertex of ENAME nearest POINT.
(defun il-nearest-vertex (ename point / best best-distance index d)
  (setq index 0)
  (foreach vertex (il-lw-vertices ename)
    (setq d (distance (list (car vertex) (cadr vertex)) (list (car point) (cadr point))))
    (if (or (null best-distance) (< d best-distance)) (setq best index best-distance d))
    (setq index (1+ index))
  )
  best
)

(defun il-run-breaks (x) (if (il-get "breaks" x) (mapcar 'atoi (il-split (il-get "breaks" x) ","))))

;; ILJUMPER: pick the run where a jumper joins two segments. At a vertex the jumper goes there (pick it
;; again to take it off); elsewhere on a line or arc a vertex is added at that point.
(defun c:ILJUMPER (/ point ename vertices target index x breaks spans cable removed span)
  (il-begin)
  (initget "Span")
  (setq point (getpoint "\nPoint on the run where the jumper goes (object snaps work), or [Span] to mark a gap: "))
  (if (= point "Span")
    (setq point (getpoint "\nWhere the tape stops at the gap, or a point inside a span to remove it (object snaps work): ") span T)
  )
  (cond
    ((null point))
    ((null (setq ename (il-run-at point)))
      (princ "\nNo ilLumenate run at that point. Snap to the run (Nearest, Endpoint, Midpoint...)."))
    (span (il-jumper-span ename point))
    (T
      (il-snap-note ename point)
      (setq vertices (il-lw-vertices ename) x (il-xget ename) breaks (il-run-breaks x) spans (il-run-spans x))
      (setq target (il-jumper-target vertices point *il-snap-tolerance*))
      (cond
        ((and (= (car target) "split") (member (cadr target) spans))
          (il-jumper-span ename point) (setq index 'done))
        ((= (car target) "split")
          (setq index (il-run-vertex-at ename point) x (il-xget ename) breaks (vl-sort (cons index (il-run-breaks x)) '<)))
        ((or (= (cadr target) 0) (= (cadr target) (1- (length vertices))))
          (setq index nil))
        ((member (cadr target) breaks)
          (setq breaks (vl-remove (cadr target) breaks) index (cadr target) removed T))
        (T (setq index (cadr target) breaks (vl-sort (cons index breaks) '<)))
      )
      (cond
        ((eq index 'done))
        ((null index) (princ "\nThat is the end of the run. A jumper joins two segments: pick a point along the run."))
        (T
          (if (not removed)
            (progn
              (initget 4)
              (setq cable (getreal (strcat "\nJumper cable length in inches <" (if (il-get "jumper_in" x) (il-get "jumper_in" x) "12") ">: ")))
            )
          )
          (il-xupdate ename (list (cons "breaks" (il-join breaks ","))
                                  (cons "jumper_in" (if cable (il-num->str cable 2) (if (il-get "jumper_in" x) (il-get "jumper_in" x) "12")))))
          (princ (strcat "\n" (il-get "id" x) ": " (if removed "jumper removed; " "")
                         (if breaks (strcat (itoa (1+ (length breaks))) " segments joined by " (itoa (length breaks))
                                            " jumper" (if (= (length breaks) 1) "" "s") " of " (il-str (il-get "jumper_in" (il-xget ename))) " in.")
                                    "no jumpers at points.")))
          (il-tag-run ename)
        )
      )
    )
  )
  (il-end)
)

;; Snapped points are exact: a pick within this many inches of a vertex is that vertex, else a vertex is
;; added exactly where it was picked.
(setq *il-snap-tolerance* 0.01)

(setq *il-feed-directions* '("End" "Back" "Left" "Right" "Side" "Endcap"))

;; ILFEED: pick the run near the end where power comes in. The run is turned round if it was drawn
;; from the other end (the feed is always its first vertex), then the feed details are asked.
(defun c:ILFEED (/ point ename x vertices lead feed method)
  (il-begin)
  (setq point (getpoint "\nPoint at the run's feed end (snap to its Endpoint): "))
  (cond
    ((null point))
    ((null (setq ename (il-run-at point)))
      (princ "\nNo ilLumenate run at that point. Snap to the end of the run."))
    (T
      (setq vertices (il-lw-vertices ename) x (il-xget ename))
      (if (and (not (il-lw-closed ename))
               (< (distance (il-xy (last vertices)) (il-xy point)) (distance (il-xy (car vertices)) (il-xy point))))
        (progn
          (il-lw-set-vertices ename (il-reverse-vertices vertices))
          (il-save-run-links ename (il-reverse-breaks (il-run-breaks x) (length vertices)) (il-reverse-spans (il-run-spans x) (length vertices)))
          (princ "\nRun turned round: it now starts at this end.")
        )
      )
      (setq x (il-xget ename))
      (setq feed (il-choose "Start feed direction (where the lead leaves the tape)" *il-feed-directions*
                            (1+ (if (vl-position (il-get "start_feed" x) *il-feed-directions*) (vl-position (il-get "start_feed" x) *il-feed-directions*) 0))))
      (initget 4)
      (setq lead (getreal (strcat "\nLead cable from the run to its power supply, inches <" (il-str (il-get "lead_in" x)) ">: ")))
      (initget "End Double Center Multi")
      (setq method (getkword (strcat "\nFeed method [End/Double-end/Center/Multi-feed] <" (il-str (il-get "feed" x)) ">: ")))
      (il-xupdate ename (list (cons "start_feed" (if feed feed (il-get "start_feed" x)))
                              (cons "lead_in" (if lead (il-num->str lead 2) (il-get "lead_in" x)))
                              (cons "feed" (cond ((= method "Double") "double-end") ((= method "Center") "center") ((= method "Multi") "multi-feed") ((= method "End") "end") (T (il-get "feed" x))))))
      (il-tag-run ename)
    )
  )
  (il-end)
)

(defun il-scale-text (factor / inches)
  (setq inches (/ 12.0 factor))
  (cond
    ((equal inches 1.0 1e-6) "1\" = 1'-0\"")
    ((equal inches 0.75 1e-6) "3/4\" = 1'-0\"")
    ((equal inches 0.5 1e-6) "1/2\" = 1'-0\"")
    ((equal inches 0.375 1e-6) "3/8\" = 1'-0\"")
    ((equal inches 0.25 1e-6) "1/4\" = 1'-0\"")
    ((equal inches 0.1875 1e-6) "3/16\" = 1'-0\"")
    ((equal inches 0.125 1e-6) "1/8\" = 1'-0\"")
    ((equal inches 0.0625 1e-6) "1/16\" = 1'-0\"")
    (T (strcat "1:" (il-num->str factor 2)))
  )
)

(defun il-piece-of (ename / data center vertices)
  (setq data (entget ename))
  (setq vertices
    (cond
      ((= (cdr (assoc 0 data)) "LINE")
        (list (append (il-xy (cdr (assoc 10 data))) '(0.0)) (append (il-xy (cdr (assoc 11 data))) '(0.0))))
      ((= (cdr (assoc 0 data)) "ARC")
        (il-arc-piece (cdr (assoc 10 data)) (cdr (assoc 40 data)) (cdr (assoc 50 data)) (cdr (assoc 51 data))))
      (T (il-lw-vertices ename))
    )
  )
  (if (and (assoc 210 data) (< (cadddr (assoc 210 data)) 0) (/= (cdr (assoc 0 data)) "LINE"))
    (setq vertices (mapcar '(lambda (v) (list (- (car v)) (cadr v) (- (il-bulge v)))) vertices))
  )
  vertices
)

(defun il-make-lwpolyline (vertices closed like / data)
  (setq data (entget like))
  (entmake (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (assoc 8 data))
                   (if (assoc 410 data) (list (assoc 410 data)))
                   (list '(100 . "AcDbPolyline") (cons 90 (length vertices)) (cons 70 (if closed 1 0)))
                   (apply 'append (mapcar '(lambda (v) (list (list 10 (car v) (cadr v)) (cons 42 (il-bulge v)))) vertices))))
  (entlast)
)

(defun il-run-spans (x) (if (il-get "spans" x) (mapcar 'atoi (il-split (il-get "spans" x) ","))))

(defun il-save-run-links (ename breaks spans)
  (il-xupdate ename (list (cons "breaks" (il-join breaks ",")) (cons "spans" (il-join spans ","))))
)

(defun il-run-vertex-at (ename point / vertices target x)
  (setq vertices (il-lw-vertices ename) target (il-jumper-target vertices point *il-snap-tolerance*))
  (if (= (car target) "split")
    (progn
      (setq x (il-xget ename))
      (il-lw-set-vertices ename (il-insert-vertex vertices (cadr target) (caddr target)))
      (il-save-run-links ename (il-shift-breaks (il-run-breaks x) (cadr target)) (il-split-spans (il-run-spans x) (cadr target)))
      (1+ (cadr target))
    )
    (cadr target)
  )
)

(defun il-span-length (vertices spans / total)
  (setq total 0.0)
  (foreach s spans (setq total (+ total (il-segment-length (nth s vertices) (nth (1+ s) vertices) (il-bulge (nth s vertices))))))
  total
)

(defun il-jumper-span (ename first / second a b x spans breaks vertices group low target)
  (setq vertices (il-lw-vertices ename) x (il-xget ename) spans (il-run-spans x))
  (setq target (il-jumper-target vertices first *il-snap-tolerance*))
  (setq group (if (= (car target) "split") (il-span-group spans (cadr target))))
  (if group
    (progn
      (il-save-run-links ename (il-run-breaks x) (vl-remove-if '(lambda (s) (member s group)) spans))
      (princ (strcat "\n" (il-get "id" x) ": jumper span removed; that stretch counts as tape again."))
    )
    (if (setq second (getpoint first "\nWhere the tape starts again after the gap (object snaps work): "))
      (progn
        (il-snap-note ename first)
        (il-snap-note ename second)
        (setq first (il-segment-point-on ename first) second (il-segment-point-on ename second))
        (il-run-vertex-at ename first)
        (il-run-vertex-at ename second)
        (setq a (il-vertex-index-at ename first) b (il-vertex-index-at ename second))
        (if (> a b) (setq low b b a a low))
        (if (= a b)
          (princ "\nPick two different points along the run.")
          (progn
            (setq x (il-xget ename) vertices (il-lw-vertices ename) spans (il-run-spans x) breaks (il-run-breaks x) low a)
            (while (< low b) (if (not (member low spans)) (setq spans (cons low spans))) (setq low (1+ low)))
            (setq spans (vl-sort spans '<) breaks (vl-remove-if '(lambda (i) (and (>= i a) (<= i b))) breaks))
            (il-save-run-links ename breaks spans)
            (princ (strcat "\n" (il-get "id" x) ": jumper span of "
                           (il-num->str (il-span-length vertices (il-span-group spans a)) 2)
                           " in. It is jumper cable, not tape, and its drawn length is the jumper's length."))
          )
        )
      )
    )
  )
  (il-tag-run ename)
)

(defun il-tag-index (/ ss index ename owner result pair)
  (if (setq ss (ssget "_X" (list '(0 . "INSERT") (list -3 (list *il-app*)))))
    (progn
      (setq index 0)
      (repeat (sslength ss)
        (setq ename (ssname ss index) index (1+ index) owner (il-get "owner" (il-xget ename)))
        (if owner
          (setq result (if (setq pair (assoc owner result))
                         (subst (cons owner (cons ename (cdr pair))) pair result)
                         (cons (list owner ename) result)))
        )
      )
    )
  )
  result
)

(defun il-run-anchor (run)
  (if (il-get "closed" run) (il-centroid (il-get "vertices" run)) (il-path-point (il-get "vertices" run) 0.5))
)

(defun il-pick-tolerance (/ box size screen)
  (setq box (getvar "PICKBOX") size (getvar "VIEWSIZE") screen (getvar "SCREENSIZE"))
  (if (and (numberp box) (numberp size) (listp screen) (numberp (cadr screen)) (> (cadr screen) 0))
    (max 1e-6 (* 1.5 box (/ size (cadr screen))))
    0.5
  )
)

(defun il-run-at (point / tolerance best best-d d near picked)
  (setq tolerance (il-pick-tolerance))
  (foreach ename (il-entities "RUN")
    (setq d (il-distance-to-path (il-lw-vertices ename) (il-lw-closed ename) point))
    (if (and d (<= d tolerance))
      (progn
        (if (and best-d (< (abs (- d best-d)) *il-snap-tolerance*)) (setq near T))
        (if (or (null best-d) (< d (- best-d *il-snap-tolerance*))) (setq best ename best-d d near nil))
      )
    )
  )
  (if near
    (progn
      (setq picked (entsel "\nMore than one run meets at that point. Select the one you mean: "))
      (if (and picked (= (il-kind (car picked)) "RUN")) (car picked))
    )
    best
  )
)

(defun il-snap-note (ename point / d)
  (setq d (il-distance-to-path (il-lw-vertices ename) (il-lw-closed ename) point))
  (if (and d (> d *il-snap-tolerance*))
    (princ (strcat "\nThat point is " (il-num->str d 2) " in off the run; using the nearest point on it. Snap to the run to be exact."))
  )
)

(defun il-vertex-index-at (ename point / found index)
  (setq index 0)
  (foreach vertex (il-lw-vertices ename)
    (if (and (null found) (<= (distance (il-xy vertex) (il-xy point)) *il-snap-tolerance*)) (setq found index))
    (setq index (1+ index))
  )
  (if found found (il-nearest-vertex ename point))
)

(defun il-segment-point-on (ename point / target vertices)
  (setq vertices (il-lw-vertices ename) target (il-jumper-target vertices point *il-snap-tolerance*))
  (if (= (car target) "split") (append (il-xy (cadddr target)) '(0.0)) (append (il-xy (nth (cadr target) vertices)) '(0.0)))
)

;; --- Tags ---------------------------------------------------------------------------------------

(defun il-delete-tags (owner-handle)
  (foreach ename (il-owned-tags owner-handle) (entdel ename))
  (if *il-tag-index* (setq *il-tag-index* (vl-remove-if '(lambda (pair) (= (car pair) owner-handle)) *il-tag-index*)))
)

;; (Re)place the run's tag halfway along it with id, style, lengths and part number, and its markers.
;; Feed and jumper markers of RUN, owned by it so ILUPDATE redraws them: the feed at the first vertex
;; (both ends for double-end feeding, halfway along for a centre feed), a jumper at every break.
(defun il-run-markers (run owner / vertices count points)
  (setq vertices (il-get "vertices" run) count (length vertices))
  (setq points (cond ((= (il-get "feed_method" run) "double-end") (list (il-xy (car vertices)) (il-xy (last vertices))))
                     ((= (il-get "feed_method" run) "center") (list (il-path-point vertices 0.5)))
                     (T (list (il-xy (car vertices))))))
  (foreach point points
    (il-xset (il-insert "IL-FEED" (list (car point) (cadr point) 0.0) (il-symbol-scale) "E-LITE-FEED" nil)
             (list (cons "kind" "TAG") (cons "owner" owner)))
  )
  (foreach index (il-get "breaks" run)
    (if (and (> index 0) (< index (1- count)))
      (il-xset (il-insert "IL-JUMPER" (append (il-xy (nth index vertices)) '(0.0)) (il-symbol-scale) "E-LITE-FEED" nil)
               (list (cons "kind" "TAG") (cons "owner" owner)))
    )
  )
  (foreach index (il-get "spans" run)
    (if (< index (1- count))
      (il-xset (il-insert "IL-JUMPER" (append (il-segment-point (nth index vertices) (nth (1+ index) vertices) (il-bulge (nth index vertices)) 0.5) '(0.0))
                          (il-symbol-scale) "E-LITE-FEED" nil)
               (list (cons "kind" "TAG") (cons "owner" owner)))
    )
  )
)

;; Feed and jumper markers placed by toolkit 0.4.2 and earlier had no owner: ILUPDATE redraws them.
(defun il-clear-loose-markers (/ ss index ename)
  (if (setq ss (ssget "_X" '((0 . "INSERT") (2 . "IL-FEED,IL-JUMPER"))))
    (progn
      (setq index 0)
      (repeat (sslength ss)
        (setq ename (ssname ss index) index (1+ index))
        (if (null (il-get "owner" (il-xget ename))) (entdel ename))
      )
    )
  )
)

(defun il-tag-run (ename / run style hint tag)
  (setq run (il-run-from-entity ename) style (il-style-by-id (il-get "style" run)))
  (setq hint (il-run-hint run style (il-catalog)))
  (setq *il-layout* (cdr (assoc 410 (entget ename))))
  (il-delete-tags (il-handle ename))
  (il-run-markers run (il-handle ename))
  (setq tag (il-insert "IL-RUNTAG" (il-run-anchor run) (il-symbol-scale) "E-ANNO-TAGS"
              (list (cons "TAG" (il-get "id" run))
                    (cons "STYLE" (if style (il-style-label style) "no style"))
                    (cons "LENGTH" (if (il-get "server_in" run)
                                     (strcat (il-num->str (il-get "server_in" run) 2) " in built")
                                     (il-hint-text hint)))
                    (cons "PART" (il-get "part_number" run)))))
  (il-xset tag (list (cons "kind" "TAG") (cons "owner" (il-handle ename))))
  (setq *il-layout* nil)
  tag
)

;; --- Copies and symbol scale ------------------------------------------------------------------

;; Kinds that carry an id, and the attribute that shows it (on the entity when it is a block, else
;; on the tag it owns). Run tags are redrawn by il-tag-run, so runs need none.
(setq *il-copy-kinds* '(("RUN" nil) ("ROOM" "ID") ("WIRE" "TAG") ("CABINET" "TAG") ("PSU" "TAG") ("CONTROL" "TAG")))

;; What a copy must not inherit: the portal line its original was imported as, the runs a PSU
;; feeds, a fixed DMX address.
(setq *il-copy-resets*
  '(("RUN" ("line_key") ("configured_name") ("config_hash") ("part_number") ("server_in") ("feed_handles"))
    ("PSU" ("runs"))
    ("CONTROL" ("start" . "auto"))))

;; Where an entity sits: a block's insertion point, a polyline's centroid.
(defun il-ref-point (ename / data)
  (setq data (entget ename))
  (if (= (cdr (assoc 0 data)) "INSERT") (cdr (assoc 10 data)) (il-centroid (il-lw-vertices ename)))
)

(defun il-owned-tags (owner-handle / ss index ename result)
  (if *il-tag-index*
    (vl-remove-if-not '(lambda (e) (entget e)) (cdr (assoc owner-handle *il-tag-index*)))
    (progn
      (if (setq ss (ssget "_X" (list '(0 . "INSERT") (list -3 (list *il-app*)))))
        (progn
          (setq index 0)
          (repeat (sslength ss)
            (setq ename (ssname ss index) index (1+ index))
            (if (= (il-get "owner" (il-xget ename)) owner-handle) (setq result (cons ename result)))
          )
        )
      )
      result
    )
  )
)

;; Tags copied with an entity still name the original as owner: give the copy the ones nearer to it.
(defun il-adopt-tags (original copy attribute id / here there point)
  (setq here (il-ref-point copy) there (il-ref-point original))
  (foreach tag (il-owned-tags (il-handle original))
    (setq point (cdr (assoc 10 (entget tag))))
    (if (< (distance point here) (distance point there))
      (progn
        (il-xupdate tag (list (cons "owner" (il-handle copy))))
        (if attribute (il-set-attribute tag attribute id))
      )
    )
  )
)

;; COPY, ARRAY and paste duplicate XData, id included. Give every copy its own id, drop what it must
;; not inherit, and record each entity's own handle ("self") so later copies are told apart.
(defun il-fix-copies (verbose / kind attribute enames x records copy original old id block-p)
  (foreach row *il-copy-kinds*
    (setq kind (car row) attribute (cadr row) enames (il-entities kind) records nil)
    (foreach ename enames
      (setq x (il-xget ename))
      (setq records (cons (list ename (il-get "id" x) (il-get "self" x) (il-handle ename)) records))
    )
    (foreach pair (il-copies (reverse records))
      (setq copy (car pair) original (handent (cdr pair)) old (il-get "id" (il-xget copy)))
      (setq id (il-next-id kind (il-id-prefix old)) block-p (= (cdr (assoc 0 (entget copy))) "INSERT"))
      (il-xupdate copy (cons (cons "id" id) (cdr (assoc kind *il-copy-resets*))))
      (if (and attribute block-p) (il-set-attribute copy attribute id))
      (if original (il-adopt-tags original copy (if block-p nil attribute) id))
      (if verbose (princ (strcat "\nCopy of " old " is now " id ".")))
    )
    (foreach ename enames
      (if (/= (il-get "self" (il-xget ename)) (il-handle ename))
        (il-xupdate ename (list (cons "self" (il-handle ename))))
      )
    )
  )
)

;; Resize every placed toolkit symbol by FACTOR about its insertion point; title blocks stay 1:1.
(defun il-rescale-symbols (factor / ss index ename data base next count)
  (setq count 0)
  (if (setq ss (ssget "_X" '((0 . "INSERT") (2 . "IL-*"))))
    (progn
      (setq index 0)
      (repeat (sslength ss)
        (setq ename (ssname ss index) index (1+ index) data (entget ename))
        (if (not (il-starts-with (cdr (assoc 2 data)) "IL-TB-"))
          (progn
            (setq base (cdr (assoc 10 data)))
            (foreach code '(41 42 43)
              (if (assoc code data) (setq data (subst (cons code (* factor (cdr (assoc code data)))) (assoc code data) data)))
            )
            (entmod data)
            (setq next (entnext ename))
            (while (and next (= (cdr (assoc 0 (setq data (entget next)))) "ATTRIB"))
              (setq data (subst (cons 10 (il-scale-about base (cdr (assoc 10 data)) factor)) (assoc 10 data) data))
              (if (and (assoc 11 data) (or (/= 0 (il-num-or-0 (cdr (assoc 72 data)))) (/= 0 (il-num-or-0 (cdr (assoc 74 data))))))
                (setq data (subst (cons 11 (il-scale-about base (cdr (assoc 11 data)) factor)) (assoc 11 data) data))
              )
              (setq data (subst (cons 40 (* factor (cdr (assoc 40 data)))) (assoc 40 data) data))
              (entmod data)
              (setq next (entnext next))
            )
            (entupd ename)
            (setq count (1+ count))
          )
        )
      )
    )
  )
  count
)

(defun il-num-or-0 (value) (if (numberp value) value 0))

;; --- Site: ILSCALE, ILROOM, ILCAB, ILPSU, ILCONNECT, ILWIRE --------------------------------------

(defun c:ILSCALE (/ ss first second measured actual factor)
  (il-begin)
  (princ "\nSelect the underlay to calibrate (PDF underlay, image or xref).")
  (if (and (setq ss (ssget))
           (setq first (getpoint "\nFirst point of a known dimension: "))
           (setq second (getpoint first "\nSecond point: ")))
    (progn
      (setq measured (distance first second))
      (if (< measured 1e-6)
        (princ "\nThose are the same point. Pick both ends of a dimension you know.")
        (progn
          (initget 6)
          (setq actual (getdist "\nTrue length of that dimension (inches, or feet with ', for example 12'6\"): "))
          (if actual
            (progn
              (setq factor (/ actual measured))
              (command "_.SCALE" ss "" "_non" first factor)
              (il-set-setting "scale_verified" 'IL-TRUE)
              (princ (strcat "\nScaled by " (il-num->str factor 6) ". Scale verified."))
            )
          )
        )
      )
    )
  )
  (il-end)
)

(defun il-room-slug (name)
  (strcat "Z-" (il-replace-all (il-replace-all (il-trim name) " " "-") "/" "-"))
)

(defun c:ILROOM (/ picked ename point before name level env id x other)
  (il-begin)
  (il-assets-ensure)
  (initget "Pick")
  (setq picked (entsel "\nSelect the room's closed polyline, or [Pick a point inside]: "))
  (cond
    ((= picked "Pick")
      (if (setq point (getpoint "\nPoint inside the room: "))
        (progn
          (setq before (entlast))
          (command "_.-BOUNDARY" "_Advanced" "_Object" "_Polyline" "" "_non" point "")
          (if (not (equal before (entlast))) (setq ename (entlast)))
        )
      )
    )
    ((and (listp picked) picked (il-kind (car picked)) (/= (il-kind (car picked)) "ROOM"))
      (princ (strcat "\nThat is an ilLumenate " (il-kind (car picked)) ", not a room outline.")))
    ((and (listp picked) picked (= (cdr (assoc 0 (entget (car picked)))) "LWPOLYLINE") (il-lw-closed (car picked)))
      (setq ename (car picked)))
  )
  (if ename
    (progn
      (setq x (il-xget ename))
      (setq name (il-trim (il-ask "Room name" (if (il-get "name" x) (il-get "name" x) "Room"))))
      (if (= name "") (setq name "Room"))
      (setq level (il-ask "Level" (if (il-get "level" x) (il-get "level" x) "L1")))
      (setq env (il-choose "Environment" *il-env-choices*
                           (if (vl-position (il-get "env" x) *il-env-choices*) (1+ (vl-position (il-get "env" x) *il-env-choices*)) 1)))
      (setq id (il-room-slug name))
      (if (and (setq other (il-find-id "ROOM" id)) (not (equal other ename)))
        (progn (setq id (il-next-id "ROOM" (strcat id "-"))) (princ (strcat "\nAnother room is already " (il-room-slug name) "; this one is " id ".")))
      )
      (entmod (subst (cons 8 "E-ANNO-ROOM") (assoc 8 (entget ename)) (entget ename)))
      (il-xset ename (list (cons "kind" "ROOM") (cons "id" id) (cons "name" name) (cons "level" level) (cons "env" env)
                           (cons "self" (il-handle ename))))
      (setq *il-layout* (cdr (assoc 410 (entget ename))))
      (il-delete-tags (il-handle ename))
      (il-xset (il-insert "IL-ROOMTAG" (il-centroid (il-lw-vertices ename)) (il-symbol-scale) "E-ANNO-ROOM"
                 (list (cons "NAME" name) (cons "ID" id) (cons "ENV" env)))
               (list (cons "kind" "TAG") (cons "owner" (il-handle ename))))
      (setq *il-layout* nil)
      (princ (strcat "\nRoom " id " (" env "). Runs and equipment inside it pick it up on ILUPDATE."))
    )
    (if (not (and (listp picked) picked (il-kind (car picked)))) (princ "\nNo closed polyline."))
  )
  (il-end)
)

;; The room containing POINT, as its id.
(defun il-room-at (point / found x)
  (foreach ename (il-entities "ROOM")
    (if (and (null found) (il-point-in-polygon point (il-lw-vertices ename)))
      (setq found (il-get "id" (il-xget ename)))
    )
  )
  found
)

(defun c:ILCAB (/ point id rating note insert)
  (il-begin)
  (il-assets-ensure)
  (if (setq point (getpoint "\nCabinet or PSU location: "))
    (progn
      (setq id (il-ask-id "CABINET" "Cabinet tag" "CAB-"))
      (initget "Dry Damp Wet")
      (setq rating (getkword "\nLocation rating [Dry/Damp/Wet] <Dry>: "))
      (setq note (il-ask "Access note" ""))
      (setq insert (il-insert "IL-CABINET" point (il-symbol-scale) "E-POWR-CABN"
                     (list (cons "TAG" id) (cons "RATING" (if rating rating "Dry")) (cons "ACCESS" note))))
      (il-xset insert (list (cons "kind" "CABINET") (cons "id" id) (cons "room" (il-room-at point))
                            (cons "rating" (if rating rating "Dry")) (cons "access" note) (cons "self" (il-handle insert))))
      (princ (strcat "\nCabinet " id "."))
    )
  )
  (il-end)
)

(defun il-nearest (kind point / best best-distance d)
  (foreach ename (il-entities kind)
    (setq d (distance (cdr (assoc 10 (entget ename))) point))
    (if (or (null best-distance) (< d best-distance)) (setq best ename best-distance d))
  )
  best
)

(defun c:ILPSU (/ point id cabinet drivers names model insert)
  (il-begin)
  (il-assets-ensure)
  (if (setq point (getpoint "\nPSU location: "))
    (progn
      (setq id (il-ask-id "PSU" "PSU tag" "PS-"))
      (setq cabinet (il-cabinet-for point))
      (setq drivers (if (il-catalog) (il-items (il-j (il-catalog) "drivers"))))
      (setq names (cons "Choose in the System Designer"
                        (mapcar '(lambda (d) (strcat (il-str (il-j d "code")) "  "
                                                     (if (il-number (il-j d "rated_w")) (strcat (il-num->str (il-number (il-j d "rated_w")) 0) " W") "rating unknown")))
                                drivers)))
      (setq model (il-choose "Model (optional; the System Designer sizes and assigns)" names 1))
      (if (= model "Choose in the System Designer") (setq model nil) (if model (setq model (car (il-split model "  ")))))
      (setq insert (il-insert "IL-PSUTAG" point (il-symbol-scale) "E-POWR-EQPM" (list (cons "TAG" id) (cons "MODEL" model))))
      (il-xset insert (list (cons "kind" "PSU") (cons "id" id)
                            (cons "cabinet" (if cabinet (il-get "id" (il-xget cabinet))))
                            (cons "item_code" model) (cons "self" (il-handle insert))))
      (princ (strcat "\nPSU " id (if cabinet (strcat " in " (il-get "id" (il-xget cabinet))) "") ". Connect runs with ILCONNECT."))
    )
  )
  (il-end)
)

(defun c:ILCONNECT (/ picked psu x runs ss index ename cabinet action id moved others other-runs)
  (il-begin)
  (if (and (setq picked (entsel "\nPick the PSU: ")) (= (il-kind (setq psu (car picked))) "PSU"))
    (progn
      (setq x (il-xget psu) runs (if (il-get "runs" x) (il-split (il-get "runs" x) ",")) cabinet (il-get "cabinet" x))
      (initget "Add Remove")
      (setq action (getkword (strcat "\n" (il-get "id" x) " feeds " (if runs (il-join runs ", ") "nothing yet") ". [Add runs/Remove runs] <Add>: ")))
      (princ (if (= action "Remove") "\nSelect the runs to take off it." "\nSelect the runs it feeds."))
      (if (setq ss (ssget '((0 . "LWPOLYLINE"))))
        (progn
          (setq index 0)
          (repeat (sslength ss)
            (setq ename (ssname ss index) index (1+ index) id (il-get "id" (il-xget ename)))
            (if (and (= (il-kind ename) "RUN") id)
              (if (= action "Remove")
                (setq runs (vl-remove id runs))
                (progn
                  (if (not (member id runs)) (setq runs (append runs (list id))))
                  (if cabinet (il-xupdate ename (list (cons "cabinet" cabinet))))
                  ;; A run has one supply: take it off any other PSU.
                  (foreach other (il-entities "PSU")
                    (if (and (not (equal other psu))
                             (member id (setq other-runs (if (il-get "runs" (il-xget other)) (il-split (il-get "runs" (il-xget other)) ",")))))
                      (progn
                        (il-xupdate other (list (cons "runs" (il-join (vl-remove id other-runs) ","))))
                        (setq moved (cons (strcat id " from " (il-get "id" (il-xget other))) moved))
                        (if (not (member other others)) (setq others (cons other others)))
                      )
                    )
                  )
                )
              )
            )
          )
          (il-xupdate psu (list (cons "runs" (il-join runs ","))))
          (princ (strcat "\n" (il-get "id" x) " feeds " (if runs (il-join runs ", ") "nothing") "."))
          (if moved (princ (strcat "\nMoved " (il-join (reverse moved) ", ") ".")))
          (foreach other (cons psu others) (il-update-psu-tag other))
        )
      )
    )
    (princ "\nThat is not an ilLumenate PSU.")
  )
  (il-end)
)

(defun il-end-id (ename / kind)
  (setq kind (il-kind ename))
  (if (member kind '("RUN" "PSU" "CABINET" "CONTROL")) (il-get "id" (il-xget ename)))
)

(defun c:ILWIRE (/ from to kind before ename id layer wire-length)
  (il-begin)
  (il-assets-ensure)
  (if (setq from (il-pick-end "\nPick where the wire starts (PSU, cabinet, control or run): "))
    (progn
      (initget "Lv Line Data")
      (setq kind (getkword "\nWire [Lv class 2/Line voltage/Data] <Lv>: "))
      (setq kind (cond ((= kind "Line") "line") ((= kind "Data") "data") (T "lv")))
      (setq layer (cond ((= kind "line") "E-POWR-WIRE-LINE") ((= kind "data") "E-LITE-DATA") (T "E-LITE-WIRE-CL2")))
      (setvar "CLAYER" layer)
      (princ "\nDraw the wire's path. Press Enter to finish.")
      (setq before (entlast))
      (command "_.PLINE")
      (while (> (getvar "CMDACTIVE") 0) (command pause))
      (setq ename (entlast))
      (cond
        ((or (equal before ename) (/= (cdr (assoc 0 (entget ename))) "LWPOLYLINE")) (princ "\nNo wire drawn."))
        ((null (setq to (il-pick-end "\nPick where the wire ends (PSU, cabinet, control or run): ")))
          (princ "\nThe path is drawn but not recorded as a wire. Erase it, or run ILWIRE again and draw over it."))
        (T
          (setq id (il-next-id "WIRE" "W-"))
          (il-xset ename (list (cons "kind" "WIRE") (cons "id" id) (cons "from" from) (cons "to" to) (cons "wire" kind) (cons "self" (il-handle ename))))
          (setq wire-length (il-get "length_in" (il-path-length (il-lw-vertices ename) nil)))
          (il-tag-wire ename)
          (princ (strcat "\n" id ": " from " to " to ", " (il-num->str (/ wire-length 12.0) 1) " ft path (slack and waste are added in the System Designer)."))
        )
      )
    )
    (princ "\nPick a PSU, cabinet, control or run.")
  )
  (il-end)
)

(defun il-cabinet-for (point / near picked)
  (setq near (il-nearest "CABINET" point))
  (cond
    ((and near (<= (distance (il-xy (cdr (assoc 10 (entget near)))) (il-xy point)) (* 1.5 (il-symbol-scale)))) near)
    ((il-entities "CABINET")
      (setq picked (entsel "\nNot at a cabinet. Pick the cabinet it goes in, or press Enter for none: "))
      (if (and picked (= (il-kind (car picked)) "CABINET")) (car picked)))
  )
)

(defun il-pick-end (message / picked id done)
  (while (not done)
    (setq picked (entsel message))
    (cond
      ((null picked) (setq done T))
      ((setq id (il-end-id (car picked))) (setq done T))
      (T (princ "\nThat is not a PSU, cabinet, control or run; pick again, or press Enter to stop."))
    )
  )
  id
)

(defun il-tag-wire (ename / x wire-length text tags)
  (setq x (il-xget ename) wire-length (il-get "length_in" (il-path-length (il-lw-vertices ename) nil)))
  (setq text (strcat (il-num->str (/ wire-length 12.0) 1) "'") tags (il-owned-tags (il-handle ename)))
  (if tags
    (foreach tag tags (il-set-attribute tag "LENGTH" text) (il-set-attribute tag "TAG" (il-get "id" x)))
    (progn
      (setq *il-layout* (cdr (assoc 410 (entget ename))))
      (il-xset (il-insert "IL-WIRETAG" (il-path-point (il-lw-vertices ename) 0.5) (il-symbol-scale) "E-ANNO-TAGS"
                 (list (cons "TAG" (il-get "id" x)) (cons "LENGTH" text)))
               (list (cons "kind" "TAG") (cons "owner" (il-handle ename))))
      (setq *il-layout* nil)
    )
  )
)

(defun il-update-psu-tag-in (psu model / x loads hint driver result)
  (setq x (il-xget psu))
  (foreach run (il-get "runs" model)
    (if (member (il-get "id" run) (if (il-get "runs" x) (il-split (il-get "runs" x) ",")))
      (if (il-get "watts" (setq hint (il-run-hint run (il-model-style model (il-get "style" run)) (il-catalog))))
        (setq loads (cons (il-get "watts" hint) loads))
      )
    )
  )
  (foreach item (if (il-catalog) (il-items (il-j (il-catalog) "drivers")))
    (if (= (il-j item "code") (il-get "item_code" x)) (setq driver item))
  )
  (if (and driver (il-number (il-j driver "rated_w")))
    (progn
      (setq result (il-psu-load loads (il-number (il-j driver "rated_w")) (il-j driver "usable_load_factor")))
      (il-set-attribute psu "LOAD" (strcat (il-num->str (il-get "total_w" result) 1) " W  " (il-num->str (il-get "pct_of_usable" result) 0) "%"))
    )
    (il-set-attribute psu "LOAD" (strcat (il-num->str (il-sum loads) 1) " W"))
  )
)

(defun il-rooms-index ()
  (mapcar '(lambda (ename) (cons (il-get "id" (il-xget ename)) (cons (il-get "name" (il-xget ename)) (il-lw-vertices ename))))
          (il-entities "ROOM"))
)

(defun il-room-in (rooms point / found)
  (foreach room rooms
    (if (and (null found) (il-point-in-polygon point (cddr room))) (setq found room))
  )
  found
)

(defun il-prune-links (/ ids x kept zones changed)
  (setq ids (mapcar '(lambda (e) (il-get "id" (il-xget e))) (il-entities "RUN")))
  (foreach psu (il-entities "PSU")
    (setq x (il-xget psu))
    (if (il-get "runs" x)
      (progn
        (setq kept (vl-remove-if-not '(lambda (id) (member id ids)) (il-split (il-get "runs" x) ",")))
        (if (/= (length kept) (length (il-split (il-get "runs" x) ","))) (il-xupdate psu (list (cons "runs" (il-join kept ",")))))
      )
    )
  )
  (setq zones (mapcar '(lambda (zone / runs)
                         (setq runs (il-items (il-j zone "runs")))
                         (if (vl-some '(lambda (id) (not (member id ids))) runs) (setq changed T))
                         (il-jset zone "runs" (il-arr (vl-remove-if-not '(lambda (id) (member id ids)) runs))))
                      (il-zones)))
  (if changed (il-store-json "ZONES" (il-arr zones)))
)

(defun il-worst-severity (issues ref overrides / worst)
  (foreach issue issues
    (if (and (= (il-get "ref" issue) ref) (not (il-overridden-p issue overrides)))
      (cond
        ((= (il-get "severity" issue) "error") (setq worst "error"))
        ((and (= (il-get "severity" issue) "warning") (/= worst "error")) (setq worst "warning"))
      )
    )
  )
  worst
)

(defun il-next-zone-id (zones / number)
  (setq number 1)
  (while (vl-some '(lambda (z) (= (il-j z "id") (strcat "ZN-" (itoa number)))) zones) (setq number (1+ number)))
  (strcat "ZN-" (itoa number))
)

(defun il-num-text (value digits) (if (il-number value) (il-num->str (il-number value) digits) ""))

;; --- Other lines and overrides ----------------------------------------------------------------

(defun c:ILOTHER (/ others fixture-type qty maker model watts action)
  (il-begin)
  (setq others (il-items (il-fetch-json "OTHERS")))
  (if others
    (princ (strcat "\nOther-manufacturer lines: " (il-join (mapcar '(lambda (o) (strcat (il-str (il-j o "fixture_type")) " x" (il-str (il-j o "qty")))) others) ", ")))
  )
  (setq fixture-type (il-trim (il-ask "Schedule Type of the other manufacturer's fixture" "X1")))
  (if (vl-some '(lambda (o) (= (il-j o "fixture_type") fixture-type)) others)
    (progn
      (initget "Replace Delete")
      (setq action (getkword (strcat "\n" fixture-type " is already in this drawing. [Replace/Delete] <Replace>: ")))
    )
  )
  (setq others (vl-remove-if '(lambda (o) (= (il-j o "fixture_type") fixture-type)) others))
  (if (= action "Delete")
    (princ (strcat "\n" fixture-type " removed."))
    (progn
      (initget 7)
      (setq qty (getint "\nQuantity: "))
      (setq maker (il-ask "Manufacturer" "") model (il-ask "Model" ""))
      (initget 4)
      (setq watts (getreal "\nWatts each (for the System Designer, Enter to skip): "))
      (setq others (append others (list (il-obj (append (list (cons "fixture_type" fixture-type) (cons "qty" qty) (cons "manufacturer_name" maker))
                                                        (if (/= model "") (list (cons "fixture_model_number" model)))
                                                        (if watts (list (cons "watts_each" watts))))))))
    )
  )
  (il-store-json "OTHERS" (il-arr others))
  (princ (strcat "\n" (itoa (length others)) " other-manufacturer lines in this drawing."))
  (il-end)
)

(defun il-overrides () (il-items (il-fetch-json "OVERRIDES")))

(defun il-add-override (code ref note / kept)
  (foreach item (il-overrides)
    (if (not (and (= (il-j item "code") code) (= (il-j item "ref") ref))) (setq kept (cons item kept)))
  )
  (il-store-json "OVERRIDES" (il-arr (cons (il-obj (list (cons "code" code) (cons "ref" ref) (cons "note" note))) (reverse kept))))
)

(defun c:ILOVERRIDE (/ issues names choice issue note overrides action)
  (il-begin)
  (setq overrides (il-overrides))
  (if overrides
    (progn
      (initget "Add Remove")
      (setq action (getkword (strcat "\n" (itoa (length overrides)) " checks are overridden. [Add an override/Remove one] <Add>: ")))
    )
  )
  (if (= action "Remove")
    (progn
      (setq names (mapcar '(lambda (o) (strcat (il-str (il-j o "code")) " " (il-str (il-j o "ref")) ": " (il-str (il-j o "note")))) overrides))
      (if (setq choice (il-choose "Remove which override" names nil))
        (progn
          (setq issue (nth (vl-position choice names) overrides))
          (il-store-json "OVERRIDES" (il-arr (vl-remove-if '(lambda (o) (and (= (il-j o "code") (il-j issue "code")) (= (il-j o "ref") (il-j issue "ref")))) overrides)))
          (princ "\nOverride removed.")
        )
      )
    )
    (progn
      (il-update-all nil)
      (setq issues (vl-remove-if '(lambda (i) (or (= (il-get "severity" i) "info") (il-overridden-p i (il-get "overrides" (il-model)))))
                                 (il-check (il-model) (il-catalog) (il-today))))
      (if (null issues)
        (princ "\nNothing to override: no open errors or warnings.")
        (progn
          (setq names (mapcar '(lambda (i) (strcat (il-get "code" i) " " (il-str (il-get "ref" i)) ": " (il-get "text" i))) issues))
          (if (setq choice (il-choose "Override which check" names nil))
            (progn
              (setq issue (nth (vl-position choice names) issues) note (il-trim (il-ask "Reason (kept with the quote)" "")))
              (if (>= (strlen note) 3)
                (progn (il-add-override (il-get "code" issue) (il-get "ref" issue) note) (princ "\nOverride recorded."))
                (princ "\nGive a reason of at least 3 characters.")
              )
            )
          )
        )
      )
    )
  )
  (il-end)
)

;; --- Model, ILUPDATE, ILCHECK ------------------------------------------------------------------

(defun il-rev (/ value)
  (setq value (il-number (il-setting "rev")))
  (if value (fix value) 0)
)

(defun il-model (/ runs rooms cabinets psus wires controls x drawing)
  (foreach ename (il-entities "ROOM")
    (setq x (il-xget ename))
    (setq rooms (cons (list (cons "id" (il-get "id" x)) (cons "name" (il-get "name" x)) (cons "level" (il-get "level" x)) (cons "env" (il-get "env" x))
                            (cons "layout" (cdr (assoc 410 (entget ename)))))
                      rooms))
  )
  (foreach ename (il-entities "RUN") (setq runs (cons (il-run-from-entity ename) runs)))
  (foreach ename (il-entities "CABINET")
    (setq x (il-xget ename))
    (setq cabinets (cons (list (cons "id" (il-get "id" x)) (cons "room" (il-get "room" x)) (cons "location_rating" (il-get "rating" x)) (cons "access_note" (il-get "access" x))) cabinets))
  )
  (foreach ename (il-entities "PSU")
    (setq x (il-xget ename))
    (setq psus (cons (list (cons "id" (il-get "id" x)) (cons "cabinet" (il-get "cabinet" x)) (cons "item_code" (il-get "item_code" x))
                           (cons "runs" (if (il-get "runs" x) (il-split (il-get "runs" x) ","))))
                     psus))
  )
  (foreach ename (il-entities "WIRE")
    (setq x (il-xget ename))
    (setq wires (cons (list (cons "id" (il-get "id" x)) (cons "from" (il-get "from" x)) (cons "to" (il-get "to" x)) (cons "kind" (il-get "wire" x))
                            (cons "length_in" (il-get "length_in" (il-path-length (il-lw-vertices ename) nil))))
                      wires))
  )
  (foreach ename (il-entities "CONTROL")
    (setq x (il-xget ename))
    (setq controls (cons (list (cons "id" (il-get "id" x)) (cons "handle" (il-handle ename)) (cons "item_code" (il-get "item_code" x))
                               (cons "cabinet" (il-get "cabinet" x)) (cons "room" (il-get "room" x))
                               (cons "universe" (if (il-get "universe" x) (atoi (il-get "universe" x))))
                               (cons "start" (if (and (il-get "start" x) (/= (il-get "start" x) "auto")) (atoi (il-get "start" x)) "auto"))
                               (cons "control_from" (il-get "control_from" x)) (cons "notes" (il-get "notes" x))
                               (cons "line_key" (il-get "line_key" x)))
                         controls))
  )
  (setq drawing (list (cons "file" (getvar "DWGNAME")) (cons "rev" (il-rev))
                      (cons "scale_verified" (il-true-p (il-setting "scale_verified")))
                      (cons "schedule" (il-setting "schedule")) (cons "project" (il-setting "project"))
                      (cons "schedule_version" (il-setting "schedule_version"))))
  (list
    (cons "drawing" drawing)
    (cons "rooms" (reverse rooms))
    (cons "cabinets" (reverse cabinets))
    (cons "runs" (vl-sort (reverse runs) '(lambda (a b) (< (il-str (il-get "id" a)) (il-str (il-get "id" b))))))
    (cons "styles" (il-styles))
    (cons "psus" (reverse psus))
    (cons "wires" (reverse wires))
    (cons "controls" (vl-sort (reverse controls) '(lambda (a b) (< (il-str (il-get "id" a)) (il-str (il-get "id" b))))))
    (cons "zones" (mapcar '(lambda (zone)
                             (list (cons "id" (il-j zone "id")) (cons "name" (il-j zone "name")) (cons "method" (il-j zone "method"))
                                   (cons "control" (il-j zone "control")) (cons "port" (il-j zone "port"))
                                   (cons "runs" (il-items (il-j zone "runs")))))
                          (il-zones)))
    (cons "others" (il-items (il-fetch-json "OTHERS")))
    (cons "overrides" (mapcar '(lambda (o) (list (cons "code" (il-j o "code")) (cons "ref" (il-j o "ref")) (cons "note" (il-j o "note")))) (il-overrides)))
  )
)

(defun il-update-psu-tag (psu) (il-update-psu-tag-in psu (il-model)))

(defun c:ILUPDATE () (il-begin) (il-update-all T) (il-end))

;; New ids for copies and runs without one, rooms by position, tags and PSU loads.
(defun il-update-all (verbose / x id room count moved model rooms)
  (il-fix-copies verbose)
  (il-clear-loose-markers)
  (setq moved (il-recenter-tags))
  (if (and verbose (> moved 0)) (princ (strcat "\n" (itoa moved) " tag labels centred.")))
  (setq *il-tag-index* (il-tag-index) rooms (il-rooms-index) count 0)
  (foreach ename (il-entities "RUN")
    (setq x (il-xget ename) id (il-get "id" x))
    (if (or (null id) (= id ""))
      (il-xupdate ename (list (cons "id" (il-next-id "RUN" (strcat (if (il-get "type" x) (il-get "type" x) "L") "-")))))
    )
    (setq room (il-room-in rooms (il-run-anchor (il-run-from-entity ename))))
    (if (/= (car room) (il-get "room" x))
      (il-xupdate ename (list (cons "room" (car room)) (cons "location" (cadr room))))
    )
    (il-tag-run ename)
    (setq count (1+ count))
  )
  (foreach kind '("CABINET" "CONTROL")
    (foreach ename (il-entities kind)
      (setq room (il-room-in rooms (cdr (assoc 10 (entget ename)))))
      (if (/= (car room) (il-get "room" (il-xget ename))) (il-xupdate ename (list (cons "room" (car room)))))
    )
  )
  (il-prune-links)
  (foreach ename (il-entities "WIRE") (il-tag-wire ename))
  (setq model (il-model))
  (foreach psu (il-entities "PSU") (il-update-psu-tag-in psu model))
  (setq *il-tag-index* nil)
  (if verbose (princ (strcat "\n" (itoa count) " runs updated.")))
  count
)

(defun il-clear-markers (/ ss)
  (if (setq ss (ssget "_X" '((0 . "INSERT") (2 . "IL-ISSUE"))))
    (command "_.ERASE" ss "")
  )
)

(defun c:ILCHECK (/ model issues counts ename overrides last-hash x)
  (il-begin)
  (il-assets-ensure)
  (il-update-all nil)
  (setq model (il-model) overrides (il-get "overrides" model))
  (setq issues (il-check model (il-catalog) (il-today)))
  (setq last-hash (il-setting "receipt_hash"))
  (if (and last-hash (il-catalog) (/= last-hash (il-model-hash model (il-catalog))))
    (setq issues (append issues (list (il-issue "DRAWING_CHANGED_SINCE_IMPORT" "drawing" "info" "The drawing changed since its last import; run ILQUOTE and import it again"))))
  )
  (il-clear-markers)
  (foreach issue issues
    (princ (strcat "\n" (strcase (il-get "severity" issue)) " " (il-get "code" issue) " " (il-str (il-get "ref" issue)) ": " (il-get "text" issue)
                   (if (il-overridden-p issue overrides) " [overridden]" "")))
    (if (and (/= (il-get "severity" issue) "info") (setq ename (il-find-id "RUN" (il-get "ref" issue))))
      (progn
        (setq *il-layout* (cdr (assoc 410 (entget ename))))
        (il-insert "IL-ISSUE" (il-run-anchor (il-run-from-entity ename)) (il-symbol-scale) "E-ANNO-ISSU" (list (cons "CODE" (il-get "code" issue))))
        (setq *il-layout* nil)
      )
    )
  )
  ;; Red for an open error, yellow for a warning, green when clean (ByLayer once imported).
  (foreach ename (il-entities "RUN")
    (setq x (il-xget ename))
    (il-color-run ename (cond ((il-worst-severity issues (il-get "id" x) overrides))
                              ((il-get "line_key" x) "imported")
                              (T "ok")))
  )
  (setq counts (il-issue-counts issues overrides))
  (princ (strcat "\nILCHECK: " (itoa (car counts)) " errors, " (itoa (cadr counts)) " warnings"
                 (if (> (car counts) 0) ". Fix or override (ILOVERRIDE) the errors before ILQUOTE." ".")))
  (il-end)
)

;; --- ILQUOTE and ILRECEIPT ----------------------------------------------------------------------

(defun c:ILQUOTE (/ catalog model issues counts package hash path rev)
  (il-begin)
  (setq catalog (il-require-catalog))
  (il-update-all nil)
  (setq rev (1+ (il-rev)))
  (setq model (il-model) issues (il-check model catalog (il-today)) counts (il-issue-counts issues (il-get "overrides" model)))
  (setq hash (il-model-hash model catalog))
  (setq model (il-put "drawing" (il-put "rev" rev (il-put "hash" (strcat "sha256:" hash) (il-get "drawing" model))) model))
  (setq package (il-package model catalog issues (il-platform)))
  (setq path (getfiled "Save the drawing package" (strcat (getvar "DWGPREFIX") (vl-filename-base (getvar "DWGNAME")) ".ilq") "json" 1))
  (cond
    ((null path) (princ "\nNo package written."))
    ((not (il-json-write-file package path)) (princ (strcat "\nCould not write " path ". Is it open in another program, or the folder read-only?")))
    (T
      (il-set-setting "rev" rev)
      (il-set-setting "last_package_hash" hash)
      (princ (strcat "\nWrote " path " (revision " (itoa rev) "): " (itoa (length (il-get "runs" model))) " runs, "
                     (itoa (length (il-get "rooms" model))) " rooms, " (itoa (length (il-get "psus" model))) " PSUs, "
                     (itoa (length (il-get "wires" model))) " wires; " (itoa (car counts)) " errors, " (itoa (cadr counts)) " warnings."))
      (if (> (car counts) 0) (princ "\nThe portal refuses packages with errors: run ILCHECK, then fix or override them."))
      (princ "\nUpload it on the schedule page: Import Drawing. No prices are in the package.")
    )
  )
  (il-end)
)

(defun c:ILRECEIPT (/ path receipt index count ename run)
  (il-begin)
  (setq path (getfiled "Import receipt from the portal" (getvar "DWGPREFIX") "json" 0))
  (cond
    ((null path))
    ((null (setq receipt (il-json-read-file path))) (princ (strcat "\nCould not read the receipt: " (il-str *il-jr-error*))))
    ((null (setq index (il-receipt-index receipt))) (princ "\nThis is not an ilLumenate import receipt."))
    (T
      (setq count 0)
      (foreach ename (il-entities "RUN")
        (setq run (il-run-with-receipt (il-run-from-entity ename) index))
        (if (il-get "line_key" run)
          (progn
            (il-xupdate ename (mapcar '(lambda (key) (cons key (il-str (il-get key run))))
                                      '("line_key" "configured_name" "config_hash" "part_number" "server_in")))
            (il-color-run ename "imported")
            (il-tag-run ename)
            (setq count (1+ count))
          )
        )
      )
      (foreach pair (il-receipt-controls receipt)
        (if (and (cdr pair) (setq ename (il-find-id "CONTROL" (car pair))))
          (il-xupdate ename (list (cons "line_key" (cdr pair))))
        )
      )
      (il-set-setting "schedule" (il-j receipt "schedule"))
      (il-set-setting "schedule_version" (il-j receipt "schedule_version"))
      (il-set-setting "receipt_hash" (substr (il-str (il-jp receipt '("drawing" "hash"))) 8))
      (il-store-json "RECEIPT" receipt)
      (princ (strcat "\n" (itoa count) " runs stamped with their schedule lines (" (il-str (il-j receipt "import")) ")."))
    )
  )
  (il-end)
)

;; --- Controls in v1: ILCTRL, ILZONE, ILDMX (PRD question 7) ------------------------------------------

(defun il-zones () (il-items (il-fetch-json "ZONES")))

(defun il-control-label (item)
  (strcat (il-str (il-j item "code")) "  " (il-str (il-j item "model")) "  [" (il-str (il-j item "category")) "]")
)

(defun c:ILCTRL (/ catalog point items names choice item id cabinet universe start source picked insert)
  (il-begin)
  (setq catalog (il-require-catalog))
  (il-assets-ensure)
  (setq items (il-items (il-j catalog "controllers")))
  (if (null items)
    (princ "\nThe catalog has no controls. Add controller specs in ERPNext, then download the catalog again.")
    (if (and (setq point (getpoint "\nControl location: "))
             (setq choice (il-choose "Control" (setq names (mapcar 'il-control-label items)) 1)))
      (progn
        (setq item (nth (vl-position choice names) items))
        (setq id (il-ask-id "CONTROL" "Control tag" (if (= (il-j item "kind") "decoder") "DEC-" "CTL-")))
        (setq cabinet (il-cabinet-for point))
        (if (il-true-p (il-j item "receives_dmx"))
          (progn
            (initget 6)
            (setq universe (getint "\nDMX universe <1>: "))
            (initget 6)
            (setq start (getint "\nDMX start address (Enter for auto): "))
            (if (and start (> start 512)) (progn (princ "\nAddresses are 1 to 512; using auto.") (setq start nil)))
          )
        )
        (initget "None")
        (setq picked (entsel "\nPick the control that sends its signal, or [None] <None>: "))
        (if (and (listp picked) picked (= (il-kind (car picked)) "CONTROL")) (setq source (il-get "id" (il-xget (car picked)))))
        (setq insert (il-insert (if (= (il-j item "kind") "decoder") "IL-DECODER" "IL-CONTROLLER") point
                                (* 0.4 (il-symbol-scale)) "E-LITE-CTRL-EQPM"
                                (list (cons "TAG" id) (cons "MODEL" (il-j item "code"))
                                      (cons "DMX_ADDR" (if (il-true-p (il-j item "receives_dmx")) (strcat "U" (itoa (if universe universe 1)) "/" (if start (itoa start) "auto")) "")))))
        (il-xset insert (list (cons "kind" "CONTROL") (cons "id" id) (cons "item_code" (il-j item "code"))
                              (cons "cabinet" (if cabinet (il-get "id" (il-xget cabinet)))) (cons "room" (il-room-at point))
                              (cons "universe" (if (il-true-p (il-j item "receives_dmx")) (itoa (if universe universe 1))))
                              (cons "start" (if start (itoa start) "auto")) (cons "control_from" source) (cons "self" (il-handle insert))))
        (princ (strcat "\n" id ": " (il-str (il-j item "code")) (if cabinet (strcat " in " (il-get "id" (il-xget cabinet))) "")
                       ". Group runs it dims with ILZONE; draw its data cable with ILWIRE (Data)."))
      )
    )
  )
  (il-end)
)

(defun c:ILZONE (/ catalog zones name method picked control item ports port ss index ename runs id kept existing action)
  (il-begin)
  (setq catalog (il-require-catalog))
  (setq zones (il-zones))
  (if zones (princ (strcat "\nZones: " (il-join (mapcar '(lambda (z) (strcat (il-str (il-j z "id")) " " (il-str (il-j z "name")))) zones) ", "))))
  (setq name (il-trim (il-ask "Zone name" "Zone")))
  (setq existing (car (vl-remove-if-not '(lambda (z) (= (strcase (il-str (il-j z "name"))) (strcase name))) zones)))
  (if existing
    (progn
      (initget "Add Replace Delete")
      (setq action (getkword (strcat "\n" (il-j existing "id") " " name " has " (itoa (length (il-items (il-j existing "runs"))))
                                     " runs. [Add runs/Replace its runs/Delete the zone] <Add>: ")))
      (if (null action) (setq action "Add"))
    )
  )
  (cond
    ((= action "Delete")
      (il-store-json "ZONES" (il-arr (vl-remove existing zones)))
      (princ (strcat "\n" (il-j existing "id") " " name " deleted.")))
    (T
      (if existing
        (setq method (il-j existing "method") control (il-j existing "control") port (il-j existing "port"))
        (progn
          (setq method (il-choose "How the zone is dimmed" *il-zone-methods* 1))
          (initget "None")
          (setq picked (entsel "\nPick the control whose output dims it, or [None] <None>: "))
          (if (and (listp picked) picked (= (il-kind (car picked)) "CONTROL"))
            (progn
              (setq control (il-get "id" (il-xget (car picked))))
              (setq item (il-cat-control catalog (il-get "item_code" (il-xget (car picked)))))
              (setq ports (if item (il-control-outputs item)))
              (setq port (if ports (il-choose "Output" ports 1) (il-ask "Output port name" "")))
            )
          )
        )
      )
      (princ "\nSelect the runs in the zone.")
      (if (setq ss (ssget '((0 . "LWPOLYLINE"))))
        (progn
          (setq index 0)
          (repeat (sslength ss)
            (setq ename (ssname ss index) index (1+ index))
            (if (and (= (il-kind ename) "RUN") (il-get "id" (il-xget ename))) (setq runs (cons (il-get "id" (il-xget ename)) runs)))
          )
        )
      )
      (setq runs (reverse runs))
      (if (and (= action "Add") existing)
        (foreach id (il-items (il-j existing "runs")) (if (not (member id runs)) (setq runs (cons id runs))))
      )
      (if (null runs)
        (princ "\nNo runs selected; the zone was not saved.")
        (progn
          (setq id (if existing (il-j existing "id") (il-next-zone-id zones)))
          ;; A run belongs to one zone: take the selected runs out of the others.
          (foreach zone zones
            (if (/= (il-j zone "id") id)
              (setq kept (cons (il-jset zone "runs" (il-arr (vl-remove-if '(lambda (run) (member run runs)) (il-items (il-j zone "runs"))))) kept))
            )
          )
          (setq zones (append (reverse kept)
                              (list (il-obj (list (cons "id" id) (cons "name" name) (cons "method" method)
                                                  (cons "control" control) (cons "port" port) (cons "runs" (il-arr runs)))))))
          (il-store-json "ZONES" (il-arr zones))
          (princ (strcat "\n" id " " name ": " (itoa (length runs)) " runs, " (il-str method) (if control (strcat " from " control "/" (il-str port)) "") "."))
        )
      )
    )
  )
  (il-end)
)

(defun c:ILDMX (/ catalog patch point rows scale)
  (il-begin)
  (setq catalog (il-require-catalog))
  (il-assets-ensure)
  (setq patch (il-dmx-patch (il-model) catalog))
  (if (null patch)
    (princ "\nNo DMX receivers in the drawing.")
    (progn
      (princ "\nDMX patch (preview; the System Designer exports the final patch):")
      (foreach row patch
        (princ (strcat "\n  U" (itoa (car row)) "  " (il-str (nth 1 row)) "  " (itoa (nth 2 row)) "-" (itoa (nth 3 row)) (if (nth 4 row) "  (auto)" "")))
      )
      (if (setq point (getpoint "\nTop-left corner for the patch table (Enter to skip): "))
        (progn
          (setq scale (if (il-paper-space-p) 1.0 (il-symbol-scale)))
          (setq rows (cons '("UNIVERSE" "CONTROL" "START" "END" "") (mapcar '(lambda (row) (list (itoa (car row)) (il-str (nth 1 row)) (itoa (nth 2 row)) (itoa (nth 3 row)) (if (nth 4 row) "auto" ""))) patch)))
          (il-table point rows (mapcar '(lambda (w) (* w scale)) '(0.9 1.0 0.6 0.6 0.5)) (* 0.09375 scale))
        )
      )
    )
  )
  (il-end)
)

;; --- Outputs: ILOUT, ILRISER, ILSTRIP (plan 4.1, 4.2, 4.5) ----------------------------------------

;; A text table at POINT: ROWS are lists of strings, the first row the header.
(defun il-table (point rows widths height / y x row-height)
  (setq y (cadr point) row-height (* 2.0 height))
  (foreach row rows
    (setq x (car point))
    (mapcar '(lambda (cell width)
               (entmake (list '(0 . "TEXT") '(8 . "E-ANNO-SCHD") (list 10 (+ x (* 0.25 height)) (- y (* 1.5 height)) 0.0) (cons 40 height) (cons 1 (il-str cell))))
               (setq x (+ x width)))
            row widths)
    (entmake (list '(0 . "LINE") '(8 . "E-ANNO-SCHD") (list 10 (car point) (- y row-height) 0.0) (list 11 x (- y row-height) 0.0)))
    (setq y (- y row-height))
  )
  y
)

(defun c:ILOUT (/ point receipt rows scale cuts)
  (il-begin)
  (il-assets-ensure)
  (setq receipt (il-fetch-json "RECEIPT"))
  (if (null receipt)
    (princ "\nRun ILRECEIPT first: the run schedule and cut list show the server's numbers, not the drawing's.")
    (if (setq point (getpoint "\nTop-left corner of the run schedule: "))
      (progn
        (setq scale (if (il-paper-space-p) 1.0 (il-symbol-scale)))
        (setq rows (list '("RUN" "TYPE" "PART NUMBER" "DRAWN IN" "BUILT IN" "CUT LIST (IN)")))
        (foreach run (il-items (il-j receipt "runs"))
          (setq cuts (il-join (mapcar '(lambda (x) (il-num-text x 2)) (il-items (il-j run "cut_list_in"))) " + "))
          (setq rows (append rows (list (list (il-str (il-j run "id")) (il-str (il-j run "fixture_type")) (il-str (il-j run "part_number"))
                                              (il-num-text (il-j run "drawn_length_in") 2)
                                              (il-num-text (il-j run "server_length_in") 2) cuts))))
        )
        (il-table point rows (mapcar '(lambda (w) (* w scale)) '(0.8 0.6 2.6 0.9 0.9 2.4)) (* 0.09375 scale))
        (princ (strcat "\nRun schedule from import " (il-str (il-j receipt "import")) ". Production builds from the BOM, not this table."))
      )
    )
  )
  (il-end)
)

(defun c:ILRISER (/ path point scale)
  (il-begin)
  (princ "\nThe System Designer exports the riser as DXF. Open it, SAVEAS a DWG, then attach that DWG here.")
  (if (and (setq path (getfiled "Riser drawing (DWG saved from the designer's DXF)" (getvar "DWGPREFIX") "dwg" 0))
           (setq point (getpoint "\nInsertion point: ")))
    (progn
      (setq scale (if (il-paper-space-p) 1.0 (il-symbol-scale)))
      (command "_.-XREF" "_Attach" path "_non" point scale scale 0)
      (princ (strcat "\nRiser attached at " (if (= scale 1.0) "full size." (strcat "the plot scale (" (il-scale-text scale) ")."))))
    )
  )
  (il-end)
)

(defun il-strip-xdata (/ ss index ename)
  (if (setq ss (ssget "_X" (list (list -3 (list *il-app*)))))
    (progn
      (setq index 0)
      (repeat (sslength ss)
        (setq ename (ssname ss index) index (1+ index))
        (entmod (append (vl-remove-if '(lambda (item) (= (car item) -3)) (entget ename)) (list (list -3 (list *il-app*)))))
      )
    )
  )
  (dictremove (namedobjdict) *il-dict*)
)

(defun c:ILSTRIP (/ path)
  (il-begin)
  (setq path (getfiled "Save a copy for the architect as" (strcat (getvar "DWGPREFIX") (vl-filename-base (getvar "DWGNAME")) "-architect") "dwg" 1))
  (cond
    ((null path))
    ((= (strcase path) (strcase (strcat (getvar "DWGPREFIX") (getvar "DWGNAME"))))
      (princ "\nPick a new name: ILSTRIP must not overwrite the drawing you are working in."))
    (T
      (if (findfile path) (command "_.SAVEAS" "" path "_Y") (command "_.SAVEAS" "" path))
      (il-clear-markers)
      (il-strip-xdata)
      (command "_.QSAVE")
      (princ (strcat "\nSaved " path " without ilLumenate data. You are now in the copy; reopen the original to keep working."))
    )
  )
  (il-end)
)

;; --- ILVERSION, ILHELP ------------------------------------------------------------------------

(defun c:ILVERSION ()
  (princ (strcat "\nilLumenate CAD toolkit " *il-version* " on " (il-platform)))
  (foreach pair (il-capabilities) (princ (strcat "\n  " (car pair) ": " (il-str (cdr pair)))))
  (if (il-catalog) (princ (strcat "\n  catalog: " (substr (il-str (il-j (il-catalog) "hash")) 1 8) " generated " (il-str (il-j (il-catalog) "generated_at")))))
  (if (and (il-catalog) (il-toolkit-outdated (il-catalog))) (princ (strcat "\n  " (il-toolkit-outdated (il-catalog)) ".")))
  (princ)
)

(defun c:ILHELP ()
  (foreach line
    '("ilLumenate CAD toolkit: draw, check, upload. The portal builds the products and the quote."
      "  ILSETUP     layers, blocks, schedule name, symbol scale, title block"
      "  ILCATALOG   load the CAD catalog downloaded from the portal"
      "  ILSTYLE     choose a run style (saved preset, template and options, or your own custom style)"
      "  ILTAPE      draw runs from the feed end, one after another; ILCONVERT turns lines, arcs and polylines into runs"
      "  ILJUMPER    jumper at a snapped point on a run (again to remove); Span marks a gap between two snapped points"
      "  ILFEED      snap to the feed end; feed direction, lead length and feed method"
      "  ILSCALE     calibrate an underlay; ILROOM rooms; ILCAB cabinets; ILPSU supplies"
      "  ILCONNECT   add or remove runs on a PSU; ILWIRE draw a wire path"
      "  ILCTRL      place a controller or decoder; ILZONE add, change or delete a zone; ILDMX patch"
      "  ILOTHER     add, replace or delete another manufacturer's fixture"
      "  ILOVERRIDE  accept a check with a reason, or remove an override"
      "  ILUPDATE    ids (renumbers copies), rooms, tags and links; ILCHECK checks and colours runs"
      "  ILQUOTE     write the .ilq.json package; upload it with Import Drawing on the schedule page"
      "  ILRECEIPT   stamp line keys and part numbers from the import receipt"
      "  ILOUT       run schedule and cut list from the receipt; ILRISER attach the designer's riser"
      "  ILSTRIP     save a copy without ilLumenate data; ILVERSION version and capabilities")
    (princ (strcat "\n" line))
  )
  (princ)
)

(princ (strcat "\nilLumenate CAD toolkit " *il-version* " loaded. Type ILHELP."))
(princ)
